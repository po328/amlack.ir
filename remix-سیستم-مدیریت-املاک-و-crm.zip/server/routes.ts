import express, { Router, Response } from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { getDatabase, hashPassword, createBackupInternal } from './db/database.js';
import {
  authMiddleware,
  requireRole,
  requirePermission,
  logAudit,
  AuthenticatedRequest
} from './middleware/auth.js';

export const apiRouter = Router();

// Apply auth & tenant scoping middleware to all /api routes
apiRouter.use(authMiddleware);

// ==========================================
// 1. AUTH & USER PROFILE ENDPOINTS
// ==========================================

apiRouter.post('/auth/login', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const { username, password, tenantSlug } = req.body;

  if (!username || !password) {
    res.status(400).json({ error: 'نام کاربری و کلمه عبور الزامی است.' });
    return;
  }

  let user: any;
  if (username === 'superadmin') {
    user = db.prepare("SELECT * FROM users WHERE username = ? AND role = 'super_admin'").get('superadmin');
  } else {
    // 1. Check if user with this username exists
    if (tenantSlug) {
      const tenant = db.prepare('SELECT id FROM tenants WHERE slug = ?').get(tenantSlug) as any;
      if (tenant) {
        user = db.prepare('SELECT * FROM users WHERE username = ? AND tenant_id = ?').get(username, tenant.id);
      }
    } else {
      user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    }

    // 2. If not found, check if username is a real estate agency slug (e.g. shahr_realestate, modern_realestate)
    if (!user) {
      const tenantBySlug = db.prepare('SELECT id FROM tenants WHERE slug = ?').get(username) as any;
      if (tenantBySlug) {
        user = db.prepare("SELECT * FROM users WHERE tenant_id = ? AND role = 'owner' LIMIT 1").get(tenantBySlug.id);
      }
    }
  }

  if (!user) {
    res.status(401).json({ error: 'نام کاربری یا کلمه عبور اشتباه است.' });
    return;
  }

  if (user.is_active !== 1) {
    res.status(403).json({ error: 'حساب کاربری شما غیرفعال شده است. با مدیر آژانس یا پشتیبانی تماس بگیرید.' });
    return;
  }

  // Brute-force Lockout Check
  if (user.locked_until) {
    const lockedUntilDate = new Date(user.locked_until);
    if (lockedUntilDate > new Date()) {
      const remainingMinutes = Math.ceil((lockedUntilDate.getTime() - Date.now()) / (60 * 1000));
      res.status(429).json({
        error: `حساب کاربری شما به علت ۵ بار ورود ناموفق مسدود شده است. لطفاً پس از ${remainingMinutes} دقیقه دیگر تلاش فرمایید.`
      });
      return;
    }
  }

  const { hash } = hashPassword(password, user.salt);
  if (hash !== user.password_hash) {
    const newFailed = (user.failed_attempts || 0) + 1;
    let lockedUntil: string | null = null;
    if (newFailed >= 5) {
      lockedUntil = new Date(Date.now() + 15 * 60 * 1000).toISOString();
    }

    try {
      db.prepare('UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?').run(newFailed, lockedUntil, user.id);
    } catch (_) {}

    // Log failed login
    try {
      db.prepare(`
        INSERT INTO login_history (id, tenant_id, user_id, username, ip_address, user_agent, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, 'failed', ?)
      `).run(
        crypto.randomUUID(),
        user.tenant_id,
        user.id,
        user.username,
        req.ip || '127.0.0.1',
        req.headers['user-agent'] || '',
        new Date().toISOString()
      );
    } catch (_) {}

    const attemptsLeft = Math.max(0, 5 - newFailed);
    res.status(401).json({
      error: attemptsLeft > 0 
        ? `کلمه عبور نادرست است. (${attemptsLeft} تلاش باقی‌مانده قبل از قفل امنیتی)`
        : 'حساب کاربری شما به دلیل تلاش‌های مکرر به مدت ۱۵ دقیقه مسدود شد.'
    });
    return;
  }

  // Password is correct - reset brute force counters and update last login
  const now = new Date().toISOString();
  try {
    db.prepare('UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login_at = ? WHERE id = ?').run(now, user.id);
  } catch (_) {}

  // Generate cryptographically secure session token
  const sessionToken = `sess_${crypto.randomBytes(32).toString('hex')}`;
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(); // 30 days session

  try {
    db.prepare(`
      INSERT INTO user_sessions (id, user_id, tenant_id, token, ip_address, user_agent, created_at, expires_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      `s-${crypto.randomUUID()}`,
      user.id,
      user.tenant_id,
      sessionToken,
      req.ip || '127.0.0.1',
      req.headers['user-agent'] || '',
      now,
      expiresAt
    );
  } catch (_) {}

  // Log successful login
  try {
    db.prepare(`
      INSERT INTO login_history (id, tenant_id, user_id, username, ip_address, user_agent, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 'success', ?)
    `).run(
      crypto.randomUUID(),
      user.tenant_id,
      user.id,
      user.username,
      req.ip || '127.0.0.1',
      req.headers['user-agent'] || '',
      now
    );
  } catch (_) {}

  const tenant = db.prepare('SELECT * FROM tenants WHERE id = ?').get(user.tenant_id) as any;

  res.json({
    token: sessionToken,
    user: {
      id: user.id,
      tenant_id: user.tenant_id,
      username: user.username,
      full_name: user.full_name,
      role: user.role,
      permissions: user.permissions_json ? JSON.parse(user.permissions_json) : [],
      phone: user.phone,
      email: user.email,
      avatar_url: user.avatar_url
    },
    tenant: tenant ? {
      id: tenant.id,
      name: tenant.name,
      slug: tenant.slug,
      license_number: tenant.license_number,
      manager_name: tenant.manager_name,
      phone: tenant.phone,
      city: tenant.city,
      address: tenant.address,
      subscription_plan: tenant.subscription_plan,
      subscription_status: tenant.subscription_status
    } : null
  });
});

// Logout current device
apiRouter.post('/auth/logout', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7).trim();
    try {
      db.prepare('DELETE FROM user_sessions WHERE token = ?').run(token);
    } catch (_) {}
  }
  res.json({ message: 'با موفقیت خارج شدید.' });
});

// Logout from all devices
apiRouter.post('/auth/logout-all', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  if (req.user) {
    try {
      db.prepare('DELETE FROM user_sessions WHERE user_id = ?').run(req.user.id);
    } catch (_) {}
  }
  res.json({ message: 'از تمام دستگاه‌ها با موفقیت خارج شدید.' });
});

// Change Password
apiRouter.post('/auth/logout', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const token = req.headers['authorization']?.replace('Bearer ', '');
  if (token) {
    try {
      db.prepare('DELETE FROM user_sessions WHERE token = ?').run(token);
    } catch (_) {}
  }
  res.json({ message: 'خروج با موفقیت انجام شد.' });
});

apiRouter.post('/auth/change-password', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  if (!req.user) {
    res.status(401).json({ error: 'کاربر احراز هویت نشده است.' });
    return;
  }

  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    res.status(400).json({ error: 'کلمه عبور فعلی و جدید الزامی است.' });
    return;
  }

  if (newPassword.length < 6) {
    res.status(400).json({ error: 'کلمه عبور جدید باید حداقل ۶ کاراکتر باشد.' });
    return;
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id) as any;
  if (!user) {
    res.status(404).json({ error: 'کاربر یافت نشد.' });
    return;
  }

  const { hash } = hashPassword(currentPassword, user.salt);
  if (hash !== user.password_hash) {
    res.status(400).json({ error: 'کلمه عبور فعلی اشتباه است.' });
    return;
  }

  const { hash: newHash, salt: newSalt } = hashPassword(newPassword);
  db.prepare('UPDATE users SET password_hash = ?, salt = ?, updated_at = ? WHERE id = ?').run(
    newHash,
    newSalt,
    new Date().toISOString(),
    user.id
  );

  res.json({ message: 'کلمه عبور شما با موفقیت تغییر یافت.' });
});

// Reset Password (by Owner or Super Admin)
apiRouter.post('/auth/reset-password', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  if (!req.user) {
    res.status(401).json({ error: 'احراز هویت انجام نشده است.' });
    return;
  }

  const { userId, newPassword } = req.body;
  if (!userId || !newPassword) {
    res.status(400).json({ error: 'شناسه کاربر و کلمه عبور جدید الزامی است.' });
    return;
  }

  let targetUser: any;
  if (req.isSuperAdmin) {
    targetUser = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  } else if (req.user.role === 'owner') {
    targetUser = db.prepare('SELECT * FROM users WHERE id = ? AND tenant_id = ?').get(userId, req.tenantId || '');
  } else {
    res.status(403).json({ error: 'فقط مدیر آژانس یا مدیر کل می‌توانند کلمه عبور را بازنشانی کنند.' });
    return;
  }

  if (!targetUser) {
    res.status(404).json({ error: 'کاربر مورد نظر در آژانس شما یافت نشد.' });
    return;
  }

  const { hash: newHash, salt: newSalt } = hashPassword(newPassword);
  db.prepare('UPDATE users SET password_hash = ?, salt = ?, failed_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?').run(
    newHash,
    newSalt,
    new Date().toISOString(),
    targetUser.id
  );

  // Invalidate user sessions to require fresh login
  try {
    db.prepare('DELETE FROM user_sessions WHERE user_id = ?').run(targetUser.id);
  } catch (_) {}

  res.json({ message: `کلمه عبور کاربر ${targetUser.full_name} با موفقیت بازنشانی شد.` });
});

apiRouter.get('/auth/me', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  if (!req.user) {
    res.status(401).json({ error: 'کاربر احراز هویت نشده است.' });
    return;
  }

  const tenant = db.prepare('SELECT * FROM tenants WHERE id = ?').get(req.tenantId!) as any;
  res.json({
    user: req.user,
    tenant: tenant ? {
      id: tenant.id,
      name: tenant.name,
      slug: tenant.slug,
      license_number: tenant.license_number,
      manager_name: tenant.manager_name,
      phone: tenant.phone,
      city: tenant.city,
      address: tenant.address,
      subscription_plan: tenant.subscription_plan,
      subscription_status: tenant.subscription_status,
      settings: tenant.settings_json ? JSON.parse(tenant.settings_json) : null
    } : null
  });
});

// ==========================================
// 2. TENANTS & MULTI-TENANCY MANAGEMENT
// ==========================================

// Super Admin: List all real estate agencies
apiRouter.get('/tenants', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();

  // If superadmin, list all. Otherwise, list only own agency
  if (req.isSuperAdmin) {
    const tenants = db.prepare('SELECT * FROM tenants ORDER BY created_at DESC').all();
    res.json(tenants.map((t: any) => ({
      ...t,
      settings: t.settings_json ? JSON.parse(t.settings_json) : null
    })));
  } else {
    const tenant = db.prepare('SELECT * FROM tenants WHERE id = ?').get(req.tenantId!) as any;
    res.json(tenant ? [{
      ...tenant,
      settings: tenant.settings_json ? JSON.parse(tenant.settings_json) : null
    }] : []);
  }
});

// Super Admin: Create new Real Estate Agency
apiRouter.post('/tenants', requireRole(['super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const {
    name,
    slug,
    managerName,
    phone,
    email,
    city,
    address,
    licenseNumber,
    subscriptionPlan,
    ownerUsername,
    ownerPassword,
    ownerPhone
  } = req.body;

  if (!name || !slug || !managerName || !phone) {
    res.status(400).json({ error: 'اطلاعات الزامی آژانس وارد نشده است.' });
    return;
  }

  const existingSlug = db.prepare('SELECT id FROM tenants WHERE slug = ?').get(slug);
  if (existingSlug) {
    res.status(400).json({ error: 'شناسه انگلیسی (slug) آژانس تکراری است.' });
    return;
  }

  const tenantId = `tenant-${crypto.randomUUID()}`;
  const now = new Date().toISOString();

  const defaultSettings = {
    agencyName: name,
    managerName: managerName,
    phone: phone,
    city: city || 'تهران',
    address: address || '',
    currencyUnit: 'تومان',
    defaultConversionRate: 3.0,
    saleCommissionRateBuyer: 0.5,
    saleCommissionRateSeller: 0.5,
    rentCommissionDays: 7,
    vatPercent: 10,
    agentCommissionSharePercent: 40,
    licenseNumber: licenseNumber || ''
  };

  db.prepare(`
    INSERT INTO tenants (
      id, name, slug, license_number, manager_name, phone, email, city, address,
      subscription_plan, subscription_status, max_users, max_properties, settings_json,
      created_at, updated_at, created_by, updated_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', 20, 2000, ?, ?, ?, ?, ?, 'active')
  `).run(
    tenantId,
    name,
    slug,
    licenseNumber || null,
    managerName,
    phone,
    email || null,
    city || 'تهران',
    address || null,
    subscriptionPlan || 'standard',
    JSON.stringify(defaultSettings),
    now,
    now,
    req.user?.id || 'system',
    req.user?.id || 'system'
  );

  // Create owner account for new agency
  const ownerUser = ownerUsername || `admin_${slug.replace(/[^a-z0-9]/gi, '')}`;
  const { hash, salt } = hashPassword(ownerPassword || '123456');
  const ownerId = `usr-${crypto.randomUUID()}`;

  db.prepare(`
    INSERT INTO users (
      id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
      phone, email, is_active, created_at, updated_at, created_by, updated_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, 'owner', ?, ?, ?, 1, ?, ?, ?, ?, 'active')
  `).run(
    ownerId,
    tenantId,
    ownerUser,
    hash,
    salt,
    managerName,
    JSON.stringify(['*']),
    ownerPhone || phone,
    email || null,
    now,
    now,
    req.user?.id || 'system',
    req.user?.id || 'system'
  );

  logAudit(
    tenantId,
    req.user,
    'create_tenant',
    'ثبت آژانس املاک جدید',
    `آژانس ${name} با موفقیت در سامانه ابری ثبت شد.`,
    'tenant',
    tenantId,
    req.ip
  );

  res.status(201).json({
    message: 'آژانس املاک با موفقیت راه‌اندازی شد.',
    tenantId,
    ownerUsername: ownerUser
  });
});

// Update Agency Settings
apiRouter.put('/tenants/settings', requireRole(['super_admin', 'owner']), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const settings = req.body;
  const tenantId = req.tenantId!;
  const now = new Date().toISOString();

  db.prepare(`
    UPDATE tenants
    SET settings_json = ?,
        name = COALESCE(?, name),
        manager_name = COALESCE(?, manager_name),
        phone = COALESCE(?, phone),
        city = COALESCE(?, city),
        address = COALESCE(?, address),
        license_number = COALESCE(?, license_number),
        updated_at = ?,
        updated_by = ?
    WHERE id = ?
  `).run(
    JSON.stringify(settings),
    settings.agencyName || null,
    settings.managerName || null,
    settings.phone || null,
    settings.city || null,
    settings.address || null,
    settings.licenseNumber || null,
    now,
    req.user?.id || 'system',
    tenantId
  );

  logAudit(
    tenantId,
    req.user,
    'update_settings',
    'بروزرسانی تنظیمات آژانس',
    'تنظیمات کمیسیون، درصدها و اطلاعات تماس آژانس بروزرسانی شد.',
    'tenant',
    tenantId,
    req.ip
  );

  res.json({ message: 'تنظیمات با موفقیت ذخیره شد.', settings });
});

// ==========================================
// 3. PROPERTIES ENDPOINTS (Strictly Scoped)
// ==========================================

apiRouter.get('/properties', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;

  const {
    q,
    type,
    dealType,
    minArea,
    maxArea,
    district,
    status
  } = req.query as Record<string, string>;

  let sql = 'SELECT * FROM properties WHERE tenant_id = ?';
  const params: any[] = [tenantId];

  if (status && status !== 'all') {
    sql += ' AND status = ?';
    params.push(status);
  }

  if (type && type !== 'all') {
    sql += ' AND property_type = ?';
    params.push(type);
  }

  if (dealType && dealType !== 'all') {
    sql += ' AND deal_type = ?';
    params.push(dealType);
  }

  if (district && district !== 'all') {
    sql += ' AND district LIKE ?';
    params.push(`%${district}%`);
  }

  if (minArea) {
    sql += ' AND area >= ?';
    params.push(Number(minArea));
  }

  if (maxArea) {
    sql += ' AND area <= ?';
    params.push(Number(maxArea));
  }

  if (q) {
    sql += ' AND (title LIKE ? OR code LIKE ? OR address LIKE ? OR district LIKE ?)';
    const searchPattern = `%${q}%`;
    params.push(searchPattern, searchPattern, searchPattern, searchPattern);
  }

  sql += ' ORDER BY created_at DESC';

  const rows = db.prepare(sql).all(...params) as any[];

  const properties = rows.map((p) => ({
    id: p.id,
    code: p.code,
    title: p.title,
    propertyType: p.property_type,
    dealType: p.deal_type,
    area: p.area,
    rooms: p.rooms,
    floor: p.floor,
    totalFloors: p.total_floors,
    yearBuilt: p.year_built,
    salePrice: p.sale_price,
    pricePerMeter: p.price_per_meter,
    mortgagePrice: p.mortgage_price,
    rentPrice: p.rent_price,
    address: p.address,
    city: p.city,
    district: p.district,
    description: p.description,
    features: p.features_json ? JSON.parse(p.features_json) : [],
    images: p.images_json ? JSON.parse(p.images_json) : [],
    status: p.status,
    isFavorite: Boolean(p.is_favorite),
    ownerName: p.owner_name,
    ownerPhone: p.owner_phone,
    assignedAgentName: p.assigned_agent_name,
    viewsCount: p.views_count || 0,
    createdAt: p.created_at,
    updatedAt: p.updated_at
  }));

  res.json(properties);
});

apiRouter.get('/properties/:id', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const { id } = req.params;
  const tenantId = req.tenantId!;

  // Strict tenant scoping check!
  const p = db.prepare('SELECT * FROM properties WHERE id = ? AND tenant_id = ?').get(id, tenantId) as any;
  if (!p) {
    res.status(404).json({ error: 'ملک مورد نظر یافت نشد یا دسترسی مجاز نیست.' });
    return;
  }

  // Increment view counter
  db.prepare('UPDATE properties SET views_count = views_count + 1 WHERE id = ?').run(id);

  res.json({
    id: p.id,
    code: p.code,
    title: p.title,
    propertyType: p.property_type,
    dealType: p.deal_type,
    area: p.area,
    rooms: p.rooms,
    floor: p.floor,
    totalFloors: p.total_floors,
    yearBuilt: p.year_built,
    salePrice: p.sale_price,
    pricePerMeter: p.price_per_meter,
    mortgagePrice: p.mortgage_price,
    rentPrice: p.rent_price,
    address: p.address,
    city: p.city,
    district: p.district,
    description: p.description,
    features: p.features_json ? JSON.parse(p.features_json) : [],
    images: p.images_json ? JSON.parse(p.images_json) : [],
    status: p.status,
    isFavorite: Boolean(p.is_favorite),
    ownerName: p.owner_name,
    ownerPhone: p.owner_phone,
    assignedAgentName: p.assigned_agent_name,
    viewsCount: (p.views_count || 0) + 1,
    createdAt: p.created_at,
    updatedAt: p.updated_at
  });
});

apiRouter.post('/properties', requirePermission('properties.create'), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;
  const body = req.body;

  const id = `prop-${crypto.randomUUID()}`;
  const now = new Date().toISOString();

  // Generate unique file code if not supplied
  let code = body.code;
  if (!code) {
    const count = (db.prepare('SELECT COUNT(*) as c FROM properties WHERE tenant_id = ?').get(tenantId) as any)?.c || 0;
    code = `ملک-${count + 101}`;
  }

  db.prepare(`
    INSERT INTO properties (
      id, tenant_id, code, title, property_type, deal_type, area, rooms, floor, total_floors,
      year_built, sale_price, price_per_meter, mortgage_price, rent_price, address, city, district,
      description, features_json, images_json, documents_json, owner_name, owner_phone,
      assigned_agent_name, is_favorite, created_at, updated_at, created_by, updated_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    tenantId,
    code,
    body.title,
    body.propertyType,
    body.dealType,
    Number(body.area) || 0,
    Number(body.rooms) || 0,
    body.floor !== undefined ? Number(body.floor) : null,
    body.totalFloors !== undefined ? Number(body.totalFloors) : null,
    body.yearBuilt !== undefined ? Number(body.yearBuilt) : null,
    body.salePrice !== undefined ? Number(body.salePrice) : null,
    body.pricePerMeter !== undefined ? Number(body.pricePerMeter) : null,
    body.mortgagePrice !== undefined ? Number(body.mortgagePrice) : null,
    body.rentPrice !== undefined ? Number(body.rentPrice) : null,
    body.address || '',
    body.city || 'تهران',
    body.district || '',
    body.description || '',
    JSON.stringify(body.features || []),
    JSON.stringify(body.images || []),
    JSON.stringify([]),
    body.ownerName || null,
    body.ownerPhone || null,
    body.assignedAgentName || req.user?.full_name || null,
    body.isFavorite ? 1 : 0,
    now,
    now,
    req.user?.id || 'system',
    req.user?.id || 'system',
    body.status || 'active'
  );

  logAudit(
    tenantId,
    req.user,
    'create_property',
    'ثبت ملک جدید',
    `فایل با کد ${code} (${body.title}) در سامانه ثبت گردید.`,
    'property',
    id,
    req.ip
  );

  res.status(201).json({ id, code, message: 'ملک با موفقیت در پایگاه داده ثبت شد.' });
});

apiRouter.put('/properties/:id', requirePermission('properties.edit'), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const { id } = req.params;
  const tenantId = req.tenantId!;
  const body = req.body;

  // Strict tenant verification
  const existing = db.prepare('SELECT id FROM properties WHERE id = ? AND tenant_id = ?').get(id, tenantId);
  if (!existing) {
    res.status(404).json({ error: 'فایل ملکی برای این آژانس یافت نشد.' });
    return;
  }

  const now = new Date().toISOString();

  db.prepare(`
    UPDATE properties SET
      title = ?,
      property_type = ?,
      deal_type = ?,
      area = ?,
      rooms = ?,
      floor = ?,
      total_floors = ?,
      year_built = ?,
      sale_price = ?,
      price_per_meter = ?,
      mortgage_price = ?,
      rent_price = ?,
      address = ?,
      city = ?,
      district = ?,
      description = ?,
      features_json = ?,
      images_json = ?,
      owner_name = ?,
      owner_phone = ?,
      assigned_agent_name = ?,
      is_favorite = ?,
      status = ?,
      updated_at = ?,
      updated_by = ?
    WHERE id = ? AND tenant_id = ?
  `).run(
    body.title,
    body.propertyType,
    body.dealType,
    Number(body.area) || 0,
    Number(body.rooms) || 0,
    body.floor !== undefined ? Number(body.floor) : null,
    body.totalFloors !== undefined ? Number(body.totalFloors) : null,
    body.yearBuilt !== undefined ? Number(body.yearBuilt) : null,
    body.salePrice !== undefined ? Number(body.salePrice) : null,
    body.pricePerMeter !== undefined ? Number(body.pricePerMeter) : null,
    body.mortgagePrice !== undefined ? Number(body.mortgagePrice) : null,
    body.rentPrice !== undefined ? Number(body.rentPrice) : null,
    body.address || '',
    body.city || 'تهران',
    body.district || '',
    body.description || '',
    JSON.stringify(body.features || []),
    JSON.stringify(body.images || []),
    body.ownerName || null,
    body.ownerPhone || null,
    body.assignedAgentName || null,
    body.isFavorite ? 1 : 0,
    body.status || 'active',
    now,
    req.user?.id || 'system',
    id,
    tenantId
  );

  logAudit(
    tenantId,
    req.user,
    'update_property',
    'ویرایش اطلاعات ملک',
    `اطلاعات فایل کد ${body.code || id} بروزرسانی گردید.`,
    'property',
    id,
    req.ip
  );

  res.json({ message: 'تغییرات ملک با موفقیت ذخیره شد.' });
});

apiRouter.delete('/properties/:id', requirePermission('properties.delete'), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const { id } = req.params;
  const tenantId = req.tenantId!;

  // Strict tenant scoping check
  const existing = db.prepare('SELECT code, title FROM properties WHERE id = ? AND tenant_id = ?').get(id, tenantId) as any;
  if (!existing) {
    res.status(404).json({ error: 'ملک یافت نشد یا دسترسی مجاز نیست.' });
    return;
  }

  db.prepare('DELETE FROM properties WHERE id = ? AND tenant_id = ?').run(id, tenantId);

  logAudit(
    tenantId,
    req.user,
    'delete_property',
    'حذف فایل ملکی',
    `ملک با کد ${existing.code} (${existing.title}) حذف گردید.`,
    'property',
    id,
    req.ip
  );

  res.json({ message: 'فایل ملکی با موفقیت حذف گردید.' });
});

// ==========================================
// 4. CUSTOMERS CRM ENDPOINTS
// ==========================================

apiRouter.get('/customers', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;

  const rows = db.prepare('SELECT * FROM customers WHERE tenant_id = ? ORDER BY created_at DESC').all(tenantId) as any[];

  const customers = rows.map((c) => ({
    id: c.id,
    fullName: c.full_name,
    phone: c.phone,
    email: c.email,
    customerType: c.customer_type,
    dealType: c.deal_type,
    preferredPropertyTypes: c.preferred_property_types_json ? JSON.parse(c.preferred_property_types_json) : [],
    minArea: c.min_area,
    maxArea: c.max_area,
    minRooms: c.min_rooms,
    preferredDistricts: c.preferred_districts_json ? JSON.parse(c.preferred_districts_json) : [],
    budgetMin: c.budget_min,
    budgetMax: c.budget_max,
    mortgageMax: c.mortgage_max,
    rentMax: c.rent_max,
    notes: c.notes,
    status: c.status,
    createdAt: c.created_at,
    lastContactDate: c.last_contact_date
  }));

  res.json(customers);
});

apiRouter.post('/customers', requirePermission('customers.create'), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;
  const body = req.body;

  const id = `cust-${crypto.randomUUID()}`;
  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO customers (
      id, tenant_id, full_name, phone, email, customer_type, deal_type,
      preferred_property_types_json, min_area, max_area, min_rooms, preferred_districts_json,
      budget_min, budget_max, mortgage_max, rent_max, notes, last_contact_date,
      created_at, updated_at, created_by, updated_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    tenantId,
    body.fullName,
    body.phone,
    body.email || null,
    body.customerType,
    body.dealType,
    JSON.stringify(body.preferredPropertyTypes || []),
    body.minArea !== undefined ? Number(body.minArea) : null,
    body.maxArea !== undefined ? Number(body.maxArea) : null,
    body.minRooms !== undefined ? Number(body.minRooms) : null,
    JSON.stringify(body.preferredDistricts || []),
    body.budgetMin !== undefined ? Number(body.budgetMin) : null,
    body.budgetMax !== undefined ? Number(body.budgetMax) : null,
    body.mortgageMax !== undefined ? Number(body.mortgageMax) : null,
    body.rentMax !== undefined ? Number(body.rentMax) : null,
    body.notes || null,
    body.lastContactDate || now,
    now,
    now,
    req.user?.id || 'system',
    req.user?.id || 'system',
    body.status || 'active'
  );

  logAudit(
    tenantId,
    req.user,
    'create_customer',
    'ثبت پرونده مشتری جدید',
    `پرونده متقاضی ${body.fullName} (${body.phone}) ایجاد گردید.`,
    'customer',
    id,
    req.ip
  );

  res.status(201).json({ id, message: 'مشتری با موفقیت ثبت شد.' });
});

apiRouter.put('/customers/:id', requirePermission('customers.edit'), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const { id } = req.params;
  const tenantId = req.tenantId!;
  const body = req.body;

  const existing = db.prepare('SELECT id FROM customers WHERE id = ? AND tenant_id = ?').get(id, tenantId);
  if (!existing) {
    res.status(404).json({ error: 'پرونده مشتری یافت نشد.' });
    return;
  }

  const now = new Date().toISOString();

  db.prepare(`
    UPDATE customers SET
      full_name = ?,
      phone = ?,
      email = ?,
      customer_type = ?,
      deal_type = ?,
      preferred_property_types_json = ?,
      min_area = ?,
      max_area = ?,
      min_rooms = ?,
      preferred_districts_json = ?,
      budget_min = ?,
      budget_max = ?,
      mortgage_max = ?,
      rent_max = ?,
      notes = ?,
      status = ?,
      updated_at = ?,
      updated_by = ?
    WHERE id = ? AND tenant_id = ?
  `).run(
    body.fullName,
    body.phone,
    body.email || null,
    body.customerType,
    body.dealType,
    JSON.stringify(body.preferredPropertyTypes || []),
    body.minArea !== undefined ? Number(body.minArea) : null,
    body.maxArea !== undefined ? Number(body.maxArea) : null,
    body.minRooms !== undefined ? Number(body.minRooms) : null,
    JSON.stringify(body.preferredDistricts || []),
    body.budgetMin !== undefined ? Number(body.budgetMin) : null,
    body.budgetMax !== undefined ? Number(body.budgetMax) : null,
    body.mortgageMax !== undefined ? Number(body.mortgageMax) : null,
    body.rentMax !== undefined ? Number(body.rentMax) : null,
    body.notes || null,
    body.status || 'active',
    now,
    req.user?.id || 'system',
    id,
    tenantId
  );

  res.json({ message: 'اطلاعات مشتری بروز شد.' });
});

apiRouter.delete('/customers/:id', requirePermission('customers.delete'), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const { id } = req.params;
  const tenantId = req.tenantId!;

  const existing = db.prepare('SELECT full_name FROM customers WHERE id = ? AND tenant_id = ?').get(id, tenantId) as any;
  if (!existing) {
    res.status(404).json({ error: 'مشتری یافت نشد.' });
    return;
  }

  db.prepare('DELETE FROM customers WHERE id = ? AND tenant_id = ?').run(id, tenantId);

  logAudit(
    tenantId,
    req.user,
    'delete_customer',
    'حذف پرونده مشتری',
    `پرونده ${existing.full_name} از سامانه حذف شد.`,
    'customer',
    id,
    req.ip
  );

  res.json({ message: 'پرونده مشتری با موفقیت حذف شد.' });
});

// Interactions & timeline
apiRouter.get('/customers/:id/interactions', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const { id } = req.params;
  const tenantId = req.tenantId!;

  const rows = db.prepare(`
    SELECT * FROM customer_interactions
    WHERE customer_id = ? AND tenant_id = ?
    ORDER BY date DESC
  `).all(id, tenantId);

  res.json(rows);
});

apiRouter.post('/customers/:id/interactions', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const { id: customerId } = req.params;
  const tenantId = req.tenantId!;
  const { type, notes, result, customerName } = req.body;

  const intId = `int-${crypto.randomUUID()}`;
  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO customer_interactions (
      id, tenant_id, customer_id, customer_name, user_id, type,
      date, notes, result, created_at, updated_at, created_by, updated_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed')
  `).run(
    intId,
    tenantId,
    customerId,
    customerName || '',
    req.user?.id || null,
    type || 'call',
    now,
    notes,
    result || null,
    now,
    now,
    req.user?.id || 'system',
    req.user?.id || 'system'
  );

  // Update customer's last contact date
  db.prepare('UPDATE customers SET last_contact_date = ? WHERE id = ? AND tenant_id = ?').run(now, customerId, tenantId);

  res.status(201).json({ id: intId, message: 'تعامل در پرونده ثبت شد.' });
});

// ==========================================
// 5. CONTRACTS & COMMISSIONS
// ==========================================

apiRouter.get('/contracts', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;

  const rows = db.prepare('SELECT * FROM contracts WHERE tenant_id = ? ORDER BY contract_date DESC').all(tenantId);
  res.json(rows);
});

apiRouter.post('/contracts', requirePermission('contracts.create'), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;
  const body = req.body;

  const id = `cnt-${crypto.randomUUID()}`;
  const now = new Date().toISOString();

  let contractNumber = body.contractNumber;
  if (!contractNumber) {
    const count = (db.prepare('SELECT COUNT(*) as c FROM contracts WHERE tenant_id = ?').get(tenantId) as any)?.c || 0;
    contractNumber = `CR-1403-${count + 101}`;
  }

  db.prepare(`
    INSERT INTO contracts (
      id, tenant_id, contract_number, deal_type, property_id, customer_id,
      owner_name, owner_phone, client_name, client_phone, total_amount,
      mortgage_amount, rent_amount, commission_total, agency_share, agent_share,
      agent_id, agent_name, tax_amount, contract_date, payment_status, notes,
      created_at, updated_at, created_by, updated_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    tenantId,
    contractNumber,
    body.dealType,
    body.propertyId || null,
    body.customerId || null,
    body.ownerName || 'مالک',
    body.ownerPhone || null,
    body.clientName || 'مشتری',
    body.clientPhone || null,
    Number(body.totalAmount) || 0,
    Number(body.mortgageAmount) || 0,
    Number(body.rentAmount) || 0,
    Number(body.commissionTotal) || 0,
    Number(body.agencyShare) || 0,
    Number(body.agentShare) || 0,
    body.agentId || req.user?.id || null,
    body.agentName || req.user?.full_name || 'مشاور',
    Number(body.taxAmount) || 0,
    body.contractDate || now.split('T')[0],
    body.paymentStatus || 'paid',
    body.notes || null,
    now,
    now,
    req.user?.id || 'system',
    req.user?.id || 'system',
    'completed'
  );

  // Automatically record financial transactions
  const finIncomeId = `fin-inc-${crypto.randomUUID()}`;
  db.prepare(`
    INSERT INTO financial_transactions (
      id, tenant_id, contract_id, type, category, title, amount,
      payment_method, date, agent_name, description, created_at, updated_at, status
    ) VALUES (?, ?, ?, 'income', 'deal_commission', ?, ?, 'bank_transfer', ?, ?, ?, ?, ?, 'completed')
  `).run(
    finIncomeId,
    tenantId,
    id,
    `دریافت کمیسیون قرارداد ${contractNumber}`,
    Number(body.commissionTotal) || 0,
    body.contractDate || now.split('T')[0],
    body.agentName || req.user?.full_name || 'مشاور',
    `کمیسیون قرارداد منعقد شده`,
    now,
    now
  );

  logAudit(
    tenantId,
    req.user,
    'save_commission',
    'ثبت قرارداد و کمیسیون',
    `قرارداد رسمی شماره ${contractNumber} با کمیسیون ${Number(body.commissionTotal).toLocaleString('fa-IR')} تومان ثبت گردید.`,
    'contract',
    id,
    req.ip
  );

  res.status(201).json({ id, contractNumber, message: 'قرارداد و امور مالی مربوطه با موفقیت ثبت شد.' });
});

// ==========================================
// 6. FINANCIAL TRANSACTIONS & COMMISSIONS
// ==========================================

apiRouter.get('/finances', requirePermission('finances.view'), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;

  const rows = db.prepare('SELECT * FROM financial_transactions WHERE tenant_id = ? ORDER BY date DESC').all(tenantId);
  res.json(rows);
});

apiRouter.post('/finances', requirePermission('finances.create'), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;
  const body = req.body;

  const id = `fin-${crypto.randomUUID()}`;
  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO financial_transactions (
      id, tenant_id, contract_id, type, category, title, amount,
      payment_method, reference_number, date, agent_name, description,
      created_at, updated_at, created_by, updated_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed')
  `).run(
    id,
    tenantId,
    body.contractId || null,
    body.type, // 'income' or 'expense'
    body.category || 'other',
    body.title,
    Number(body.amount) || 0,
    body.paymentMethod || 'bank_transfer',
    body.referenceNumber || null,
    body.date || now.split('T')[0],
    body.agentName || null,
    body.description || null,
    now,
    now,
    req.user?.id || 'system',
    req.user?.id || 'system'
  );

  res.status(201).json({ id, message: 'تراکنش مالی با موفقیت ثبت گردید.' });
});

// ==========================================
// 7. TASKS & FOLLOW-UPS
// ==========================================

apiRouter.get('/tasks', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;

  const rows = db.prepare('SELECT * FROM follow_ups WHERE tenant_id = ? ORDER BY due_date ASC, due_time ASC').all(tenantId) as any[];

  const tasks = rows.map((t) => ({
    id: t.id,
    title: t.title,
    customerId: t.customer_id,
    customerName: t.customer_name,
    propertyId: t.property_id,
    propertyTitle: t.property_title,
    dueDate: t.due_date,
    dueTime: t.due_time,
    priority: t.priority,
    status: t.status,
    notes: t.notes,
    createdAt: t.created_at
  }));

  res.json(tasks);
});

apiRouter.post('/tasks', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;
  const body = req.body;

  const id = `tsk-${crypto.randomUUID()}`;
  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO follow_ups (
      id, tenant_id, title, customer_id, customer_name, property_id, property_title,
      due_date, due_time, priority, notes, created_at, updated_at, created_by, updated_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    tenantId,
    body.title,
    body.customerId || null,
    body.customerName || null,
    body.propertyId || null,
    body.propertyTitle || null,
    body.dueDate,
    body.dueTime || '12:00',
    body.priority || 'medium',
    body.notes || null,
    now,
    now,
    req.user?.id || 'system',
    req.user?.id || 'system',
    body.status || 'pending'
  );

  res.status(201).json({ id, message: 'وظیفه پیگیری در تقویم ثبت شد.' });
});

apiRouter.put('/tasks/:id/toggle', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const { id } = req.params;
  const tenantId = req.tenantId!;

  const task = db.prepare('SELECT status FROM follow_ups WHERE id = ? AND tenant_id = ?').get(id, tenantId) as any;
  if (!task) {
    res.status(404).json({ error: 'وظیفه یافت نشد.' });
    return;
  }

  const newStatus = task.status === 'completed' ? 'pending' : 'completed';
  const now = new Date().toISOString();

  db.prepare('UPDATE follow_ups SET status = ?, updated_at = ? WHERE id = ? AND tenant_id = ?').run(
    newStatus,
    now,
    id,
    tenantId
  );

  res.json({ id, status: newStatus });
});

apiRouter.delete('/tasks/:id', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const { id } = req.params;
  const tenantId = req.tenantId!;

  db.prepare('DELETE FROM follow_ups WHERE id = ? AND tenant_id = ?').run(id, tenantId);
  res.json({ message: 'وظیفه پیگیری با موفقیت حذف شد.' });
});

// ==========================================
// 8. MORTGAGE / RENT CONVERSIONS
// ==========================================

apiRouter.get('/conversions', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;

  const rows = db.prepare('SELECT * FROM conversions WHERE tenant_id = ? ORDER BY date DESC').all(tenantId) as any[];
  res.json(rows.map((r) => ({
    id: r.id,
    mortgage: r.mortgage,
    rent: r.rent,
    ratePercent: r.rate_percent,
    fullMortgage: r.full_mortgage,
    fullRent: r.full_rent,
    date: r.date
  })));
});

apiRouter.post('/conversions', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;
  const body = req.body;

  const id = `cnv-${crypto.randomUUID()}`;
  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO conversions (
      id, tenant_id, mortgage, rent, rate_percent, full_mortgage, full_rent,
      date, created_at, updated_at, created_by, updated_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
  `).run(
    id,
    tenantId,
    Number(body.mortgage) || 0,
    Number(body.rent) || 0,
    Number(body.ratePercent) || 3.0,
    Number(body.fullMortgage) || 0,
    Number(body.fullRent) || 0,
    body.date || now,
    now,
    now,
    req.user?.id || 'system',
    req.user?.id || 'system'
  );

  res.status(201).json({ id, message: 'نتیجه تبدیل ثبت شد.' });
});

apiRouter.delete('/conversions', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;

  db.prepare('DELETE FROM conversions WHERE tenant_id = ?').run(tenantId);
  res.json({ message: 'تاریخچه محاسبات تبدیل پاکسازی شد.' });
});

// ==========================================
// 9. USERS & STAFF MANAGEMENT
// ==========================================

apiRouter.get('/users', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;

  const rows = db.prepare(`
    SELECT id, tenant_id, username, full_name, role, permissions_json, phone, email, avatar_url, is_active, last_login_at, created_at
    FROM users
    WHERE tenant_id = ?
    ORDER BY created_at ASC
  `).all(tenantId) as any[];

  res.json(rows.map((u) => ({
    id: u.id,
    fullName: u.full_name,
    username: u.username,
    role: u.role,
    phone: u.phone,
    email: u.email,
    avatarUrl: u.avatar_url,
    isActive: Boolean(u.is_active),
    permissions: u.permissions_json ? JSON.parse(u.permissions_json) : []
  })));
});

apiRouter.post('/users', requireRole(['super_admin', 'owner']), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;
  const { fullName, username, password, role, phone, email, permissions } = req.body;

  if (!fullName || !username || !phone) {
    res.status(400).json({ error: 'نام و نام خانوادگی، نام کاربری و شماره تماس الزامی است.' });
    return;
  }

  // Check unique username within tenant
  const existing = db.prepare('SELECT id FROM users WHERE tenant_id = ? AND username = ?').get(tenantId, username);
  if (existing) {
    res.status(400).json({ error: 'این نام کاربری قبلاً در این آژانس ثبت شده است.' });
    return;
  }

  const { hash, salt } = hashPassword(password || '123456');
  const id = `usr-${crypto.randomUUID()}`;
  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO users (
      id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
      phone, email, is_active, created_at, updated_at, created_by, updated_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, 'active')
  `).run(
    id,
    tenantId,
    username,
    hash,
    salt,
    fullName,
    role || 'agent',
    JSON.stringify(permissions || ['properties.view', 'properties.create', 'customers.view']),
    phone,
    email || null,
    now,
    now,
    req.user?.id || 'system',
    req.user?.id || 'system'
  );

  logAudit(
    tenantId,
    req.user,
    'create_user',
    'افزودن مشاور/کاربر جدید',
    `کاربر جدید ${fullName} با نقش ${role} به کادر آژانس افزوده شد.`,
    'user',
    id,
    req.ip
  );

  res.status(201).json({ id, message: 'کاربر با موفقیت اضافه شد.' });
});

apiRouter.put('/users/:id', requireRole(['super_admin', 'owner']), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;
  const userId = req.params.id;
  const { fullName, phone, role, permissions, isActive, password } = req.body;

  let user: any;
  if (req.isSuperAdmin) {
    user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  } else {
    user = db.prepare('SELECT * FROM users WHERE id = ? AND tenant_id = ?').get(userId, tenantId);
  }

  if (!user) {
    res.status(404).json({ error: 'کاربر یافت نشد.' });
    return;
  }

  const now = new Date().toISOString();
  let newHash = user.password_hash;
  let newSalt = user.salt;
  if (password) {
    const p = hashPassword(password);
    newHash = p.hash;
    newSalt = p.salt;
  }

  db.prepare(`
    UPDATE users SET
      full_name = ?,
      phone = ?,
      role = ?,
      permissions_json = ?,
      is_active = ?,
      password_hash = ?,
      salt = ?,
      updated_at = ?
    WHERE id = ?
  `).run(
    fullName !== undefined ? fullName : user.full_name,
    phone !== undefined ? phone : user.phone,
    role !== undefined ? role : user.role,
    permissions ? JSON.stringify(permissions) : user.permissions_json,
    isActive !== undefined ? (isActive ? 1 : 0) : user.is_active,
    newHash,
    newSalt,
    now,
    userId
  );

  res.json({ message: 'اطلاعات کاربر با موفقیت به‌روزرسانی شد.' });
});

apiRouter.delete('/users/:id', requireRole(['super_admin', 'owner']), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;
  const userId = req.params.id;

  let user: any;
  if (req.isSuperAdmin) {
    user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  } else {
    user = db.prepare('SELECT * FROM users WHERE id = ? AND tenant_id = ?').get(userId, tenantId);
  }

  if (!user) {
    res.status(404).json({ error: 'کاربر در آژانس شما یافت نشد.' });
    return;
  }

  if (user.role === 'owner' && !req.isSuperAdmin) {
    res.status(403).json({ error: 'حساب مالک آژانس قابل حذف نیست.' });
    return;
  }

  db.prepare('DELETE FROM users WHERE id = ?').run(userId);
  try {
    db.prepare('DELETE FROM user_sessions WHERE user_id = ?').run(userId);
  } catch (_) {}

  res.json({ message: 'کاربر با موفقیت حذف شد.' });
});

// ==========================================
// 10. ACTIVITY AUDIT TRAIL
// ==========================================

apiRouter.get('/activity', (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;

  const rows = db.prepare(`
    SELECT * FROM activity_logs
    WHERE tenant_id = ?
    ORDER BY timestamp DESC
    LIMIT 100
  `).all(tenantId);

  res.json(rows);
});

// ==========================================
// 11. SECURE FILE & IMAGE UPLOADS
// ==========================================

apiRouter.post('/upload', express.json({ limit: '25mb' }), (req: AuthenticatedRequest, res: Response) => {
  const tenantId = req.tenantId!;
  const { data, filename, mimeType } = req.body;

  if (!data || !filename) {
    res.status(400).json({ error: 'داده‌های تصویر ارسال نشده است.' });
    return;
  }

  try {
    // Tenant isolated upload directory
    const tenantUploadDir = path.join(process.cwd(), 'data', 'uploads', tenantId);
    if (!fs.existsSync(tenantUploadDir)) {
      fs.mkdirSync(tenantUploadDir, { recursive: true });
    }

    // Decode base64
    const base64Data = data.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');

    // Generate safe unique filename
    const ext = path.extname(filename) || '.jpg';
    const uniqueName = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`;
    const filePath = path.join(tenantUploadDir, uniqueName);

    fs.writeFileSync(filePath, buffer);

    const publicUrl = `/api/files/${tenantId}/${uniqueName}`;
    res.json({
      url: publicUrl,
      filename: uniqueName,
      size: buffer.length
    });
  } catch (err: any) {
    console.error('[Upload Error]', err);
    res.status(500).json({ error: 'خطا در ذخیره‌سازی تصویر در سرور.' });
  }
});

apiRouter.get('/files/:tenantId/:fileName', (req: AuthenticatedRequest, res: Response) => {
  const { tenantId, fileName } = req.params;

  // STRICT MULTI-TENANT FILE ISOLATION:
  // Non-superadmins can only access files belonging to their assigned tenant!
  if (!req.isSuperAdmin && req.tenantId && req.tenantId !== tenantId) {
    res.status(403).send('دسترسی به فایل‌های سایر دفاتر املاک امکان‌پذیر نیست.');
    return;
  }

  const safeName = path.basename(fileName); // Prevent path traversal attack
  const filePath = path.join(process.cwd(), 'data', 'uploads', tenantId, safeName);

  if (!fs.existsSync(filePath)) {
    res.status(404).send('فایل یافت نشد');
    return;
  }

  res.sendFile(filePath);
});

// ==========================================
// 12. BACKUP & RECOVERY SYSTEM
// ==========================================

apiRouter.post('/backups/create', requireRole(['super_admin', 'owner']), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const backupPath = createBackupInternal(db, 'manual', 'پشتیبان دستی تهیه شده توسط کاربر');

  if (backupPath) {
    res.json({ message: 'نسخه پشتیبان با موفقیت تهیه شد.', path: path.basename(backupPath) });
  } else {
    res.status(500).json({ error: 'خطا در تهیه نسخه پشتیبان.' });
  }
});

apiRouter.get('/backups', requireRole(['super_admin', 'owner']), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const backups = db.prepare('SELECT * FROM system_backups ORDER BY created_at DESC').all();
  res.json(backups);
});

apiRouter.post('/backups/reset', requireRole(['super_admin', 'owner']), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();
  const tenantId = req.tenantId!;

  // Take safety backup before wiping
  createBackupInternal(db, 'pre_migration', 'پشتیبان خودکار قبل از بازنشانی داده‌ها');

  // Reset only tenant's properties, customers, tasks and transactions
  db.prepare('DELETE FROM properties WHERE tenant_id = ?').run(tenantId);
  db.prepare('DELETE FROM customers WHERE tenant_id = ?').run(tenantId);
  db.prepare('DELETE FROM follow_ups WHERE tenant_id = ?').run(tenantId);
  db.prepare('DELETE FROM customer_interactions WHERE tenant_id = ?').run(tenantId);
  db.prepare('DELETE FROM contracts WHERE tenant_id = ?').run(tenantId);
  db.prepare('DELETE FROM financial_transactions WHERE tenant_id = ?').run(tenantId);
  db.prepare('DELETE FROM conversions WHERE tenant_id = ?').run(tenantId);

  res.json({ message: 'داده‌های آژانس با موفقیت بازنشانی شد و نسخه پشتیبان امن ذخیره گردید.' });
});

// ==========================================
// 13. SUPER ADMIN PLATFORM METRICS
// ==========================================

apiRouter.get('/platform/stats', requireRole(['super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const db = getDatabase();

  const totalTenants = (db.prepare('SELECT COUNT(*) as c FROM tenants').get() as any)?.c || 0;
  const totalUsers = (db.prepare('SELECT COUNT(*) as c FROM users').get() as any)?.c || 0;
  const totalProperties = (db.prepare('SELECT COUNT(*) as c FROM properties').get() as any)?.c || 0;
  const totalCustomers = (db.prepare('SELECT COUNT(*) as c FROM customers').get() as any)?.c || 0;
  const totalContracts = (db.prepare('SELECT COUNT(*) as c FROM contracts').get() as any)?.c || 0;
  const totalCommissions = (db.prepare('SELECT SUM(commission_total) as s FROM contracts').get() as any)?.s || 0;

  const tenantStats = db.prepare(`
    SELECT t.id, t.name, t.slug, t.city, t.subscription_plan, t.subscription_status,
      (SELECT COUNT(*) FROM properties WHERE tenant_id = t.id) as properties_count,
      (SELECT COUNT(*) FROM customers WHERE tenant_id = t.id) as customers_count,
      (SELECT COUNT(*) FROM users WHERE tenant_id = t.id) as users_count,
      (SELECT COUNT(*) FROM contracts WHERE tenant_id = t.id) as contracts_count
    FROM tenants t
    ORDER BY t.created_at DESC
  `).all();

  res.json({
    summary: {
      totalTenants,
      totalUsers,
      totalProperties,
      totalCustomers,
      totalContracts,
      totalCommissions
    },
    tenants: tenantStats
  });
});
