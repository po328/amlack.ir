import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { migrations } from './migrations.js';

const defaultTenantSettings = {
  agencyName: 'املاک نگین پایتخت',
  managerName: 'مهندس علی رضایی',
  phone: '02122003344',
  city: 'تهران',
  address: 'سعادت‌آباد، میدان کاج، نبش خیابان مروارید',
  currencyUnit: 'تومان',
  defaultConversionRate: 3.0,
  saleCommissionRateBuyer: 0.25,
  saleCommissionRateSeller: 0.25,
  rentCommissionDays: 7,
  vatPercent: 10,
  agentCommissionSharePercent: 50,
  licenseNumber: 'الف/۹۸۴۳۲۱'
};

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'amlak.db');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');

// Ensure system directories exist
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

let dbInstance: DatabaseSync | null = null;

export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const generatedSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, generatedSalt, 1000, 64, 'sha512').toString('hex');
  return { hash, salt: generatedSalt };
}

export function getDatabase(): DatabaseSync {
  if (dbInstance) return dbInstance;

  dbInstance = new DatabaseSync(DB_PATH);

  // Performance and integrity pragmas
  dbInstance.exec('PRAGMA journal_mode = WAL;');
  dbInstance.exec('PRAGMA synchronous = NORMAL;');
  dbInstance.exec('PRAGMA foreign_keys = ON;');

  initMigrations(dbInstance);
  seedInitialData(dbInstance);
  ensureCoreTenantsAndUsers(dbInstance);

  return dbInstance;
}

function initMigrations(db: DatabaseSync) {
  // Ensure migrations tracking table
  db.exec(`
    CREATE TABLE IF NOT EXISTS _migrations (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL
    );
  `);

  const appliedRows = db.prepare('SELECT id FROM _migrations').all() as { id: number }[];
  const appliedIds = new Set(appliedRows.map((r) => r.id));

  for (const migration of migrations) {
    if (!appliedIds.has(migration.id)) {
      console.log(`[Migration] Running ${migration.name}...`);
      // Pre-migration snapshot before schema altering
      if (fs.existsSync(DB_PATH) && fs.statSync(DB_PATH).size > 0) {
        createBackupInternal(db, 'pre_migration', `قبل از اجرای مایگریشن ${migration.name}`);
      }

      migration.up(db);

      const stmt = db.prepare('INSERT INTO _migrations (id, name, applied_at) VALUES (?, ?, ?)');
      stmt.run(migration.id, migration.name, new Date().toISOString());
      console.log(`[Migration] Successfully applied ${migration.name}`);
    }
  }
}

export function createBackupInternal(db: DatabaseSync, type: 'auto' | 'manual' | 'pre_migration', note?: string): string {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `backup-${type}-${timestamp}.db`;
  const destPath = path.join(BACKUP_DIR, filename);

  try {
    // Copy active DB file securely
    if (fs.existsSync(DB_PATH)) {
      fs.copyFileSync(DB_PATH, destPath);
      const stat = fs.statSync(destPath);

      // Ensure table exists
      db.exec(`
        CREATE TABLE IF NOT EXISTS system_backups (
          id TEXT PRIMARY KEY,
          tenant_id TEXT,
          filename TEXT NOT NULL,
          filepath TEXT NOT NULL,
          filesize INTEGER NOT NULL,
          backup_type TEXT NOT NULL,
          checksum TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'ready'
        );
      `);

      const backupId = crypto.randomUUID();
      const stmt = db.prepare(`
        INSERT INTO system_backups (id, tenant_id, filename, filepath, filesize, backup_type, created_at, updated_at, status)
        VALUES (?, NULL, ?, ?, ?, ?, ?, ?, 'ready')
      `);
      stmt.run(
        backupId,
        filename,
        destPath,
        stat.size,
        type,
        new Date().toISOString(),
        new Date().toISOString()
      );
      return destPath;
    }
  } catch (err) {
    console.error('[Backup Error]', err);
  }
  return '';
}

function seedInitialData(db: DatabaseSync) {
  const tenantCount = (db.prepare('SELECT COUNT(*) as count FROM tenants').get() as any)?.count || 0;
  if (tenantCount > 0) return;

  console.log('[Seed] Initializing multi-tenant real estate agencies and migrating data...');

  const now = new Date().toISOString();

  // 1. Create Primary Real Estate Agency (Tenant 1)
  const tenant1Id = 'tenant-negin-1';
  const tenant1Settings = JSON.stringify(defaultTenantSettings);
  db.prepare(`
    INSERT INTO tenants (
      id, name, slug, license_number, manager_name, phone, email, city, address,
      subscription_plan, subscription_status, max_users, max_properties, settings_json,
      created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    tenant1Id,
    'املاک نگین پایتخت',
    'negin-paytakht',
    'الف/۹۸۴۳۲۱',
    'مهندس علی رضایی',
    '02122003344',
    'info@negin-amlak.ir',
    'تهران',
    'سعادت‌آباد، میدان کاج، نبش خیابان مروارید',
    'enterprise',
    'active',
    50,
    5000,
    tenant1Settings,
    now,
    now,
    'active'
  );

  // 2. Create Secondary Real Estate Agency (Tenant 2 - for multi-tenant isolation demonstration)
  const tenant2Id = 'tenant-zaferanieh-2';
  const tenant2Settings = JSON.stringify({
    ...defaultTenantSettings,
    agencyName: 'املاک بزرگ زعفرانیه',
    managerName: 'دکتر محمدرضا شایگان',
    phone: '02122446688',
    address: 'زعفرانیه، خیابان اعجازی (آصف)، پلاک ۴۸',
    license_number: 'ب/۷۷۵۵۴۴'
  });
  db.prepare(`
    INSERT INTO tenants (
      id, name, slug, license_number, manager_name, phone, email, city, address,
      subscription_plan, subscription_status, max_users, max_properties, settings_json,
      created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    tenant2Id,
    'املاک بزرگ زعفرانیه',
    'zaferanieh-group',
    'ب/۷۷۵۵۴۴',
    'دکتر محمدرضا شایگان',
    '02122446688',
    'zaferanieh@estate.ir',
    'تهران',
    'زعفرانیه، خیابان اعجازی (آصف)، پلاک ۴۸',
    'premium',
    'active',
    25,
    2500,
    tenant2Settings,
    now,
    now,
    'active'
  );

  // 3. Super Admin User (Platform level)
  const { hash: superHash, salt: superSalt } = hashPassword('admin123456');
  db.prepare(`
    INSERT INTO users (
      id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
      phone, email, is_active, created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
  `).run(
    'usr-superadmin',
    tenant1Id,
    'superadmin',
    superHash,
    superSalt,
    'مدیر ارشد سامانه (Super Admin)',
    'super_admin',
    JSON.stringify(['*']),
    '09120000000',
    'superadmin@amlaksaas.ir',
    now,
    now
  );

  // 4. Agency 1 Users
  const { hash: owner1Hash, salt: owner1Salt } = hashPassword('123456');
  db.prepare(`
    INSERT INTO users (
      id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
      phone, email, is_active, created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
  `).run(
    'usr-owner-1',
    tenant1Id,
    'ali_rezaei',
    owner1Hash,
    owner1Salt,
    'مهندس علی رضایی',
    'owner',
    JSON.stringify(['properties.*', 'customers.*', 'contracts.*', 'finances.*', 'users.*', 'settings.*']),
    '09121112233',
    'ali@negin-amlak.ir',
    now,
    now
  );

  // Additional Agents for Tenant 1
  const seedAgents = [
    { id: '2', username: 'reza_kabiri', fullName: 'رضا کبیری', role: 'agent', phone: '09123334455' },
    { id: '3', username: 'sara_abbasi', fullName: 'سارا عباسی', role: 'agent', phone: '09124445566' },
    { id: '4', username: 'mehdi_rostami', fullName: 'مهدی رستمی', role: 'agent', phone: '09125556677' }
  ];

  for (const u of seedAgents) {
    const { hash: uHash, salt: uSalt } = hashPassword('123456');
    db.prepare(`
      INSERT INTO users (
        id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
        phone, is_active, created_at, updated_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
    `).run(
      `usr-${u.id}`,
      tenant1Id,
      u.username,
      uHash,
      uSalt,
      u.fullName,
      u.role === 'admin' ? 'manager' : u.role,
      JSON.stringify(['properties.view', 'properties.create', 'properties.edit', 'customers.view', 'customers.create']),
      u.phone,
      now,
      now
    );
  }

  // Agency 2 Users (Completely isolated)
  const { hash: owner2Hash, salt: owner2Salt } = hashPassword('123456');
  db.prepare(`
    INSERT INTO users (
      id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
      phone, email, is_active, created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
  `).run(
    'usr-owner-2',
    tenant2Id,
    'shaygan',
    owner2Hash,
    owner2Salt,
    'دکتر محمدرضا شایگان',
    'owner',
    JSON.stringify(['*']),
    '09128889900',
    'shaygan@zaferanieh.ir',
    now,
    now
  );

  // 5. Seed Properties into Tenant 1
  const propStmt = db.prepare(`
    INSERT INTO properties (
      id, tenant_id, code, title, property_type, deal_type, area, rooms, floor, total_floors,
      year_built, sale_price, price_per_meter, mortgage_price, rent_price, address, city, district,
      description, features_json, images_json, documents_json, owner_name, owner_phone,
      assigned_agent_name, is_favorite, created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const seedProperties = [
    {
      id: 'prop-1',
      code: 'الف-۱۰۱',
      title: 'آپارتمان ۱۴۰ متری نوساز کلید نخورده',
      propertyType: 'apartment',
      dealType: 'sale',
      area: 140,
      rooms: 3,
      floor: 4,
      totalFloors: 5,
      yearBuilt: 1402,
      salePrice: 16800000000,
      pricePerMeter: 120000000,
      mortgagePrice: null,
      rentPrice: null,
      address: 'سعادت‌آباد، علامه شمالی، خیابان بیستم',
      city: 'تهران',
      district: 'سعادت‌آباد',
      description: 'نورگیر عالی از دو جهت، متریال درجه یک، آشپزخانه فرنیش، لابی مجلل و سرایداری مقیم.',
      features: ['پارکینگ سندی', 'انباری', 'آسانسور', 'بالکن', 'لابی'],
      images: [],
      ownerName: 'آقای تهرانی',
      ownerPhone: '09121114455',
      assignedAgentName: 'رضا کبیری',
      isFavorite: 1,
      status: 'active'
    },
    {
      id: 'prop-2',
      code: 'الف-۱۰۲',
      title: 'واحد ۱۱۰ متری دو خوابه فول بازسازی',
      propertyType: 'apartment',
      dealType: 'rent',
      area: 110,
      rooms: 2,
      floor: 2,
      totalFloors: 4,
      yearBuilt: 1395,
      salePrice: null,
      pricePerMeter: null,
      mortgagePrice: 800000000,
      rentPrice: 28000000,
      address: 'شهرک غرب، بلوار دادمان، خیابان درختی',
      city: 'تهران',
      district: 'شهرک غرب',
      description: 'لوکیشن دنج و آرام، دسترسی عالی به مراکز خرید، نقشه مهندسی بدون پرتی.',
      features: ['پارکینگ', 'انباری', 'آسانسور', 'اسپلیت'],
      images: [],
      ownerName: 'خانم پیروز',
      ownerPhone: '09122225566',
      assignedAgentName: 'سارا عباسی',
      isFavorite: 0,
      status: 'active'
    }
  ];

  for (const p of seedProperties) {
    propStmt.run(
      p.id,
      tenant1Id,
      p.code,
      p.title,
      p.propertyType,
      p.dealType,
      p.area,
      p.rooms,
      p.floor || null,
      p.totalFloors || null,
      p.yearBuilt || null,
      p.salePrice || null,
      p.pricePerMeter || null,
      p.mortgagePrice || null,
      p.rentPrice || null,
      p.address,
      p.city,
      p.district,
      p.description,
      JSON.stringify(p.features || []),
      JSON.stringify(p.images || []),
      JSON.stringify([]),
      p.ownerName || null,
      p.ownerPhone || null,
      p.assignedAgentName || null,
      p.isFavorite ? 1 : 0,
      now,
      now,
      p.status
    );
  }

  // Seed sample distinct property in Tenant 2 to demonstrate strict isolation
  propStmt.run(
    'prop-zaf-101',
    tenant2Id,
    'زعفرانیه-۳۰۱',
    'پنت‌هاوس مجلل ۴۵۰ متری با دید ابدی توچال',
    'penthouse',
    'sale',
    450,
    4,
    14,
    14,
    1402,
    135000000000,
    300000000,
    null,
    null,
    'زعفرانیه، خیابان ثارالله',
    'تهران',
    'زعفرانیه',
    'برج باغ سوپرلوکس، استخر اختصاصی داخل واحد، هلی‌پد، متریال تماماً ایتالیایی',
    JSON.stringify(['استخر', 'سونا', 'جکوزی', 'هلی‌پد', 'لابی‌من ۲۴ ساعته', '۴ پارکینگ سندی']),
    JSON.stringify([]),
    JSON.stringify([]),
    'مهندس صدر',
    '09123334455',
    'دکتر محمدرضا شایگان',
    1,
    now,
    now,
    'active'
  );

  // 6. Seed Customers into Tenant 1
  const custStmt = db.prepare(`
    INSERT INTO customers (
      id, tenant_id, full_name, phone, email, customer_type, deal_type,
      preferred_property_types_json, min_area, max_area, min_rooms, preferred_districts_json,
      budget_min, budget_max, mortgage_max, rent_max, notes, last_contact_date,
      created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const seedCustomers = [
    {
      id: 'cust-1',
      fullName: 'دکتر علیرضا محمدی',
      phone: '09121234567',
      email: 'dr.mohammadi@example.ir',
      customerType: 'buyer',
      dealType: 'buy',
      preferredPropertyTypes: ['apartment'],
      minArea: 130,
      maxArea: 160,
      minRooms: 3,
      preferredDistricts: ['سعادت‌آباد', 'شهرک غرب'],
      budgetMin: 15000000000,
      budgetMax: 18000000000,
      notes: 'خریدار نقدی، به دنبال واحد نوساز با نور مستقیم و لابی شیک.',
      status: 'active'
    }
  ];

  for (const c of seedCustomers) {
    custStmt.run(
      c.id,
      tenant1Id,
      c.fullName,
      c.phone,
      c.email || null,
      c.customerType,
      c.dealType,
      JSON.stringify(c.preferredPropertyTypes || []),
      c.minArea || null,
      c.maxArea || null,
      c.minRooms || null,
      JSON.stringify(c.preferredDistricts || []),
      c.budgetMin || null,
      c.budgetMax || null,
      null,
      null,
      c.notes || null,
      now,
      now,
      now,
      c.status
    );
  }

  // Seed sample distinct customer in Tenant 2
  custStmt.run(
    'cust-zaf-201',
    tenant2Id,
    'دکتر کامران شریفی',
    '09124445566',
    'sharifi@med.ir',
    'buyer',
    'buy',
    JSON.stringify(['penthouse', 'apartment']),
    350,
    500,
    4,
    JSON.stringify(['زعفرانیه', 'محمودیه', 'فرمانیه']),
    100000000000,
    150000000000,
    null,
    null,
    'متقاضی نقد پنت‌هاوس با تراس گاردن قابل چیدمان در زعفرانیه',
    now,
    now,
    now,
    'active'
  );

  // 7. Seed Tasks & FollowUps
  const taskStmt = db.prepare(`
    INSERT INTO follow_ups (
      id, tenant_id, title, customer_id, customer_name, property_id, property_title,
      due_date, due_time, priority, notes, created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const seedFollowUps = [
    {
      id: 'fu-1',
      title: 'هماهنگی بازدید آپارتمان ۱۴۰ متری',
      customerId: 'cust-1',
      customerName: 'دکتر علیرضا محمدی',
      propertyId: 'prop-1',
      propertyTitle: 'آپارتمان ۱۴۰ متری نوساز کلید نخورده',
      dueDate: '1403/07/15',
      dueTime: '17:30',
      priority: 'high',
      notes: 'تماس با مالک آقای تهرانی جهت دریافت کلید قبل از ساعت ۵ عصر.',
      status: 'pending'
    }
  ];

  for (const f of seedFollowUps) {
    taskStmt.run(
      f.id,
      tenant1Id,
      f.title,
      f.customerId || null,
      f.customerName || null,
      f.propertyId || null,
      f.propertyTitle || null,
      f.dueDate,
      f.dueTime || '12:00',
      f.priority,
      f.notes || null,
      now,
      now,
      f.status
    );
  }

  // 8. Seed Contracts and Financial Transactions
  const contractStmt = db.prepare(`
    INSERT INTO contracts (
      id, tenant_id, contract_number, deal_type, property_id, customer_id,
      owner_name, client_name, total_amount, mortgage_amount, rent_amount,
      commission_total, agency_share, agent_share, agent_name, tax_amount,
      contract_date, payment_status, notes, created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const financeStmt = db.prepare(`
    INSERT INTO financial_transactions (
      id, tenant_id, contract_id, type, category, title, amount,
      payment_method, date, agent_name, description, created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const seedCommissions = [
    {
      id: 'comm-1',
      contractNum: 'CR-1403-101',
      dealType: 'sale',
      propertyTitle: 'آپارتمان ۱۴۰ متری سعادت‌آباد',
      customerName: 'دکتر علیرضا محمدی',
      dealAmount: 16800000000,
      mortgageAmount: 0,
      rentAmount: 0,
      commissionTotal: 84000000,
      agencyShare: 42000000,
      agentShare: 42000000,
      agentName: 'رضا کبیری',
      taxAmount: 8400000,
      date: '1403/06/20',
      notes: 'تسویه کامل کمیسیون قرارداد فروش'
    }
  ];

  for (let i = 0; i < seedCommissions.length; i++) {
    const c = seedCommissions[i];
    const contractId = `cnt-${c.id}`;
    const contractNum = c.contractNum;

    contractStmt.run(
      contractId,
      tenant1Id,
      contractNum,
      c.dealType,
      null,
      null,
      'مالک محترم',
      c.customerName,
      c.dealAmount,
      c.mortgageAmount || 0,
      c.rentAmount || 0,
      c.commissionTotal,
      c.agencyShare,
      c.agentShare,
      c.agentName,
      c.taxAmount,
      c.date,
      'paid',
      c.notes || 'تسویه کامل کمیسیون',
      now,
      now,
      'completed'
    );

    financeStmt.run(
      `fin-inc-${c.id}`,
      tenant1Id,
      contractId,
      'income',
      'deal_commission',
      `کمیسیون قرارداد ${contractNum} (${c.propertyTitle})`,
      c.commissionTotal,
      'bank_transfer',
      c.date,
      c.agentName,
      `دریافت وجه کمیسیون معامله`,
      now,
      now,
      'completed'
    );

    financeStmt.run(
      `fin-exp-${c.id}`,
      tenant1Id,
      contractId,
      'expense',
      'salary',
      `پرداخت پورسانت مشاور ${c.agentName} برای قرارداد ${contractNum}`,
      c.agentShare,
      'bank_transfer',
      c.date,
      c.agentName,
      `تسویه پورسانت سهم مشاور معامله`,
      now,
      now,
      'completed'
    );
  }

  // 9. Seed Initial Activity Logs
  const actStmt = db.prepare(`
    INSERT INTO activity_logs (
      id, tenant_id, user_id, user_name, action, title, description,
      timestamp, created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'logged')
  `);

  actStmt.run(
    'act-init-1',
    tenant1Id,
    'usr-owner-1',
    'مهندس علی رضایی',
    'create_property',
    'راه‌اندازی سامانه املاک',
    'پایگاه داده سامانه با موفقیت مستقر شد و پایگاه داده ایزوله برای آژانس ایجاد گردید.',
    now,
    now,
    now
  );

  console.log('[Seed] Multi-tenant initialization successfully finished.');
}

function ensureCoreTenantsAndUsers(db: DatabaseSync) {
  const now = new Date().toISOString();

  // 1. Ensure Super Admin user exists
  const superAdmin = db.prepare("SELECT id FROM users WHERE username = 'superadmin'").get() as any;
  if (!superAdmin) {
    const { hash, salt } = hashPassword('admin123456');
    db.prepare(`
      INSERT INTO users (
        id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
        phone, email, is_active, created_at, updated_at, status
      ) VALUES (?, 'tenant-system', 'superadmin', ?, ?, 'مدیر ارشد سامانه (Super Admin)', 'super_admin', ?, '09120000000', 'admin@amlaksaas.ir', 1, ?, ?, 'active')
    `).run('usr-superadmin', hash, salt, JSON.stringify(['*']), now, now);
  }

  // 2. Real Estate A: "املاک شهر" ("Shahr Real Estate" - slug: shahr_realestate)
  const tenantShahr = db.prepare("SELECT id FROM tenants WHERE slug = 'shahr_realestate'").get() as any;
  if (!tenantShahr) {
    const shahrId = 'tenant-shahr';
    const shahrSettings = JSON.stringify({
      ...defaultTenantSettings,
      agencyName: 'املاک شهر',
      managerName: 'علی رحمانی',
      phone: '02188776655',
      address: 'شهرک غرب، بلوار دادمان، خیابان هرمزان، پلاک ۳۲',
      license_number: 'ش/۳۳۴۴۵۵'
    });

    db.prepare(`
      INSERT INTO tenants (
        id, name, slug, license_number, manager_name, phone, email, city, address,
        subscription_plan, subscription_status, max_users, max_properties, settings_json,
        created_at, updated_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      shahrId,
      'املاک شهر',
      'shahr_realestate',
      'ش/۳۳۴۴۵۵',
      'علی رحمانی',
      '02188776655',
      'info@shahr-estate.ir',
      'تهران',
      'شهرک غرب، بلوار دادمان، خیابان هرمزان، پلاک ۳۲',
      'premium',
      'active',
      20,
      2000,
      shahrSettings,
      now,
      now,
      'active'
    );

    // Owner: Ali (ali_shahr / password123)
    const { hash: aliHash, salt: aliSalt } = hashPassword('password123');
    db.prepare(`
      INSERT INTO users (
        id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
        phone, email, is_active, created_at, updated_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
    `).run(
      'usr-shahr-ali',
      shahrId,
      'ali_shahr',
      aliHash,
      aliSalt,
      'علی رحمانی (مدیر املاک شهر)',
      'owner',
      JSON.stringify(['*']),
      '09121002030',
      'ali@shahr-estate.ir',
      now,
      now
    );

    // Employee 1: Sara (sara_crm / password123) -> Can manage customers
    const { hash: saraHash, salt: saraSalt } = hashPassword('password123');
    db.prepare(`
      INSERT INTO users (
        id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
        phone, is_active, created_at, updated_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
    `).run(
      'usr-shahr-sara',
      shahrId,
      'sara_crm',
      saraHash,
      saraSalt,
      'سارا عباسی (مشاور امور مشتریان)',
      'agent',
      JSON.stringify(['customers:manage', 'followups:manage', 'properties:view']),
      '09123004050',
      now,
      now
    );

    // Employee 2: Reza (reza_properties / password123) -> Can add/edit properties
    const { hash: rezaHash, salt: rezaSalt } = hashPassword('password123');
    db.prepare(`
      INSERT INTO users (
        id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
        phone, is_active, created_at, updated_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
    `).run(
      'usr-shahr-reza',
      shahrId,
      'reza_properties',
      rezaHash,
      rezaSalt,
      'رضا کبیری (کارشناس ثبت ملک)',
      'agent',
      JSON.stringify(['properties:create', 'properties:edit', 'properties:view']),
      '09125006070',
      now,
      now
    );

    // Seed Properties for Shahr Real Estate
    db.prepare(`
      INSERT INTO properties (
        id, tenant_id, code, title, property_type, deal_type, area, rooms, floor, total_floors,
        year_built, sale_price, price_per_meter, mortgage_price, rent_price, address, city, district,
        description, features_json, images_json, owner_name, owner_phone, assigned_agent_name, is_favorite, created_at, updated_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
    `).run(
      'prop-shahr-1',
      shahrId,
      'شهر-۱۰۱',
      'آپارتمان ۱۶۵ متری ۳ خوابه ویو بوستان دادمان',
      'apartment',
      'sale',
      165,
      3,
      5,
      6,
      1401,
      23100000000,
      140000000,
      null,
      null,
      'شهرک غرب، فاز ۱، خیابان مهستان',
      'تهران',
      'شهرک غرب',
      'ساختمان برند و مهندسی‌ساز، دو پارکینگ سندی باکس، متریال اروپایی، نورگیر مستقیم.',
      JSON.stringify(['۲ پارکینگ سندی', 'آسانسور کدینگ', 'انباری ۱۰ متری', 'بالکن قابل چیدمان', 'لابی مجلل']),
      JSON.stringify([]),
      'آقای ناصری',
      '09127778899',
      'رضا کبیری',
      now,
      now
    );

    db.prepare(`
      INSERT INTO properties (
        id, tenant_id, code, title, property_type, deal_type, area, rooms, floor, total_floors,
        year_built, sale_price, price_per_meter, mortgage_price, rent_price, address, city, district,
        description, features_json, images_json, owner_name, owner_phone, assigned_agent_name, is_favorite, created_at, updated_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
    `).run(
      'prop-shahr-2',
      shahrId,
      'شهر-۱۰۲',
      'واحد اداری ۱۱۰ متری بر بلوار پاکنژاد',
      'office',
      'rent',
      110,
      3,
      2,
      5,
      1398,
      null,
      null,
      500000000,
      45000000,
      'سعادت‌آباد، تقاطع بلوار دریا و پاکنژاد',
      'تهران',
      'سعادت‌آباد',
      'موقعیت ۱۰۰٪ اداری و تابلوخور عالی، لابی اداری، مناسب مطب، وکالت و دفاتر مهندسی.',
      JSON.stringify(['پارکینگ اختصاصی', 'آسانسور', 'دید بلوار اصلی', 'سیستم حریق']),
      JSON.stringify([]),
      'خانم صیرفی',
      '09128881122',
      'سارا عباسی',
      now,
      now
    );

    // Seed customer for Shahr Real Estate
    db.prepare(`
      INSERT INTO customers (
        id, tenant_id, full_name, phone, customer_type, preferred_property_types_json, deal_type, budget_min, budget_max,
        preferred_districts_json, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)
    `).run(
      'cust-shahr-1',
      shahrId,
      'دکتر آرش مقصودی',
      '09124445566',
      'buyer',
      JSON.stringify(['apartment']),
      'buy',
      20000000000,
      25000000000,
      JSON.stringify(['شهرک غرب', 'سعادت‌آباد']),
      now,
      now
    );
  }

  // 3. Real Estate B: "املاک مدرن" ("Modern Real Estate" - slug: modern_realestate)
  const tenantModern = db.prepare("SELECT id FROM tenants WHERE slug = 'modern_realestate'").get() as any;
  if (!tenantModern) {
    const modernId = 'tenant-modern';
    const modernSettings = JSON.stringify({
      ...defaultTenantSettings,
      agencyName: 'املاک مدرن',
      managerName: 'رضا حسینی',
      phone: '02122667788',
      address: 'الهیه، خیابان فرشته، مرکز خرید کوئین سنتر، طبقه ۵',
      license_number: 'م/۹۹۸۸۷۷'
    });

    db.prepare(`
      INSERT INTO tenants (
        id, name, slug, license_number, manager_name, phone, email, city, address,
        subscription_plan, subscription_status, max_users, max_properties, settings_json,
        created_at, updated_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      modernId,
      'املاک مدرن',
      'modern_realestate',
      'م/۹۹۸۸۷۷',
      'رضا حسینی',
      '02122667788',
      'contact@modern-estate.ir',
      'تهران',
      'الهیه، خیابان فرشته، مرکز خرید کوئین سنتر، طبقه ۵',
      'enterprise',
      'active',
      30,
      3000,
      modernSettings,
      now,
      now,
      'active'
    );

    // Owner: Reza (reza_modern / password123)
    const { hash: rezaModHash, salt: rezaModSalt } = hashPassword('password123');
    db.prepare(`
      INSERT INTO users (
        id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
        phone, email, is_active, created_at, updated_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
    `).run(
      'usr-modern-reza',
      modernId,
      'reza_modern',
      rezaModHash,
      rezaModSalt,
      'رضا حسینی (مدیر املاک مدرن)',
      'owner',
      JSON.stringify(['*']),
      '09127008090',
      'reza@modern-estate.ir',
      now,
      now
    );

    // Employee 1: Arash (arash_modern / password123)
    const { hash: arashHash, salt: arashSalt } = hashPassword('password123');
    db.prepare(`
      INSERT INTO users (
        id, tenant_id, username, password_hash, salt, full_name, role, permissions_json,
        phone, is_active, created_at, updated_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
    `).run(
      'usr-modern-arash',
      modernId,
      'arash_modern',
      arashHash,
      arashSalt,
      'آرش نوری (کارشناس ارشد فروش)',
      'agent',
      JSON.stringify(['properties:create', 'properties:edit', 'properties:view', 'customers:manage']),
      '09129001020',
      now,
      now
    );

    // Seed Properties for Modern Real Estate
    db.prepare(`
      INSERT INTO properties (
        id, tenant_id, code, title, property_type, deal_type, area, rooms, floor, total_floors,
        year_built, sale_price, price_per_meter, mortgage_price, rent_price, address, city, district,
        description, features_json, images_json, owner_name, owner_phone, assigned_agent_name, is_favorite, created_at, updated_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 'active')
    `).run(
      'prop-modern-1',
      modernId,
      'مدرن-۲۰۰',
      'پنت‌هاوس مجلل ۳۲۰ متری در فرشته با استخر روباز اختصاصی',
      'penthouse',
      'sale',
      320,
      4,
      12,
      12,
      1402,
      96000000000,
      300000000,
      null,
      null,
      'الهیه، خیابان فرشته، خیابان چناران',
      'تهران',
      'الهیه',
      'معماری پست‌مدرن، طراحی آرشیتکت مطرح بین‌المللی، استخر معلق شیشه‌ای، هلی‌پد و لابی‌من ۳ شیفت.',
      JSON.stringify(['استخر معلق', 'روف‌گاردن', '۴ پارکینگ سندی باکس', 'سیستم تمام هوشمند']),
      JSON.stringify([]),
      'دکتر شمس',
      '09123332211',
      'آرش نوری',
      now,
      now
    );
  }
}
