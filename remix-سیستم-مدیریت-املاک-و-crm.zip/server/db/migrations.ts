import { DatabaseSync } from 'node:sqlite';

export interface Migration {
  id: number;
  name: string;
  up: (db: DatabaseSync) => void;
}

export const migrations: Migration[] = [
  {
    id: 1,
    name: '001_initial_multitenant_schema',
    up: (db: DatabaseSync) => {
      // 1. Tenancy table (Real Estate Agencies)
      db.exec(`
        CREATE TABLE IF NOT EXISTS tenants (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          slug TEXT UNIQUE NOT NULL,
          license_number TEXT,
          manager_name TEXT NOT NULL,
          phone TEXT NOT NULL,
          email TEXT,
          city TEXT DEFAULT 'تهران',
          address TEXT,
          subscription_plan TEXT DEFAULT 'standard', -- 'trial', 'standard', 'premium', 'enterprise'
          subscription_status TEXT DEFAULT 'active', -- 'active', 'expired', 'suspended'
          subscription_expires_at TEXT,
          max_users INTEGER DEFAULT 10,
          max_properties INTEGER DEFAULT 1000,
          settings_json TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'active'
        );
        CREATE INDEX IF NOT EXISTS idx_tenants_slug ON tenants(slug);
        CREATE INDEX IF NOT EXISTS idx_tenants_status ON tenants(status);
      `);

      // 2. Users table with granular roles & custom permissions
      db.exec(`
        CREATE TABLE IF NOT EXISTS users (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          username TEXT NOT NULL,
          password_hash TEXT NOT NULL,
          salt TEXT NOT NULL,
          full_name TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'agent', -- 'super_admin', 'owner', 'manager', 'agent'
          permissions_json TEXT, -- custom granular permissions override
          phone TEXT NOT NULL,
          email TEXT,
          avatar_url TEXT,
          is_active INTEGER DEFAULT 1,
          last_login_at TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'active',
          FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
          UNIQUE(tenant_id, username)
        );
        CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);
        CREATE INDEX IF NOT EXISTS idx_users_role ON users(tenant_id, role);
      `);

      // 3. User Login & Audit History
      db.exec(`
        CREATE TABLE IF NOT EXISTS login_history (
          id TEXT PRIMARY KEY,
          tenant_id TEXT,
          user_id TEXT,
          username TEXT NOT NULL,
          ip_address TEXT,
          user_agent TEXT,
          status TEXT NOT NULL, -- 'success', 'failed'
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_login_history_tenant ON login_history(tenant_id, created_at);
      `);

      // 4. Properties table (Fully normalized & indexed)
      db.exec(`
        CREATE TABLE IF NOT EXISTS properties (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          code TEXT NOT NULL,
          title TEXT NOT NULL,
          property_type TEXT NOT NULL, -- 'apartment', 'villa', 'commercial', 'office', 'land', 'penthouse'
          deal_type TEXT NOT NULL, -- 'sale', 'rent', 'presale'
          area REAL NOT NULL,
          rooms INTEGER NOT NULL,
          floor INTEGER,
          total_floors INTEGER,
          year_built INTEGER,
          sale_price REAL,
          price_per_meter REAL,
          mortgage_price REAL,
          rent_price REAL,
          address TEXT NOT NULL,
          city TEXT NOT NULL DEFAULT 'تهران',
          district TEXT NOT NULL,
          description TEXT,
          features_json TEXT,
          images_json TEXT,
          documents_json TEXT,
          owner_name TEXT,
          owner_phone TEXT,
          assigned_agent_id TEXT,
          assigned_agent_name TEXT,
          is_favorite INTEGER DEFAULT 0,
          views_count INTEGER DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'active', -- 'active', 'negotiating', 'sold', 'rented', 'archived'
          FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
          UNIQUE(tenant_id, code)
        );
        CREATE INDEX IF NOT EXISTS idx_properties_tenant_status ON properties(tenant_id, status);
        CREATE INDEX IF NOT EXISTS idx_properties_tenant_type ON properties(tenant_id, property_type, deal_type);
        CREATE INDEX IF NOT EXISTS idx_properties_tenant_district ON properties(tenant_id, district);
        CREATE INDEX IF NOT EXISTS idx_properties_tenant_created ON properties(tenant_id, created_at);
      `);

      // 5. Customers CRM table
      db.exec(`
        CREATE TABLE IF NOT EXISTS customers (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          full_name TEXT NOT NULL,
          phone TEXT NOT NULL,
          email TEXT,
          customer_type TEXT NOT NULL, -- 'buyer', 'tenant', 'seller', 'landlord', 'investor'
          deal_type TEXT NOT NULL, -- 'buy', 'rent', 'sell', 'let'
          preferred_property_types_json TEXT,
          min_area REAL,
          max_area REAL,
          min_rooms INTEGER,
          preferred_districts_json TEXT,
          budget_min REAL,
          budget_max REAL,
          mortgage_max REAL,
          rent_max REAL,
          notes TEXT,
          assigned_agent_id TEXT,
          last_contact_date TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'active', -- 'active', 'in_progress', 'deal_closed', 'cancelled'
          FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_customers_tenant_type ON customers(tenant_id, customer_type, status);
        CREATE INDEX IF NOT EXISTS idx_customers_tenant_phone ON customers(tenant_id, phone);
      `);

      // 6. Customer Interactions & Timeline
      db.exec(`
        CREATE TABLE IF NOT EXISTS customer_interactions (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          customer_id TEXT NOT NULL,
          customer_name TEXT,
          user_id TEXT,
          type TEXT NOT NULL, -- 'call', 'visit', 'meeting', 'message'
          date TEXT NOT NULL,
          notes TEXT NOT NULL,
          result TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'completed',
          FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
          FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_interactions_tenant_customer ON customer_interactions(tenant_id, customer_id);
      `);

      // 7. Contracts (Sales, Rental, Pre-sale Deals)
      db.exec(`
        CREATE TABLE IF NOT EXISTS contracts (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          contract_number TEXT NOT NULL,
          deal_type TEXT NOT NULL, -- 'sale', 'rent', 'presale'
          property_id TEXT,
          customer_id TEXT,
          owner_name TEXT NOT NULL,
          owner_phone TEXT,
          client_name TEXT NOT NULL,
          client_phone TEXT,
          total_amount REAL DEFAULT 0,
          mortgage_amount REAL DEFAULT 0,
          rent_amount REAL DEFAULT 0,
          commission_total REAL DEFAULT 0,
          agency_share REAL DEFAULT 0,
          agent_share REAL DEFAULT 0,
          agent_id TEXT,
          agent_name TEXT,
          tax_amount REAL DEFAULT 0,
          contract_date TEXT NOT NULL,
          start_date TEXT,
          end_date TEXT,
          payment_status TEXT DEFAULT 'pending', -- 'pending', 'partial', 'paid'
          notes TEXT,
          documents_json TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'active', -- 'draft', 'active', 'terminated', 'completed'
          FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
          UNIQUE(tenant_id, contract_number)
        );
        CREATE INDEX IF NOT EXISTS idx_contracts_tenant_status ON contracts(tenant_id, status);
        CREATE INDEX IF NOT EXISTS idx_contracts_tenant_date ON contracts(tenant_id, contract_date);
      `);

      // 8. Financial Transactions (Accounting, Income, Expenses, Commissions)
      db.exec(`
        CREATE TABLE IF NOT EXISTS financial_transactions (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          contract_id TEXT,
          type TEXT NOT NULL, -- 'income', 'expense', 'commission'
          category TEXT NOT NULL, -- 'deal_commission', 'office_rent', 'utility', 'marketing', 'salary', 'tax', 'other'
          title TEXT NOT NULL,
          amount REAL NOT NULL,
          payment_method TEXT DEFAULT 'bank_transfer', -- 'cash', 'bank_transfer', 'cheque', 'pos'
          reference_number TEXT,
          date TEXT NOT NULL,
          agent_id TEXT,
          agent_name TEXT,
          description TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'completed',
          FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
          FOREIGN KEY (contract_id) REFERENCES contracts(id) ON DELETE SET NULL
        );
        CREATE INDEX IF NOT EXISTS idx_finance_tenant_type ON financial_transactions(tenant_id, type, date);
      `);

      // 9. Follow-Ups & Tasks
      db.exec(`
        CREATE TABLE IF NOT EXISTS follow_ups (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          title TEXT NOT NULL,
          customer_id TEXT,
          customer_name TEXT,
          property_id TEXT,
          property_title TEXT,
          assigned_agent_id TEXT,
          due_date TEXT NOT NULL,
          due_time TEXT,
          priority TEXT DEFAULT 'medium', -- 'high', 'medium', 'low'
          notes TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'pending', -- 'pending', 'completed', 'cancelled'
          FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_follow_ups_tenant_date ON follow_ups(tenant_id, due_date, status);
      `);

      // 10. Mortgage/Rent Conversion records
      db.exec(`
        CREATE TABLE IF NOT EXISTS conversions (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          mortgage REAL NOT NULL,
          rent REAL NOT NULL,
          rate_percent REAL NOT NULL,
          full_mortgage REAL NOT NULL,
          full_rent REAL NOT NULL,
          date TEXT NOT NULL,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'active',
          FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_conversions_tenant ON conversions(tenant_id);
      `);

      // 11. Activity Logs (Audit Trail for Enterprise Compliance: Who, When, What)
      db.exec(`
        CREATE TABLE IF NOT EXISTS activity_logs (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          user_id TEXT,
          user_name TEXT,
          action TEXT NOT NULL,
          title TEXT NOT NULL,
          description TEXT NOT NULL,
          entity_type TEXT,
          entity_id TEXT,
          diff_json TEXT,
          ip_address TEXT,
          timestamp TEXT NOT NULL,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'logged',
          FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_activity_tenant ON activity_logs(tenant_id, timestamp DESC);
      `);

      // 12. System Backups log
      db.exec(`
        CREATE TABLE IF NOT EXISTS system_backups (
          id TEXT PRIMARY KEY,
          tenant_id TEXT,
          filename TEXT NOT NULL,
          filepath TEXT NOT NULL,
          filesize INTEGER NOT NULL,
          backup_type TEXT NOT NULL, -- 'auto', 'manual', 'pre_migration'
          checksum TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          created_by TEXT,
          updated_by TEXT,
          status TEXT DEFAULT 'ready'
        );
      `);
    }
  },
  {
    id: 2,
    name: '002_user_sessions_and_security_lockout',
    up: (db: DatabaseSync) => {
      // 1. User Sessions table for multi-device login & logout-all
      db.exec(`
        CREATE TABLE IF NOT EXISTS user_sessions (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          tenant_id TEXT NOT NULL,
          token TEXT UNIQUE NOT NULL,
          ip_address TEXT,
          user_agent TEXT,
          created_at TEXT NOT NULL,
          expires_at TEXT NOT NULL,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_sessions_token ON user_sessions(token);
        CREATE INDEX IF NOT EXISTS idx_sessions_user ON user_sessions(user_id);
      `);

      // Add failed_attempts and locked_until to users if not present
      try {
        db.exec(`ALTER TABLE users ADD COLUMN failed_attempts INTEGER DEFAULT 0;`);
      } catch (_) {}

      try {
        db.exec(`ALTER TABLE users ADD COLUMN locked_until TEXT;`);
      } catch (_) {}
    }
  }
];
