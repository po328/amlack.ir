// Format numbers to Persian digits optionally or Persian localized numbers
export function toPersianDigits(num: number | string): string {
  if (num === undefined || num === null) return '';
  const str = num.toString();
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return str.replace(/[0-9]/g, (w) => persianDigits[+w]);
}

// Format currency in Tomans with commas
export function formatToman(amount?: number | null, appendUnit: boolean = true): string {
  if (amount === undefined || amount === null || isNaN(amount)) return '۰' + (appendUnit ? ' تومان' : '');
  const formatted = new Intl.NumberFormat('fa-IR').format(amount);
  return formatted + (appendUnit ? ' تومان' : '');
}

export const formatCurrency = formatToman;

// Convert large number to conversational Persian words (e.g. ۳ میلیارد و ۵۰۰ میلیون تومان)
export function numberToPersianWords(amount: number): string {
  if (!amount || amount === 0) return 'صفر تومان';

  const billion = 1000000000;
  const million = 1000000;
  const thousand = 1000;

  const billions = Math.floor(amount / billion);
  let remainder = amount % billion;

  const millions = Math.floor(remainder / million);
  remainder = remainder % million;

  const thousands = Math.floor(remainder / thousand);
  const units = remainder % thousand;

  const parts: string[] = [];

  if (billions > 0) {
    parts.push(`${toPersianDigits(billions)} میلیارد`);
  }
  if (millions > 0) {
    parts.push(`${toPersianDigits(millions)} میلیون`);
  }
  if (thousands > 0) {
    parts.push(`${toPersianDigits(thousands)} هزار`);
  }
  if (units > 0 && parts.length === 0) {
    parts.push(`${toPersianDigits(units)}`);
  }

  return parts.join(' و ') + ' تومان';
}

// Calculate Mortgage & Rent Conversion
// Custom market standard: Rate is typically 3% per month (30,000 Tomans rent per 1,000,000 Tomans mortgage)
export function calculateMortgageRentConversion(
  mortgage: number,
  rent: number,
  ratePercent: number = 3.0 // 3 percent
) {
  // ratePercent e.g. 3.0 means 0.03
  const factor = ratePercent / 100;

  // fullMortgage = mortgage + (rent / factor)
  const fullMortgage = Math.round(mortgage + (factor > 0 ? rent / factor : 0));

  // fullRent = rent + (mortgage * factor)
  const fullRent = Math.round(rent + (mortgage * factor));

  return {
    fullMortgage,
    fullRent,
  };
}

// Custom partial conversion: given target new mortgage, calculate new rent
export function calculateCustomConversion(
  initialMortgage: number,
  initialRent: number,
  targetMortgage: number,
  ratePercent: number = 3.0
) {
  const factor = ratePercent / 100;
  const mortgageDiff = targetMortgage - initialMortgage;
  // If mortgage increases by diff, rent decreases by diff * factor
  const newRent = Math.max(0, Math.round(initialRent - (mortgageDiff * factor)));
  return newRent;
}

// Calculate Commission for Sale or Rent
export function calculateSaleCommission(
  salePrice: number,
  buyerRatePercent: number = 0.25,
  sellerRatePercent: number = 0.25,
  vatPercent: number = 10,
  agentSharePercent: number = 50
) {
  const buyerFee = Math.round(salePrice * (buyerRatePercent / 100));
  const sellerFee = Math.round(salePrice * (sellerRatePercent / 100));
  const totalFeeBeforeVat = buyerFee + sellerFee;
  const vatAmount = Math.round(totalFeeBeforeVat * (vatPercent / 100));
  const totalCommission = totalFeeBeforeVat + vatAmount;

  // Agent share is calculated from commission before VAT
  const agentShare = Math.round(totalFeeBeforeVat * (agentSharePercent / 100));
  const agencyShare = totalFeeBeforeVat - agentShare;

  return {
    buyerFee,
    sellerFee,
    totalFeeBeforeVat,
    vatAmount,
    totalCommission,
    agentShare,
    agencyShare,
  };
}

export function calculateRentCommission(
  mortgageAmount: number,
  rentAmount: number,
  conversionRatePercent: number = 3.0,
  rentDaysShare: number = 7, // equivalent to 1/4th month or 7-8 days
  vatPercent: number = 10,
  agentSharePercent: number = 50
) {
  // First convert mortgage to equivalent rent (mortgage * 0.03)
  const equivalentRentFromMortgage = mortgageAmount * (conversionRatePercent / 100);
  const totalMonthlyRentEquivalent = rentAmount + equivalentRentFromMortgage;

  // Fee from each party is usually 1/4 of total monthly rent equivalent (or 7.5 days)
  const factorDays = rentDaysShare / 30;
  const partyFee = Math.round(totalMonthlyRentEquivalent * factorDays);
  const totalFeeBeforeVat = partyFee * 2; // from both tenant and landlord
  const vatAmount = Math.round(totalFeeBeforeVat * (vatPercent / 100));
  const totalCommission = totalFeeBeforeVat + vatAmount;

  const agentShare = Math.round(totalFeeBeforeVat * (agentSharePercent / 100));
  const agencyShare = totalFeeBeforeVat - agentShare;

  return {
    equivalentRentFromMortgage,
    totalMonthlyRentEquivalent,
    tenantFee: partyFee,
    landlordFee: partyFee,
    totalFeeBeforeVat,
    vatAmount,
    totalCommission,
    agentShare,
    agencyShare,
  };
}

// Convert date string or timestamp to Persian formatted relative/readable date
export function formatPersianDate(dateStr: string): string {
  if (!dateStr) return '';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;

    // Check if it's today or tomorrow
    const today = new Date();
    const isToday = d.toDateString() === today.toDateString();
    
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    const isTomorrow = d.toDateString() === tomorrow.toDateString();

    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);
    const isYesterday = d.toDateString() === yesterday.toDateString();

    if (isToday) return 'امروز';
    if (isTomorrow) return 'فردا';
    if (isYesterday) return 'دیروز';

    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(d);
  } catch {
    return dateStr;
  }
}
