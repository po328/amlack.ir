/**
 * Utilities for client-side image optimization, compression, resizing,
 * and reliable fallback generation for real estate property photos.
 */

// Default premium architectural fallback SVG data URI
export const PROPERTY_FALLBACK_IMAGE = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" />
      <stop offset="50%" stop-color="#1e293b" />
      <stop offset="100%" stop-color="#0f172a" />
    </linearGradient>
    <linearGradient id="accentGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#059669" />
      <stop offset="100%" stop-color="#0d9488" />
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="url(#bgGrad)" />
  <g opacity="0.15" stroke="#ffffff" stroke-width="1">
    <line x1="0" y1="150" x2="800" y2="150" />
    <line x1="0" y1="300" x2="800" y2="300" />
    <line x1="0" y1="450" x2="800" y2="450" />
    <line x1="200" y1="0" x2="200" y2="600" />
    <line x1="400" y1="0" x2="400" y2="600" />
    <line x1="600" y1="0" x2="600" y2="600" />
  </g>
  <g transform="translate(340, 200)">
    <rect x="15" y="40" width="90" height="130" rx="8" fill="url(#accentGrad)" opacity="0.9" />
    <polygon points="60,0 0,45 120,45" fill="url(#accentGrad)" />
    <!-- Windows -->
    <rect x="30" y="55" width="22" height="22" rx="3" fill="#ffffff" opacity="0.85" />
    <rect x="68" y="55" width="22" height="22" rx="3" fill="#ffffff" opacity="0.85" />
    <rect x="30" y="90" width="22" height="22" rx="3" fill="#ffffff" opacity="0.85" />
    <rect x="68" y="90" width="22" height="22" rx="3" fill="#ffffff" opacity="0.85" />
    <rect x="30" y="125" width="22" height="22" rx="3" fill="#ffffff" opacity="0.85" />
    <rect x="68" y="125" width="22" height="22" rx="3" fill="#ffffff" opacity="0.85" />
  </g>
  <text x="400" y="430" text-anchor="middle" fill="#94a3b8" font-family="sans-serif" font-size="16" font-weight="600" letter-spacing="1">
    تصویر فایل ملکی
  </text>
  <text x="400" y="455" text-anchor="middle" fill="#64748b" font-family="sans-serif" font-size="13">
    سامانه تخصصی مدیریت املاک و مستغلات
  </text>
</svg>
`)}`;

/**
 * High-performance, self-contained SVG illustrations for each property type.
 * Completely offline, zero network requests, instant rendering in any region.
 */
export const ARCHITECTURAL_ILLUSTRATIONS: Record<string, string> = {
  apartment: `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
  <defs>
    <linearGradient id="apBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#09131f" /><stop offset="100%" stop-color="#1a2e40" />
    </linearGradient>
    <linearGradient id="apBldg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#1e3a5f" /><stop offset="100%" stop-color="#0f2238" />
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="url(#apBg)" />
  <g opacity="0.1" stroke="#38bdf8" stroke-width="1">
    <line x1="0" y1="480" x2="800" y2="480" stroke-width="2" opacity="0.4" />
  </g>
  <!-- Main Apartment Building -->
  <g transform="translate(280, 110)">
    <rect x="0" y="30" width="240" height="340" rx="8" fill="url(#apBldg)" stroke="#334155" stroke-width="2" />
    <!-- Balconies and Windows Matrix -->
    <rect x="30" y="60" width="70" height="45" rx="4" fill="#0284c7" opacity="0.75" />
    <rect x="140" y="60" width="70" height="45" rx="4" fill="#38bdf8" opacity="0.85" />
    <rect x="30" y="130" width="70" height="45" rx="4" fill="#38bdf8" opacity="0.85" />
    <rect x="140" y="130" width="70" height="45" rx="4" fill="#0284c7" opacity="0.75" />
    <rect x="30" y="200" width="70" height="45" rx="4" fill="#38bdf8" opacity="0.9" />
    <rect x="140" y="200" width="70" height="45" rx="4" fill="#0284c7" opacity="0.8" />
    <rect x="30" y="270" width="70" height="45" rx="4" fill="#0284c7" opacity="0.75" />
    <rect x="140" y="270" width="70" height="45" rx="4" fill="#38bdf8" opacity="0.85" />
    <!-- Entrance Lobby -->
    <rect x="95" y="325" width="50" height="45" rx="4" fill="#10b981" opacity="0.9" />
  </g>
  <text x="400" y="520" text-anchor="middle" fill="#94a3b8" font-family="sans-serif" font-size="18" font-weight="700">
    آپارتمان مسکونی
  </text>
</svg>
`)}`,

  penthouse: `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
  <defs>
    <linearGradient id="phBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#111827" /><stop offset="100%" stop-color="#1f2937" />
    </linearGradient>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fbbf24" /><stop offset="100%" stop-color="#d97706" />
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="url(#phBg)" />
  <!-- Penthouse Structure -->
  <g transform="translate(200, 130)">
    <rect x="50" y="160" width="300" height="200" rx="6" fill="#1e293b" stroke="#374151" stroke-width="2" />
    <!-- Luxury Rooftop Deck -->
    <rect x="80" y="80" width="240" height="90" rx="6" fill="#0f172a" stroke="url(#goldGrad)" stroke-width="3" />
    <!-- Panoramic glass windows -->
    <rect x="100" y="95" width="60" height="60" rx="3" fill="#38bdf8" opacity="0.85" />
    <rect x="170" y="95" width="60" height="60" rx="3" fill="#fbbf24" opacity="0.85" />
    <rect x="240" y="95" width="60" height="60" rx="3" fill="#38bdf8" opacity="0.85" />
    <!-- Terrace Garden & Glass Railing -->
    <line x1="60" y1="165" x2="340" y2="165" stroke="#38bdf8" stroke-width="4" opacity="0.7" />
    <circle cx="310" cy="140" r="14" fill="#10b981" opacity="0.9" />
  </g>
  <text x="400" y="520" text-anchor="middle" fill="#fbbf24" font-family="sans-serif" font-size="18" font-weight="700">
    پنت‌هاوس لوکس و روف‌گاردن
  </text>
</svg>
`)}`,

  villa: `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
  <defs>
    <linearGradient id="vilBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#064e3b" /><stop offset="100%" stop-color="#0f172a" />
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="url(#vilBg)" />
  <!-- Villa Geometric Modern Design -->
  <g transform="translate(220, 160)">
    <polygon points="180,0 20,80 340,80" fill="#047857" opacity="0.9" />
    <rect x="40" y="80" width="280" height="180" rx="6" fill="#1e293b" stroke="#10b981" stroke-width="2" />
    <rect x="60" y="100" width="80" height="60" rx="4" fill="#6ee7b7" opacity="0.9" />
    <rect x="220" y="100" width="80" height="60" rx="4" fill="#6ee7b7" opacity="0.9" />
    <!-- Main Entrance -->
    <rect x="155" y="170" width="50" height="90" rx="4" fill="#059669" />
    <!-- Private Pool -->
    <ellipse cx="180" cy="290" rx="140" ry="24" fill="#0284c7" opacity="0.8" />
  </g>
  <text x="400" y="520" text-anchor="middle" fill="#6ee7b7" font-family="sans-serif" font-size="18" font-weight="700">
    ویلا و باغ اختصاصی
  </text>
</svg>
`)}`,

  office: `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
  <defs>
    <linearGradient id="offBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" /><stop offset="100%" stop-color="#1e1e38" />
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="url(#offBg)" />
  <!-- Corporate Office Tower -->
  <g transform="translate(290, 120)">
    <rect x="0" y="20" width="220" height="340" rx="4" fill="#1e293b" stroke="#6366f1" stroke-width="2" />
    <!-- Grid of reflective blue office windows -->
    <g fill="#818cf8" opacity="0.85">
      <rect x="20" y="45" width="40" height="30" rx="2" /><rect x="75" y="45" width="40" height="30" rx="2" /><rect x="130" y="45" width="40" height="30" rx="2" />
      <rect x="20" y="95" width="40" height="30" rx="2" /><rect x="75" y="95" width="40" height="30" rx="2" /><rect x="130" y="95" width="40" height="30" rx="2" />
      <rect x="20" y="145" width="40" height="30" rx="2" /><rect x="75" y="145" width="40" height="30" rx="2" /><rect x="130" y="145" width="40" height="30" rx="2" />
      <rect x="20" y="195" width="40" height="30" rx="2" /><rect x="75" y="195" width="40" height="30" rx="2" /><rect x="130" y="195" width="40" height="30" rx="2" />
      <rect x="20" y="245" width="40" height="30" rx="2" /><rect x="75" y="245" width="40" height="30" rx="2" /><rect x="130" y="245" width="40" height="30" rx="2" />
    </g>
    <rect x="85" y="305" width="50" height="55" rx="3" fill="#6366f1" />
  </g>
  <text x="400" y="520" text-anchor="middle" fill="#c7d2fe" font-family="sans-serif" font-size="18" font-weight="700">
    واحد اداری و تجاری
  </text>
</svg>
`)}`,

  commercial: `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
  <defs>
    <linearGradient id="comBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#18181b" /><stop offset="100%" stop-color="#27272a" />
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="url(#comBg)" />
  <!-- Storefront / Showroom -->
  <g transform="translate(230, 160)">
    <rect x="0" y="40" width="340" height="230" rx="6" fill="#18181b" stroke="#f59e0b" stroke-width="2" />
    <!-- Awning Canopy -->
    <polygon points="0,40 20,0 320,0 340,40" fill="#f59e0b" />
    <!-- Large Glass Showroom Display -->
    <rect x="25" y="65" width="130" height="180" rx="4" fill="#fbbf24" opacity="0.8" />
    <rect x="185" y="65" width="130" height="180" rx="4" fill="#fbbf24" opacity="0.8" />
  </g>
  <text x="400" y="520" text-anchor="middle" fill="#fbbf24" font-family="sans-serif" font-size="18" font-weight="700">
    مغازه و تجاری بر اصلی
  </text>
</svg>
`)}`,

  land: `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
  <defs>
    <linearGradient id="lndBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f291e" /><stop offset="100%" stop-color="#1e3a2b" />
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="url(#lndBg)" />
  <!-- Land Parcel Blueprint Plot -->
  <g transform="translate(240, 150)">
    <polygon points="40,20 280,0 320,240 10,210" fill="none" stroke="#10b981" stroke-width="3" stroke-dasharray="8 6" />
    <circle cx="40" cy="20" r="7" fill="#34d399" />
    <circle cx="280" cy="0" r="7" fill="#34d399" />
    <circle cx="320" cy="240" r="7" fill="#34d399" />
    <circle cx="10" cy="210" r="7" fill="#34d399" />
    <text x="160" y="130" text-anchor="middle" fill="#34d399" font-family="sans-serif" font-size="15" font-weight="600">
      قطعه زمین تفکیکی
    </text>
  </g>
  <text x="400" y="520" text-anchor="middle" fill="#34d399" font-family="sans-serif" font-size="18" font-weight="700">
    زمین و کلنگی قابل ساخت
  </text>
</svg>
`)}`
};

export function getPropertyFallbackImage(propertyType?: string): string {
  if (!propertyType) return PROPERTY_FALLBACK_IMAGE;
  const normalized = propertyType.toLowerCase();
  return ARCHITECTURAL_ILLUSTRATIONS[normalized] || PROPERTY_FALLBACK_IMAGE;
}

export const USER_FALLBACK_AVATAR = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 160" width="160" height="160">
  <rect width="100%" height="100%" fill="#059669" rx="80"/>
  <circle cx="80" cy="60" r="28" fill="#ffffff" opacity="0.9"/>
  <path d="M36 130 C36 100 60 92 80 92 C100 92 124 100 124 130 Z" fill="#ffffff" opacity="0.9"/>
</svg>
`)}`;

/**
 * Validates if the file is a valid image type
 */
export function isValidImageFile(file: File): boolean {
  const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'];
  return validTypes.includes(file.type);
}

/**
 * Compresses and resizes an uploaded image on the client side using HTMLCanvasElement.
 * Returns an optimized data URL string (WebP or JPEG) suitable for localStorage and instant rendering.
 */
export async function compressAndResizeImage(
  file: File,
  maxWidth = 1200,
  maxHeight = 900,
  quality = 0.82
): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!isValidImageFile(file)) {
      reject(new Error('فرمت فایل پشتیبانی نمی‌شود. لطفاً فایل JPG، PNG یا WebP انتخاب نمایید.'));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('خطا در بارگذاری فایل تصویر'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('خطا در پردازش تصویر'));
      img.onload = () => {
        let { width, height } = img;

        // Calculate aspect ratio preserving dimensions
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('محیط پردازش تصویر پشتیبانی نمی‌شود.'));
          return;
        }

        // Enable high quality image smoothing
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        // Draw image onto canvas
        ctx.drawImage(img, 0, 0, width, height);

        // Try webp first; fallback to jpeg
        try {
          const webpData = canvas.toDataURL('image/webp', quality);
          if (webpData.startsWith('data:image/webp')) {
            resolve(webpData);
            return;
          }
        } catch {
          // ignore and fallback
        }

        const jpegData = canvas.toDataURL('image/jpeg', quality);
        resolve(jpegData);
      };

      img.src = reader.result as string;
    };

    reader.readAsDataURL(file);
  });
}

/**
 * Sanitize and validate an external URL string.
 */
export function isValidImageUrl(url: string): boolean {
  if (!url || typeof url !== 'string') return false;
  const trimmed = url.trim();
  if (trimmed.startsWith('data:image/')) return true;
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}
