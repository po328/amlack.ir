import {
  Property,
  Customer,
  ContactInteraction,
  FollowUp,
  CommissionRecord,
  ConversionRecord,
  User,
  AppSettings,
  ActivityLog,
  Tenant,
  Contract,
  FinancialTransaction,
  PlatformStats
} from '../types';

class ApiService {
  private token: string | null = null;
  private currentTenantId: string = 'tenant-negin-1';

  constructor() {
    if (typeof window !== 'undefined') {
      this.token = localStorage.getItem('amlak_auth_token');
      const savedTenant = localStorage.getItem('amlak_tenant_id');
      if (savedTenant) {
        this.currentTenantId = savedTenant;
      }
    }
  }

  public setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem('amlak_auth_token', token);
    } else {
      localStorage.removeItem('amlak_auth_token');
    }
  }

  public getToken(): string | null {
    return this.token;
  }

  public setTenantId(tenantId: string) {
    this.currentTenantId = tenantId;
    localStorage.setItem('amlak_tenant_id', tenantId);
  }

  public getTenantId(): string {
    return this.currentTenantId;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'x-tenant-id': this.currentTenantId,
      ...(options.headers as Record<string, string> || {})
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(endpoint, {
      ...options,
      headers
    });

    if (!response.ok) {
      let errorMessage = `HTTP Error ${response.status}`;
      try {
        const errorData = await response.json();
        if (errorData.error) errorMessage = errorData.error;
      } catch (e) {
        // non-json response
      }
      throw new Error(errorMessage);
    }

    return response.json();
  }

  // --- Auth ---
  async login(username: string, password: string, tenantSlug?: string) {
    const data = await this.request<{ token: string; user: User; tenant: Tenant }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password, tenantSlug })
    });
    this.setToken(data.token);
    if (data.tenant) {
      this.setTenantId(data.tenant.id);
    }
    return data;
  }

  async getMe() {
    return this.request<{ user: User; tenant: Tenant }>('/api/auth/me');
  }

  async logout() {
    try {
      await this.request('/api/auth/logout', { method: 'POST' });
    } catch (_) {}
    this.setToken(null);
  }

  // --- Tenants (Multi-Agency) ---
  async getTenants(): Promise<Tenant[]> {
    return this.request<Tenant[]>('/api/tenants');
  }

  async createTenant(tenantData: any): Promise<{ message: string; tenantId: string }> {
    return this.request('/api/tenants', {
      method: 'POST',
      body: JSON.stringify(tenantData)
    });
  }

  async updateSettings(settings: AppSettings) {
    return this.request<{ message: string; settings: AppSettings }>('/api/tenants/settings', {
      method: 'PUT',
      body: JSON.stringify(settings)
    });
  }

  // --- Properties ---
  async getProperties(params?: Record<string, string>): Promise<Property[]> {
    const query = params ? '?' + new URLSearchParams(params).toString() : '';
    return this.request<Property[]>(`/api/properties${query}`);
  }

  async getProperty(id: string): Promise<Property> {
    return this.request<Property>(`/api/properties/${id}`);
  }

  async createProperty(property: Partial<Property>): Promise<{ id: string; code: string }> {
    return this.request('/api/properties', {
      method: 'POST',
      body: JSON.stringify(property)
    });
  }

  async updateProperty(id: string, property: Partial<Property>): Promise<{ message: string }> {
    return this.request(`/api/properties/${id}`, {
      method: 'PUT',
      body: JSON.stringify(property)
    });
  }

  async deleteProperty(id: string): Promise<{ message: string }> {
    return this.request(`/api/properties/${id}`, {
      method: 'DELETE'
    });
  }

  // --- Customers ---
  async getCustomers(): Promise<Customer[]> {
    return this.request<Customer[]>('/api/customers');
  }

  async createCustomer(customer: Partial<Customer>): Promise<{ id: string }> {
    return this.request('/api/customers', {
      method: 'POST',
      body: JSON.stringify(customer)
    });
  }

  async updateCustomer(id: string, customer: Partial<Customer>): Promise<{ message: string }> {
    return this.request(`/api/customers/${id}`, {
      method: 'PUT',
      body: JSON.stringify(customer)
    });
  }

  async deleteCustomer(id: string): Promise<{ message: string }> {
    return this.request(`/api/customers/${id}`, {
      method: 'DELETE'
    });
  }

  async getCustomerInteractions(customerId: string): Promise<ContactInteraction[]> {
    return this.request<ContactInteraction[]>(`/api/customers/${customerId}/interactions`);
  }

  async addCustomerInteraction(customerId: string, data: Partial<ContactInteraction>): Promise<{ id: string }> {
    return this.request(`/api/customers/${customerId}/interactions`, {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  // --- Contracts & Deals ---
  async getContracts(): Promise<Contract[]> {
    return this.request<Contract[]>('/api/contracts');
  }

  async createContract(contract: Partial<Contract>): Promise<{ id: string; contractNumber: string }> {
    return this.request('/api/contracts', {
      method: 'POST',
      body: JSON.stringify(contract)
    });
  }

  // --- Finances ---
  async getFinances(): Promise<FinancialTransaction[]> {
    return this.request<FinancialTransaction[]>('/api/finances');
  }

  async createFinancialTransaction(trans: Partial<FinancialTransaction>): Promise<{ id: string }> {
    return this.request('/api/finances', {
      method: 'POST',
      body: JSON.stringify(trans)
    });
  }

  // --- Tasks / Follow-ups ---
  async getTasks(): Promise<FollowUp[]> {
    return this.request<FollowUp[]>('/api/tasks');
  }

  async createTask(task: Partial<FollowUp>): Promise<{ id: string }> {
    return this.request('/api/tasks', {
      method: 'POST',
      body: JSON.stringify(task)
    });
  }

  async toggleTask(id: string): Promise<{ id: string; status: 'pending' | 'completed' }> {
    return this.request(`/api/tasks/${id}/toggle`, {
      method: 'PUT'
    });
  }

  async deleteTask(id: string): Promise<{ message: string }> {
    return this.request(`/api/tasks/${id}`, {
      method: 'DELETE'
    });
  }

  // --- Conversions ---
  async getConversions(): Promise<ConversionRecord[]> {
    return this.request<ConversionRecord[]>('/api/conversions');
  }

  async createConversion(conversion: Partial<ConversionRecord>): Promise<{ id: string }> {
    return this.request('/api/conversions', {
      method: 'POST',
      body: JSON.stringify(conversion)
    });
  }

  async clearConversions(): Promise<{ message: string }> {
    return this.request('/api/conversions', {
      method: 'DELETE'
    });
  }

  // --- Users / Staff ---
  async getUsers(): Promise<User[]> {
    return this.request<User[]>('/api/users');
  }

  async createUser(userData: any): Promise<{ id: string }> {
    return this.request('/api/users', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  }

  async updateUser(id: string, userData: any): Promise<{ message: string }> {
    return this.request(`/api/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(userData)
    });
  }

  async deleteUser(id: string): Promise<{ message: string }> {
    return this.request(`/api/users/${id}`, {
      method: 'DELETE'
    });
  }

  // --- Activity Audit Trail ---
  async getActivityLogs(): Promise<ActivityLog[]> {
    return this.request<ActivityLog[]>('/api/activity');
  }

  // --- Backups & Safety ---
  async getBackups(): Promise<any[]> {
    return this.request<any[]>('/api/backups');
  }

  async createBackup(): Promise<{ message: string; path: string }> {
    return this.request('/api/backups/create', {
      method: 'POST'
    });
  }

  async resetTenantData(): Promise<{ message: string }> {
    return this.request('/api/backups/reset', {
      method: 'POST'
    });
  }

  // --- File Upload ---
  async uploadFile(base64Data: string, filename: string): Promise<{ url: string; filename: string }> {
    return this.request('/api/upload', {
      method: 'POST',
      body: JSON.stringify({ data: base64Data, filename })
    });
  }

  // --- Super Admin Platform Stats ---
  async getPlatformStats(): Promise<PlatformStats> {
    return this.request<PlatformStats>('/api/platform/stats');
  }
}

export const apiService = new ApiService();
