import {
  Property,
  Customer,
  ContactInteraction,
  FollowUp,
  CommissionRecord,
  ConversionRecord,
  User,
  AppSettings,
  ActivityLog
} from '../types';

const KEYS = {
  PROPERTIES: 'amlak_properties_v1',
  CUSTOMERS: 'amlak_customers_v1',
  CONTACTS: 'amlak_contacts_v1',
  FOLLOW_UPS: 'amlak_follow_ups_v1',
  COMMISSIONS: 'amlak_commissions_v1',
  CONVERSIONS: 'amlak_conversions_v1',
  USERS: 'amlak_users_v1',
  SETTINGS: 'amlak_settings_v1',
  CURRENT_USER: 'amlak_current_user_v1',
  THEME: 'amlak_theme_v1',
  ACTIVITIES: 'amlak_activities_v1',
  TENANT_CACHE_PREFIX: 'amlak_tenant_cache_'
};

const defaultSettings: AppSettings = {
  agencyName: 'املاک نگین پایتخت',
  managerName: 'مهندس علی رضایی',
  phone: '02122003344',
  city: 'تهران',
  address: 'سعادت‌آباد، میدان کاج، نبش خیابان مروارید',
  currencyUnit: 'تومان',
  defaultConversionRate: 3.0,
  saleCommissionRateBuyer: 0.25,
  saleCommissionRateSeller: 0.25,
  rentCommissionDays: 7,
  vatPercent: 10,
  agentCommissionSharePercent: 50,
  licenseNumber: 'الف/۹۸۴۳۲۱'
};

export const storageService = {
  // Tenant-scoped full offline cache
  saveAgencyCache(tenantId: string, data: {
    properties?: Property[];
    customers?: Customer[];
    followUps?: FollowUp[];
    commissions?: CommissionRecord[];
    conversions?: ConversionRecord[];
    contacts?: ContactInteraction[];
    users?: User[];
    settings?: AppSettings;
  }) {
    try {
      localStorage.setItem(`${KEYS.TENANT_CACHE_PREFIX}${tenantId}`, JSON.stringify({
        ...data,
        cachedAt: new Date().toISOString()
      }));
      if (data.properties) this.saveProperties(data.properties);
      if (data.customers) this.saveCustomers(data.customers);
      if (data.followUps) this.saveFollowUps(data.followUps);
      if (data.users) this.saveUsers(data.users);
      if (data.settings) this.saveSettings(data.settings);
    } catch (e) {
      console.warn('[Cache save error]', e);
    }
  },

  getAgencyCache(tenantId: string) {
    try {
      const raw = localStorage.getItem(`${KEYS.TENANT_CACHE_PREFIX}${tenantId}`);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  },

  // Properties
  getProperties(): Property[] {
    try {
      const data = localStorage.getItem(KEYS.PROPERTIES);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveProperties(properties: Property[]) {
    try {
      localStorage.setItem(KEYS.PROPERTIES, JSON.stringify(properties));
    } catch (e) {
      console.warn('[Storage Error]', e);
    }
  },

  addProperty(property: Omit<Property, 'id' | 'createdAt' | 'updatedAt'>): Property {
    const list = this.getProperties();
    const newProp: Property = {
      ...property,
      id: 'prop-' + Date.now(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    list.unshift(newProp);
    this.saveProperties(list);
    return newProp;
  },

  updateProperty(id: string, updates: Partial<Property>): Property | null {
    const list = this.getProperties();
    const index = list.findIndex(p => p.id === id);
    if (index === -1) return null;
    list[index] = {
      ...list[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.saveProperties(list);
    return list[index];
  },

  deleteProperty(id: string) {
    const list = this.getProperties().filter(p => p.id !== id);
    this.saveProperties(list);
  },

  toggleFavoriteProperty(id: string): boolean {
    const list = this.getProperties();
    const target = list.find(p => p.id === id);
    if (!target) return false;
    target.isFavorite = !target.isFavorite;
    this.saveProperties(list);
    return target.isFavorite;
  },

  // Customers
  getCustomers(): Customer[] {
    try {
      const data = localStorage.getItem(KEYS.CUSTOMERS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveCustomers(customers: Customer[]) {
    try {
      localStorage.setItem(KEYS.CUSTOMERS, JSON.stringify(customers));
    } catch (e) {
      console.warn('[Storage Error]', e);
    }
  },

  addCustomer(customer: Omit<Customer, 'id' | 'createdAt'>): Customer {
    const list = this.getCustomers();
    const newCust: Customer = {
      ...customer,
      id: 'cust-' + Date.now(),
      createdAt: new Date().toISOString()
    };
    list.unshift(newCust);
    this.saveCustomers(list);
    return newCust;
  },

  updateCustomer(id: string, updates: Partial<Customer>): Customer | null {
    const list = this.getCustomers();
    const index = list.findIndex(c => c.id === id);
    if (index === -1) return null;
    list[index] = {
      ...list[index],
      ...updates
    };
    this.saveCustomers(list);
    return list[index];
  },

  deleteCustomer(id: string) {
    const list = this.getCustomers().filter(c => c.id !== id);
    this.saveCustomers(list);
  },

  // Interactions / Contacts
  getContacts(customerId?: string): ContactInteraction[] {
    try {
      const data = localStorage.getItem(KEYS.CONTACTS);
      const list: ContactInteraction[] = data ? JSON.parse(data) : [];
      if (customerId) {
        return list.filter(c => c.customerId === customerId);
      }
      return list;
    } catch {
      return [];
    }
  },

  addContact(contact: Omit<ContactInteraction, 'id'>): ContactInteraction {
    const list = this.getContacts();
    const newContact: ContactInteraction = {
      ...contact,
      id: 'int-' + Date.now()
    };
    list.unshift(newContact);
    localStorage.setItem(KEYS.CONTACTS, JSON.stringify(list));
    return newContact;
  },

  // Follow-ups / Tasks
  getFollowUps(): FollowUp[] {
    try {
      const data = localStorage.getItem(KEYS.FOLLOW_UPS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveFollowUps(followUps: FollowUp[]) {
    try {
      localStorage.setItem(KEYS.FOLLOW_UPS, JSON.stringify(followUps));
    } catch (e) {
      console.warn('[Storage Error]', e);
    }
  },

  addFollowUp(followUp: Omit<FollowUp, 'id' | 'createdAt'>): FollowUp {
    const list = this.getFollowUps();
    const newFollowUp: FollowUp = {
      ...followUp,
      id: 'fu-' + Date.now(),
      createdAt: new Date().toISOString()
    };
    list.unshift(newFollowUp);
    this.saveFollowUps(list);
    return newFollowUp;
  },

  updateFollowUpStatus(id: string, status: FollowUp['status']) {
    const list = this.getFollowUps();
    const target = list.find(f => f.id === id);
    if (target) {
      target.status = status;
      this.saveFollowUps(list);
    }
  },

  deleteFollowUp(id: string) {
    const list = this.getFollowUps().filter(f => f.id !== id);
    this.saveFollowUps(list);
  },

  // Commission Records
  getCommissions(): CommissionRecord[] {
    try {
      const data = localStorage.getItem(KEYS.COMMISSIONS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  addCommission(record: Omit<CommissionRecord, 'id'>): CommissionRecord {
    const list = this.getCommissions();
    const newRecord: CommissionRecord = {
      ...record,
      id: 'comm-' + Date.now()
    };
    list.unshift(newRecord);
    localStorage.setItem(KEYS.COMMISSIONS, JSON.stringify(list));
    return newRecord;
  },

  deleteCommission(id: string) {
    const list = this.getCommissions().filter(c => c.id !== id);
    localStorage.setItem(KEYS.COMMISSIONS, JSON.stringify(list));
  },

  // Conversion History
  getConversionHistory(): ConversionRecord[] {
    try {
      const data = localStorage.getItem(KEYS.CONVERSIONS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  addConversionRecord(record: Omit<ConversionRecord, 'id'>): ConversionRecord {
    const list = this.getConversionHistory();
    const newRecord: ConversionRecord = {
      ...record,
      id: 'conv-' + Date.now()
    };
    list.unshift(newRecord);
    localStorage.setItem(KEYS.CONVERSIONS, JSON.stringify(list.slice(0, 50)));
    return newRecord;
  },

  clearConversionHistory() {
    localStorage.removeItem(KEYS.CONVERSIONS);
  },

  // Users
  getUsers(): User[] {
    try {
      const data = localStorage.getItem(KEYS.USERS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveUsers(users: User[]) {
    try {
      localStorage.setItem(KEYS.USERS, JSON.stringify(users));
    } catch (e) {
      console.warn('[Storage Error]', e);
    }
  },

  addUser(user: Omit<User, 'id'>): User {
    const list = this.getUsers();
    const newUser: User = {
      ...user,
      id: 'usr-' + Date.now()
    };
    list.push(newUser);
    this.saveUsers(list);
    return newUser;
  },

  updateUser(id: string, updates: Partial<User>): User | null {
    const list = this.getUsers();
    const index = list.findIndex(u => u.id === id);
    if (index === -1) return null;
    list[index] = {
      ...list[index],
      ...updates
    };
    this.saveUsers(list);
    return list[index];
  },

  deleteUser(id: string) {
    const list = this.getUsers().filter(u => u.id !== id);
    this.saveUsers(list);
  },

  getCurrentUser(): User | null {
    try {
      const data = localStorage.getItem(KEYS.CURRENT_USER);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  setCurrentUser(user: User | null) {
    if (!user) {
      localStorage.removeItem(KEYS.CURRENT_USER);
    } else {
      localStorage.setItem(KEYS.CURRENT_USER, JSON.stringify(user));
    }
  },

  // Settings
  getSettings(): AppSettings {
    try {
      const data = localStorage.getItem(KEYS.SETTINGS);
      return data ? JSON.parse(data) : defaultSettings;
    } catch {
      return defaultSettings;
    }
  },

  saveSettings(settings: AppSettings) {
    try {
      localStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.warn('[Storage Error]', e);
    }
  },

  updateSettings(settings: Partial<AppSettings>): AppSettings {
    const current = this.getSettings();
    const updated = { ...current, ...settings };
    this.saveSettings(updated);
    return updated;
  },

  // Activities
  getActivities(): ActivityLog[] {
    try {
      const data = localStorage.getItem(KEYS.ACTIVITIES);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  addActivity(entry: Omit<ActivityLog, 'id' | 'timestamp'>): ActivityLog {
    const list = this.getActivities();
    const newEntry: ActivityLog = {
      ...entry,
      id: 'act-' + Date.now(),
      timestamp: new Date().toISOString()
    };
    list.unshift(newEntry);
    localStorage.setItem(KEYS.ACTIVITIES, JSON.stringify(list.slice(0, 100)));
    return newEntry;
  },

  clearActivities() {
    localStorage.setItem(KEYS.ACTIVITIES, JSON.stringify([]));
  }
};
