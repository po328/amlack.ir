import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { BottomNav } from './components/layout/BottomNav';
import { DashboardView } from './components/dashboard/DashboardView';
import { PropertyList } from './components/properties/PropertyList';
import { PropertyFormModal } from './components/properties/PropertyFormModal';
import { PropertyDetailModal } from './components/properties/PropertyDetailModal';
import { CustomerList } from './components/customers/CustomerList';
import { CustomerFormModal } from './components/customers/CustomerFormModal';
import { CustomerDetailModal } from './components/customers/CustomerDetailModal';
import { MortgageRentConverter } from './components/tools/MortgageRentConverter';
import { CommissionCalculator } from './components/tools/CommissionCalculator';
import { TaskManager } from './components/tasks/TaskManager';
import { SettingsView } from './components/settings/SettingsView';
import { ContractManager } from './components/contracts/ContractManager';
import { SuperAdminDashboard } from './components/admin/SuperAdminDashboard';
import { LoginView } from './components/auth/LoginView';
import { ChangePasswordModal } from './components/auth/ChangePasswordModal';
import { ShieldAlert, Building2 } from 'lucide-react';

import { apiService } from './services/apiService';
import { storageService } from './services/storageService';
import { useToast } from './context/ToastContext';
import {
  Property,
  Customer,
  FollowUp,
  CommissionRecord,
  ConversionRecord,
  ContactInteraction,
  User,
  AppSettings,
  Tenant,
  Contract,
  FinancialTransaction,
  PlatformStats
} from './types';

export default function App() {
  const { showToast } = useToast();

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isCheckingAuth, setIsCheckingAuth] = useState<boolean>(true);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState<boolean>(false);

  // Navigation State
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [globalSearchQuery, setGlobalSearchQuery] = useState<string>('');

  // Multi-Tenant State
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [currentTenantId, setCurrentTenantId] = useState<string>(() => {
    return apiService.getTenantId() || 'tenant-negin-1';
  });
  const [platformStats, setPlatformStats] = useState<PlatformStats | null>(null);

  // Theme State
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('amlak_theme_v1');
      if (stored) return stored === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('amlak_theme_v1', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('amlak_theme_v1', 'light');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(!isDark);

  // Core Data State (Isolated per Tenant)
  const [properties, setProperties] = useState<Property[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [followUps, setFollowUps] = useState<FollowUp[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [transactions, setTransactions] = useState<FinancialTransaction[]>([]);
  const [commissions, setCommissions] = useState<CommissionRecord[]>([]);
  const [conversions, setConversions] = useState<ConversionRecord[]>([]);
  const [contacts, setContacts] = useState<ContactInteraction[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Modals & Selected items
  const [isPropertyFormOpen, setIsPropertyFormOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  const [selectedPropertyDetail, setSelectedPropertyDetail] = useState<Property | null>(null);

  const [isCustomerFormOpen, setIsCustomerFormOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [selectedCustomerDetail, setSelectedCustomerDetail] = useState<Customer | null>(null);

  // Converter initial values when triggered from property
  const [converterInitialValues, setConverterInitialValues] = useState<{ mortgage: number; rent: number }>({
    mortgage: 500000000,
    rent: 15000000
  });

  // Commission initial values when triggered from property
  const [commissionInitialValues, setCommissionInitialValues] = useState<{
    dealType: 'sale' | 'rent';
    amount: number;
    mortgage: number;
    rent: number;
  }>({
    dealType: 'sale',
    amount: 8500000000,
    mortgage: 500000000,
    rent: 15000000
  });

  // Load all data from Backend SQLite API with storageService fallback
  const loadAgencyData = useCallback(async (tenantId: string) => {
    setIsLoading(true);
    apiService.setTenantId(tenantId);
    setCurrentTenantId(tenantId);

    try {
      // Parallel fetch from multi-tenant REST API
      const [
        tenantsRes,
        propsRes,
        custRes,
        tasksRes,
        contractsRes,
        financesRes,
        usersRes,
        convRes,
        statsRes
      ] = await Promise.allSettled([
        apiService.getTenants(),
        apiService.getProperties(),
        apiService.getCustomers(),
        apiService.getTasks(),
        apiService.getContracts(),
        apiService.getFinances(),
        apiService.getUsers(),
        apiService.getConversions(),
        apiService.getPlatformStats()
      ]);

      if (tenantsRes.status === 'fulfilled') setTenants(tenantsRes.value);
      if (propsRes.status === 'fulfilled') setProperties(propsRes.value);
      if (custRes.status === 'fulfilled') setCustomers(custRes.value);
      if (tasksRes.status === 'fulfilled') setFollowUps(tasksRes.value);
      if (contractsRes.status === 'fulfilled') setContracts(contractsRes.value);
      if (financesRes.status === 'fulfilled') setTransactions(financesRes.value);
      if (convRes.status === 'fulfilled') setConversions(convRes.value);
      if (statsRes.status === 'fulfilled') setPlatformStats(statsRes.value);

      if (usersRes.status === 'fulfilled' && usersRes.value.length > 0) {
        setUsers(usersRes.value);
        // Retain or set active user
        setCurrentUser((prev) => {
          if (prev && usersRes.value.some((u) => u.id === prev.id)) return prev;
          return usersRes.value[0];
        });
      }

      // Settings from tenant
      const activeTenant = tenantsRes.status === 'fulfilled'
        ? tenantsRes.value.find((t) => t.id === tenantId)
        : null;

      if (activeTenant?.settings) {
        setSettings(activeTenant.settings);
      } else {
        setSettings({
          agencyName: activeTenant?.name || 'املاک نگین پایتخت',
          managerName: activeTenant?.manager_name || 'حاج محمود کبیری',
          phone: activeTenant?.phone || '02122003344',
          city: activeTenant?.city || 'تهران',
          address: activeTenant?.address || 'سعادت آباد، میدان کاج',
          currencyUnit: 'تومان',
          defaultConversionRate: 3.0,
          saleCommissionRateBuyer: 0.25,
          saleCommissionRateSeller: 0.25,
          rentCommissionDays: 7,
          vatPercent: 10,
          agentCommissionSharePercent: 50,
          licenseNumber: activeTenant?.license_number || '۱۴۰۳/۹۸۷۲'
        });
      }

      // Save to local tenant cache for seamless offline resilience
      if (propsRes.status === 'fulfilled') {
        storageService.saveAgencyCache(tenantId, {
          properties: propsRes.value,
          customers: custRes.status === 'fulfilled' ? custRes.value : undefined,
          followUps: tasksRes.status === 'fulfilled' ? tasksRes.value : undefined,
          users: usersRes.status === 'fulfilled' ? usersRes.value : undefined,
          settings: activeTenant?.settings || undefined
        });
      }
    } catch (err) {
      console.warn('[Data Load Warning - Falling back to local offline storage]', err);
      // Fallback to local storage
      setProperties(storageService.getProperties());
      setCustomers(storageService.getCustomers());
      setFollowUps(storageService.getFollowUps());
      setCommissions(storageService.getCommissions());
      setConversions(storageService.getConversionHistory());
      setContacts(storageService.getContacts());
      const localUsers = storageService.getUsers();
      setUsers(localUsers);
      setCurrentUser(storageService.getCurrentUser() || localUsers[0]);
      setSettings(storageService.getSettings());
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial auth session check
  useEffect(() => {
    const initSession = async () => {
      setIsCheckingAuth(true);
      const token = apiService.getToken();
      if (!token) {
        setIsCheckingAuth(false);
        setIsAuthenticated(false);
        return;
      }

      try {
        const res = await apiService.getMe();
        if (res && res.user) {
          setCurrentUser(res.user);
          const tenantId = res.tenant?.id || res.user.tenantId || 'tenant-negin-1';
          setCurrentTenantId(tenantId);
          apiService.setTenantId(tenantId);
          setIsAuthenticated(true);
          await loadAgencyData(tenantId);
        } else {
          apiService.setToken(null);
          setIsAuthenticated(false);
        }
      } catch {
        apiService.setToken(null);
        setIsAuthenticated(false);
      } finally {
        setIsCheckingAuth(false);
      }
    };

    initSession();
  }, [loadAgencyData]);

  // Login handler
  const handleLoginSuccess = async (user: User, tenant: Tenant, token: string) => {
    apiService.setToken(token);
    const tenantId = tenant?.id || user.tenantId || 'tenant-negin-1';
    apiService.setTenantId(tenantId);
    setCurrentUser(user);
    setCurrentTenantId(tenantId);
    setIsAuthenticated(true);
    await loadAgencyData(tenantId);
    showToast(`خوش آمدید، ${user.fullName} (${tenant?.name || 'سامانه مدیریت املاک'})`, 'success');
  };

  // Logout handler
  const handleLogout = async () => {
    try {
      await apiService.logout();
    } catch {
      apiService.setToken(null);
    }
    setIsAuthenticated(false);
    setCurrentUser(null);
    showToast('با موفقیت از حساب کاربری خارج شدید.', 'info');
  };

  // Handle Tenant Switch (Multi-Tenant proof)
  const handleSwitchTenant = async (tenantId: string) => {
    showToast(`در حال بارگذاری محیط تفکیک‌شده آژانس...`, 'info', 2000);
    await loadAgencyData(tenantId);
    showToast(`محیط کار به آژانس انتخابی منتقل شد.`, 'success', 3000);
  };

  // Handle Create New Tenant (Super Admin)
  const handleCreateTenant = async (tenantData: any) => {
    try {
      await apiService.createTenant(tenantData);
      showToast('آژانس جدید با موفقیت راه‌اندازی گردید.', 'success');
      await loadAgencyData(currentTenantId);
    } catch (err: any) {
      showToast(err.message || 'خطا در ثبت آژانس', 'error');
    }
  };

  // Handlers for Properties
  const handleSaveProperty = async (propData: any) => {
    try {
      if (editingProperty) {
        await apiService.updateProperty(editingProperty.id, propData);
        showToast('ملک با موفقیت بروزرسانی شد.', 'success');
      } else {
        await apiService.createProperty(propData);
        showToast('فایل ملکی جدید در دیتابیس ثبت شد.', 'success');
      }
      await loadAgencyData(currentTenantId);
      setEditingProperty(null);
      setIsPropertyFormOpen(false);
    } catch (err: any) {
      // Local fallback
      if (editingProperty) {
        storageService.updateProperty(editingProperty.id, propData);
      } else {
        storageService.addProperty(propData);
      }
      setEditingProperty(null);
      setIsPropertyFormOpen(false);
      await loadAgencyData(currentTenantId);
      showToast('ملک در حافظه ذخیره گردید.', 'info');
    }
  };

  const handleDeleteProperty = async (id: string) => {
    try {
      await apiService.deleteProperty(id);
      showToast('فایل ملکی با موفقیت حذف گردید.', 'info');
    } catch (err: any) {
      storageService.deleteProperty(id);
      showToast('فایل ملکی حذف گردید.', 'info');
    }
    await loadAgencyData(currentTenantId);
    if (selectedPropertyDetail?.id === id) {
      setSelectedPropertyDetail(null);
    }
  };

  const handleToggleFavoriteProperty = async (id: string) => {
    try {
      const prop = properties.find((p) => p.id === id);
      if (prop) {
        await apiService.updateProperty(id, { isFavorite: !prop.isFavorite });
      }
    } catch (err) {
      storageService.toggleFavoriteProperty(id);
    }
    await loadAgencyData(currentTenantId);
    if (selectedPropertyDetail?.id === id) {
      setSelectedPropertyDetail((prev) => (prev ? { ...prev, isFavorite: !prev.isFavorite } : null));
    }
  };

  // Handlers for Customers
  const handleSaveCustomer = async (customerData: any) => {
    try {
      if (editingCustomer) {
        await apiService.updateCustomer(editingCustomer.id, customerData);
        showToast('اطلاعات مشتری بروزرسانی شد.', 'success');
      } else {
        await apiService.createCustomer(customerData);
        showToast('مشتری جدید در CRM ثبت گردید.', 'success');
      }
    } catch (err) {
      if (editingCustomer) {
        storageService.updateCustomer(editingCustomer.id, customerData);
      } else {
        storageService.addCustomer(customerData);
      }
      showToast('مشتری ذخیره گردید.', 'info');
    }
    await loadAgencyData(currentTenantId);
    setEditingCustomer(null);
    setIsCustomerFormOpen(false);
  };

  const handleDeleteCustomer = async (id: string) => {
    try {
      await apiService.deleteCustomer(id);
      showToast('مشتری با موفقیت حذف گردید.', 'info');
    } catch (err) {
      storageService.deleteCustomer(id);
    }
    await loadAgencyData(currentTenantId);
    if (selectedCustomerDetail?.id === id) {
      setSelectedCustomerDetail(null);
    }
  };

  const handleAddCustomerInteraction = async (interactionData: Omit<ContactInteraction, 'id'>) => {
    try {
      if (selectedCustomerDetail) {
        await apiService.addCustomerInteraction(selectedCustomerDetail.id, interactionData);
        showToast('گزارش تماس با موفقیت ثبت شد.', 'success');
      }
    } catch (err) {
      storageService.addContact(interactionData);
    }
    await loadAgencyData(currentTenantId);
  };

  // Handlers for Contracts & Transactions
  const handleAddContract = async (contractData: Partial<Contract>) => {
    await apiService.createContract(contractData);
    await loadAgencyData(currentTenantId);
  };

  const handleAddTransaction = async (transData: Partial<FinancialTransaction>) => {
    await apiService.createFinancialTransaction(transData);
    await loadAgencyData(currentTenantId);
  };

  // Handlers for Tasks
  const handleToggleTaskStatus = async (taskId: string, status?: FollowUp['status']) => {
    try {
      await apiService.toggleTask(taskId);
    } catch (err) {
      const task = followUps.find((t) => t.id === taskId);
      if (task) {
        const newStatus = status || (task.status === 'completed' ? 'pending' : 'completed');
        storageService.updateFollowUpStatus(taskId, newStatus);
      }
    }
    await loadAgencyData(currentTenantId);
  };

  const handleAddTask = async (taskData: Omit<FollowUp, 'id' | 'createdAt'>) => {
    try {
      await apiService.createTask(taskData);
      showToast('یادآوری جدید ثبت شد.', 'success');
    } catch (err) {
      storageService.addFollowUp(taskData);
    }
    await loadAgencyData(currentTenantId);
  };

  const handleDeleteTask = async (taskId: string) => {
    try {
      await apiService.deleteTask(taskId);
      showToast('وظیفه حذف شد.', 'info');
    } catch (err) {
      storageService.deleteFollowUp(taskId);
    }
    await loadAgencyData(currentTenantId);
  };

  // Conversions
  const handleSaveConversion = async (rec: Omit<ConversionRecord, 'id'>) => {
    try {
      await apiService.createConversion(rec);
    } catch (err) {
      storageService.addConversionRecord(rec);
    }
    await loadAgencyData(currentTenantId);
  };

  const handleClearConversions = async () => {
    try {
      await apiService.clearConversions();
    } catch (err) {
      storageService.clearConversionHistory();
    }
    await loadAgencyData(currentTenantId);
  };

  // Settings & Users
  const handleUpdateSettings = async (newSettings: Partial<AppSettings>) => {
    try {
      if (settings) {
        const merged = { ...settings, ...newSettings };
        await apiService.updateSettings(merged);
        setSettings(merged);
        showToast('تنظیمات آژانس ذخیره شد.', 'success');
      }
    } catch (err) {
      storageService.updateSettings(newSettings);
      showToast('تنظیمات ذخیره شد.', 'info');
    }
    await loadAgencyData(currentTenantId);
  };

  const handleAddUser = async (user: Omit<User, 'id'>) => {
    try {
      await apiService.createUser(user);
      showToast('مشاور جدید تعریف شد.', 'success');
    } catch (err) {
      storageService.addUser(user);
    }
    await loadAgencyData(currentTenantId);
  };

  const handleResetData = async () => {
    await apiService.resetTenantData();
    await loadAgencyData(currentTenantId);
  };

  const handleExportData = () => {
    const backupData = {
      tenant_id: currentTenantId,
      agency: settings?.agencyName,
      exported_at: new Date().toISOString(),
      properties,
      customers,
      contracts,
      transactions,
      followUps
    };
    const jsonStr = JSON.stringify(backupData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `amlak_${currentTenantId}_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Cross-module actions
  const handleOpenConverterWithProperty = (mortgage: number, rent: number) => {
    setConverterInitialValues({ mortgage, rent });
    setCurrentTab('converter');
  };

  const handleOpenCommissionWithProperty = (
    dealType: 'sale' | 'rent',
    amount: number,
    mortgage?: number,
    rent?: number
  ) => {
    setCommissionInitialValues({
      dealType,
      amount,
      mortgage: mortgage || 0,
      rent: rent || 0
    });
    setCurrentTab('commission');
  };

  // Stats for badges
  const todayStr = new Date().toISOString().split('T')[0];
  const todayTasks = followUps.filter((f) => f.dueDate === todayStr && f.status !== 'completed');
  const favoriteProperties = properties.filter((p) => p.isFavorite);

  // Route permission check
  const isSuperAdmin = currentUser?.role === 'super_admin';
  const isOwner = currentUser?.role === 'owner';
  const userPerms = (currentUser?.permissions || []).map((p) => p.replace(':', '.'));

  const hasRouteAccess = (tab: string): boolean => {
    if (isSuperAdmin || isOwner || userPerms.includes('*')) return true;
    if (tab === 'superadmin') return isSuperAdmin;
    if (tab === 'contracts') return userPerms.some((p) => p.startsWith('contracts') || p.startsWith('finances'));
    if (tab === 'admin') return userPerms.some((p) => p.startsWith('settings') || p.startsWith('users') || p.startsWith('backup'));
    return true;
  };

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950 text-slate-500 text-sm gap-4" dir="rtl">
        <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30 animate-pulse">
          <Building2 className="w-6 h-6" />
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-medium">
          <div className="w-4 h-4 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          <span>در حال بررسی نشست امنیتی کاربر...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !currentUser) {
    return (
      <LoginView
        onLoginSuccess={handleLoginSuccess}
        isDark={isDark}
      />
    );
  }

  if (!settings) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-900 text-slate-500 text-sm gap-3" dir="rtl">
        <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
        <span>در حال بارگذاری پایگاه داده امن و چندمستأجره املاک...</span>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200" dir="rtl">
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={(tab) => {
            setCurrentTab(tab);
            setGlobalSearchQuery('');
          }}
          propertiesCount={properties.length}
          customersCount={customers.length}
          todayTasksCount={todayTasks.length}
          favoritesCount={favoriteProperties.length}
          contractsCount={contracts.length}
          currentUser={currentUser}
          agencyName={settings.agencyName}
          agencyPhone={settings.phone}
          onLogout={handleLogout}
        />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto">
          {/* Top Sticky Navbar */}
          <Navbar
            currentTab={currentTab}
            isDark={isDark}
            onToggleTheme={toggleTheme}
            currentUser={currentUser}
            todayTasks={todayTasks}
            onOpenNewProperty={() => {
              setEditingProperty(null);
              setIsPropertyFormOpen(true);
            }}
            onOpenNewCustomer={() => {
              setEditingCustomer(null);
              setIsCustomerFormOpen(true);
            }}
            onOpenNewTask={() => setCurrentTab('followups')}
            onOpenNewContract={() => setCurrentTab('contracts')}
            onNavigateToTasks={() => setCurrentTab('followups')}
            searchQuery={globalSearchQuery}
            onSearchChange={setGlobalSearchQuery}
            agencyName={settings.agencyName}
            tenants={tenants}
            currentTenantId={currentTenantId}
            onSwitchTenant={handleSwitchTenant}
            onLogout={handleLogout}
            onChangePassword={() => setIsChangePasswordOpen(true)}
          />

          {/* Dynamic View Body */}
          <main className="flex-1 p-3 sm:p-5 lg:p-6 max-w-7xl w-full mx-auto pb-24 lg:pb-12">
            {!hasRouteAccess(currentTab) && (
              <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 text-center max-w-lg mx-auto mt-12 space-y-4">
                <div className="w-14 h-14 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto">
                  <ShieldAlert className="w-7 h-7" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">عدم دسترسی به این بخش</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  حساب کاربری شما دارای مجوزهای لازم جهت مشاهده یا مدیریت این بخش نمی‌باشد. لطفاً با مدیر آژانس یا پشتیبانی تماس بگیرید.
                </p>
                <button
                  onClick={() => setCurrentTab('dashboard')}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20"
                >
                  بازگشت به پیشخوان کاربری
                </button>
              </div>
            )}

            {/* VIEW 1: Dashboard */}
            {hasRouteAccess(currentTab) && currentTab === 'dashboard' && (
              <DashboardView
                properties={properties}
                customers={customers}
                followUps={followUps}
                commissions={commissions}
                onNavigateTab={(tab) => {
                  setCurrentTab(tab);
                  setGlobalSearchQuery('');
                }}
                onOpenNewProperty={() => {
                  setEditingProperty(null);
                  setIsPropertyFormOpen(true);
                }}
                onOpenNewCustomer={() => {
                  setEditingCustomer(null);
                  setIsCustomerFormOpen(true);
                }}
                onOpenNewTask={() => setCurrentTab('followups')}
                onToggleTaskStatus={(taskId, status) => handleToggleTaskStatus(taskId, status)}
                onSelectProperty={(prop) => setSelectedPropertyDetail(prop)}
                onSelectCustomer={(cust) => setSelectedCustomerDetail(cust)}
              />
            )}

            {/* VIEW 2: Property List */}
            {hasRouteAccess(currentTab) && currentTab === 'properties' && (
              <PropertyList
                properties={properties}
                currentUser={currentUser}
                onOpenNewProperty={() => {
                  setEditingProperty(null);
                  setIsPropertyFormOpen(true);
                }}
                onSelectProperty={(prop) => setSelectedPropertyDetail(prop)}
                onToggleFavorite={handleToggleFavoriteProperty}
                externalSearchQuery={globalSearchQuery}
              />
            )}

            {/* VIEW 3: Favorites (Filtered Property List) */}
            {hasRouteAccess(currentTab) && currentTab === 'favorites' && (
              <div className="space-y-4">
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 text-xs font-bold text-amber-800 dark:text-amber-300">
                  ⭐️ نمایش فایل‌های ملکی نشان‌شده و منتخب شما ({favoriteProperties.length} فایل)
                </div>
                <PropertyList
                  properties={favoriteProperties}
                  currentUser={currentUser}
                  onOpenNewProperty={() => {
                    setEditingProperty(null);
                    setIsPropertyFormOpen(true);
                  }}
                  onSelectProperty={(prop) => setSelectedPropertyDetail(prop)}
                  onToggleFavorite={handleToggleFavoriteProperty}
                  externalSearchQuery={globalSearchQuery}
                />
              </div>
            )}

            {/* VIEW 4: Customers CRM */}
            {hasRouteAccess(currentTab) && currentTab === 'customers' && (
              <CustomerList
                customers={customers}
                currentUser={currentUser}
                onOpenNewCustomer={() => {
                  setEditingCustomer(null);
                  setIsCustomerFormOpen(true);
                }}
                onSelectCustomer={(cust) => setSelectedCustomerDetail(cust)}
                externalSearchQuery={globalSearchQuery}
              />
            )}

            {/* VIEW 5: Contracts & Finances (NEW MODULE) */}
            {hasRouteAccess(currentTab) && currentTab === 'contracts' && (
              <ContractManager
                contracts={contracts}
                transactions={transactions}
                properties={properties}
                customers={customers}
                onAddContract={handleAddContract}
                onAddTransaction={handleAddTransaction}
                showToast={showToast}
              />
            )}

            {/* VIEW 6: Follow-ups / Task Manager */}
            {hasRouteAccess(currentTab) && currentTab === 'followups' && (
              <TaskManager
                tasks={followUps}
                customers={customers}
                onToggleTask={(id) => handleToggleTaskStatus(id)}
                onAddTask={handleAddTask}
                onDeleteTask={handleDeleteTask}
                onSelectCustomer={(c) => setSelectedCustomerDetail(c)}
              />
            )}

            {/* VIEW 7: Mortgage & Rent Converter */}
            {hasRouteAccess(currentTab) && currentTab === 'converter' && (
              <MortgageRentConverter
                initialMortgage={converterInitialValues.mortgage}
                initialRent={converterInitialValues.rent}
                history={conversions}
                onSaveRecord={handleSaveConversion}
                onClearHistory={handleClearConversions}
                defaultRatePercent={settings.defaultConversionRate}
              />
            )}

            {/* VIEW 8: Commission Calculator */}
            {hasRouteAccess(currentTab) && currentTab === 'commission' && (
              <CommissionCalculator
                initialDealType={commissionInitialValues.dealType}
                initialAmount={commissionInitialValues.amount}
                initialMortgage={commissionInitialValues.mortgage}
                initialRent={commissionInitialValues.rent}
              />
            )}

            {/* VIEW 9: Admin & Settings */}
            {hasRouteAccess(currentTab) && currentTab === 'admin' && (
              <SettingsView
                settings={settings}
                users={users}
                onUpdateSettings={handleUpdateSettings}
                onAddUser={handleAddUser}
                onResetData={handleResetData}
                onExportData={handleExportData}
              />
            )}

            {/* VIEW 10: Super Admin Platform Control (SaaS Multi-Tenant) */}
            {hasRouteAccess(currentTab) && currentTab === 'superadmin' && (
              <SuperAdminDashboard
                stats={platformStats}
                tenants={tenants}
                currentTenantId={currentTenantId}
                onSwitchTenant={handleSwitchTenant}
                onCreateTenant={handleCreateTenant}
                showToast={showToast}
              />
            )}
          </main>
        </div>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          setGlobalSearchQuery('');
        }}
        todayTasksCount={todayTasks.length}
      />

      {/* MODAL 1: Property Form (Add / Edit) */}
      <PropertyFormModal
        isOpen={isPropertyFormOpen}
        onClose={() => {
          setIsPropertyFormOpen(false);
          setEditingProperty(null);
        }}
        onSave={handleSaveProperty}
        initialProperty={editingProperty}
      />

      {/* MODAL 2: Property Detail */}
      <PropertyDetailModal
        property={selectedPropertyDetail}
        isOpen={Boolean(selectedPropertyDetail)}
        onClose={() => setSelectedPropertyDetail(null)}
        currentUser={currentUser}
        onEdit={(prop) => {
          setSelectedPropertyDetail(null);
          setEditingProperty(prop);
          setIsPropertyFormOpen(true);
        }}
        onDelete={handleDeleteProperty}
        onToggleFavorite={handleToggleFavoriteProperty}
        onOpenConverterWithProperty={handleOpenConverterWithProperty}
        onOpenCommissionWithProperty={handleOpenCommissionWithProperty}
        customers={customers}
        onSelectCustomer={(cust) => {
          setSelectedPropertyDetail(null);
          setSelectedCustomerDetail(cust);
        }}
      />

      {/* MODAL 3: Customer Form (Add / Edit) */}
      <CustomerFormModal
        isOpen={isCustomerFormOpen}
        onClose={() => {
          setIsCustomerFormOpen(false);
          setEditingCustomer(null);
        }}
        onSave={handleSaveCustomer}
        initialCustomer={editingCustomer}
      />

      {/* MODAL 4: Customer Detail (with Call log, Smart matching properties) */}
      <CustomerDetailModal
        customer={selectedCustomerDetail}
        isOpen={Boolean(selectedCustomerDetail)}
        onClose={() => setSelectedCustomerDetail(null)}
        currentUser={currentUser}
        onEdit={(cust) => {
          setSelectedCustomerDetail(null);
          setEditingCustomer(cust);
          setIsCustomerFormOpen(true);
        }}
        onDelete={handleDeleteCustomer}
        interactions={contacts}
        onAddInteraction={handleAddCustomerInteraction}
        onAddFollowUp={handleAddTask}
        properties={properties}
        onSelectProperty={(prop) => {
          setSelectedCustomerDetail(null);
          setSelectedPropertyDetail(prop);
        }}
      />

      {/* MODAL 5: Change Password Modal */}
      <ChangePasswordModal
        isOpen={isChangePasswordOpen}
        onClose={() => setIsChangePasswordOpen(false)}
        onSuccess={() => showToast('کلمه عبور با موفقیت تغییر یافت.', 'success')}
      />
    </div>
  );
}
