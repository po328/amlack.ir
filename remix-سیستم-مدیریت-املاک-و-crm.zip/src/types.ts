export type PropertyType = 
  | 'apartment'    // آپارتمان
  | 'villa'        // ویلا
  | 'commercial'   // تجاری / مغازه
  | 'office'       // اداری
  | 'land'         // زمین / کلنگی
  | 'penthouse';   // پنت‌هاوس

export type DealType = 
  | 'sale'         // فروش
  | 'rent'         // رهن و اجاره
  | 'presale';     // پیش‌فروش

export type PropertyStatus = 
  | 'active'       // فعال
  | 'negotiating'  // در حال مذاکره
  | 'sold'         // فروخته شده
  | 'rented'       // اجاره داده شده
  | 'archived';    // بایگانی

export interface Property {
  id: string;
  code: string;               // کد فایل مانند "ملک-۱۰۴"
  title: string;              // عنوان
  propertyType: PropertyType; // نوع ملک
  dealType: DealType;         // نوع معامله
  area: number;               // متراژ به متر مربع
  rooms: number;              // تعداد اتاق خواب
  floor?: number;             // طبقه
  totalFloors?: number;       // تعداد کل طبقات
  yearBuilt?: number;         // سال ساخت
  salePrice?: number;         // قیمت کل فروش به تومان
  pricePerMeter?: number;     // قیمت هر متر
  mortgagePrice?: number;     // مبلغ رهن به تومان
  rentPrice?: number;         // مبلغ اجاره به تومان
  address: string;            // آدرس
  city: string;               // شهر
  district: string;           // منطقه / محله (مثلا سعادت آباد، الهیه)
  description: string;        // توضیحات
  features: string[];         // امکانات (آسانسور، پارکینگ، انباری، ...)
  images: string[];           // لینک‌های عکس ملک
  status: PropertyStatus;     // وضعیت فایل
  isFavorite: boolean;        // نشان شده
  ownerName?: string;         // نام مالک
  ownerPhone?: string;        // شماره تماس مالک
  assignedAgentName?: string; // مشاور مسئول
  createdAt: string;          // تاریخ ثبت
  updatedAt: string;
}

export type CustomerType = 
  | 'buyer'        // خریدار
  | 'tenant'       // مستاجر
  | 'seller'       // فروشنده / مالک
  | 'landlord'     // موجر
  | 'investor';    // سرمایه‌گذار

export type CustomerStatus = 
  | 'active'       // فعال
  | 'in_progress'  // در حال پیگیری
  | 'deal_closed'  // قرارداد منعقد شد
  | 'cancelled';   // لغو / انصراف

export interface Customer {
  id: string;
  fullName: string;
  phone: string;
  email?: string;
  customerType: CustomerType;
  dealType: 'buy' | 'rent' | 'sell' | 'let';
  status: CustomerStatus;
  preferredPropertyTypes: PropertyType[];
  minArea?: number;
  maxArea?: number;
  minRooms?: number;
  preferredDistricts: string[];
  budgetMin?: number;
  budgetMax?: number;
  mortgageMax?: number;
  rentMax?: number;
  notes?: string;
  createdAt: string;
  lastContactDate?: string;
}

export interface ContactInteraction {
  id: string;
  customerId: string;
  customerName: string;
  type: 'call' | 'visit' | 'meeting' | 'message';
  date: string;
  notes: string;
  result?: string;
}

export interface FollowUp {
  id: string;
  title: string;
  customerId?: string;
  customerName?: string;
  propertyId?: string;
  propertyTitle?: string;
  dueDate: string;          // YYYY-MM-DD
  dueTime?: string;         // HH:mm
  priority: 'high' | 'medium' | 'low';
  status: 'pending' | 'completed' | 'cancelled';
  notes?: string;
  createdAt: string;
}

export interface CommissionRecord {
  id: string;
  dealType: 'sale' | 'rent';
  propertyCode: string;
  propertyTitle: string;
  customerName: string;
  dealAmount: number;         // مبلغ کل فروش یا معادل رهن
  mortgageAmount?: number;
  rentAmount?: number;
  commissionTotal: number;    // کل کمیسیون دریافتی
  agencyShare: number;        // سهم آژانس
  agentShare: number;         // سهم مشاور
  agentName: string;
  taxAmount: number;          // مالیات بر ارزش افزوده
  date: string;
  notes?: string;
}

export interface ConversionRecord {
  id: string;
  mortgage: number;
  rent: number;
  ratePercent: number;        // e.g. 3.0
  fullMortgage: number;       // معادل رهن کامل
  fullRent: number;           // معادل اجاره کامل
  date: string;
}

export type UserRole = 'super_admin' | 'owner' | 'manager' | 'agent' | 'admin';

export interface User {
  id: string;
  tenant_id?: string;
  tenantId?: string;
  fullName: string;
  username: string;
  role: UserRole;
  phone: string;
  email?: string;
  avatarUrl?: string;
  isActive: boolean;
  permissions?: string[];
}

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  license_number?: string;
  manager_name: string;
  phone: string;
  email?: string;
  city: string;
  address?: string;
  subscription_plan: 'trial' | 'standard' | 'premium' | 'enterprise';
  subscription_status: 'active' | 'expired' | 'suspended';
  subscription_expires_at?: string;
  max_users?: number;
  max_properties?: number;
  settings?: AppSettings;
  created_at?: string;
}

export interface Contract {
  id: string;
  tenant_id?: string;
  contract_number: string;
  deal_type: 'sale' | 'rent' | 'presale';
  property_id?: string;
  customer_id?: string;
  owner_name: string;
  owner_phone?: string;
  client_name: string;
  client_phone?: string;
  total_amount: number;
  mortgage_amount?: number;
  rent_amount?: number;
  commission_total: number;
  agency_share: number;
  agent_share: number;
  agent_id?: string;
  agent_name?: string;
  tax_amount: number;
  contract_date: string;
  payment_status: 'pending' | 'partial' | 'paid';
  notes?: string;
  status: 'draft' | 'active' | 'completed' | 'terminated';
  created_at?: string;
}

export interface FinancialTransaction {
  id: string;
  tenant_id?: string;
  contract_id?: string;
  type: 'income' | 'expense' | 'commission';
  category: string;
  title: string;
  amount: number;
  payment_method: string;
  reference_number?: string;
  date: string;
  agent_name?: string;
  description?: string;
  status?: string;
}

export interface PlatformStats {
  summary: {
    totalTenants: number;
    totalUsers: number;
    totalProperties: number;
    totalCustomers: number;
    totalContracts: number;
    totalCommissions: number;
  };
  tenants: Array<{
    id: string;
    name: string;
    slug: string;
    city: string;
    subscription_plan: string;
    subscription_status: string;
    properties_count: number;
    customers_count: number;
    users_count: number;
    contracts_count: number;
  }>;
}

export interface AppSettings {
  agencyName: string;
  managerName: string;
  phone: string;
  city: string;
  address: string;
  currencyUnit: string;        // 'تومان'
  defaultConversionRate: number; // نرخ تبدیل (مثلا ۳.۰ درصد = ۳۰ هزار تومان به ازای هر میلیون)
  saleCommissionRateBuyer: number;  // درصد کمیسیون خریدار (مثلا ۰.۲۵ یا ۰.۵ درصد)
  saleCommissionRateSeller: number; // درصد کمیسیون فروشنده
  rentCommissionDays: number;       // مثلا چند روز از اجاره ماهانه (معمولا یک چهارم یا ۷ روز)
  vatPercent: number;               // مالیات ارزش افزوده (مثلا ۱۰ درصد)
  agentCommissionSharePercent: number; // درصد سهم مشاور از کل کمیسیون (مثلا ۴۰ یا ۵۰ درصد)
  licenseNumber?: string;              // شماره پروانه کسب اتحادیه
}

export type ActivityAction = 
  | 'create_property'
  | 'update_property'
  | 'delete_property'
  | 'create_customer'
  | 'update_customer'
  | 'delete_customer'
  | 'add_interaction'
  | 'create_task'
  | 'complete_task'
  | 'delete_task'
  | 'save_conversion'
  | 'save_commission'
  | 'update_settings'
  | 'backup_restore';

export interface ActivityLog {
  id: string;
  action: ActivityAction;
  title: string;
  description: string;
  timestamp: string;
  userName?: string;
}
