import React from 'react';
import {
  Building2,
  Users,
  CalendarCheck,
  Coins,
  ArrowUpRight,
  Plus,
  ArrowLeftRight,
  Calculator,
  CheckCircle2,
  Clock,
  MapPin,
  Flame,
  TrendingUp,
  ChevronLeft
} from 'lucide-react';
import { Property, Customer, FollowUp, CommissionRecord } from '../../types';
import { formatToman, formatPersianDate, toPersianDigits } from '../../utils/formatters';
import { ImageWithFallback } from '../common/ImageWithFallback';

interface DashboardViewProps {
  properties: Property[];
  customers: Customer[];
  followUps: FollowUp[];
  commissions: CommissionRecord[];
  onNavigateTab: (tab: string) => void;
  onOpenNewProperty: () => void;
  onOpenNewCustomer: () => void;
  onOpenNewTask: () => void;
  onToggleTaskStatus: (taskId: string, status: FollowUp['status']) => void;
  onSelectProperty: (property: Property) => void;
  onSelectCustomer: (customer: Customer) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  properties,
  customers,
  followUps,
  commissions,
  onNavigateTab,
  onOpenNewProperty,
  onOpenNewCustomer,
  onOpenNewTask,
  onToggleTaskStatus,
  onSelectProperty,
  onSelectCustomer
}) => {
  // Stats calculations
  const totalProperties = properties.length;
  const activeProperties = properties.filter(p => p.status === 'active').length;
  const saleProperties = properties.filter(p => p.dealType === 'sale').length;
  const rentProperties = properties.filter(p => p.dealType === 'rent').length;

  const totalCustomers = customers.length;
  const activeBuyers = customers.filter(c => c.customerType === 'buyer' || c.dealType === 'buy').length;
  const activeTenants = customers.filter(c => c.customerType === 'tenant' || c.dealType === 'rent').length;

  const todayStr = new Date().toISOString().split('T')[0];
  const todayTasks = followUps.filter(f => f.dueDate === todayStr);
  const pendingTodayTasks = todayTasks.filter(f => f.status === 'pending');

  const totalCommissionRevenue = commissions.reduce((sum, c) => sum + (c.commissionTotal || 0), 0);
  const agencyCommissionRevenue = commissions.reduce((sum, c) => sum + (c.agencyShare || 0), 0);

  // Property types distribution for chart
  const typeCounts: Record<string, number> = {
    apartment: properties.filter(p => p.propertyType === 'apartment').length,
    villa: properties.filter(p => p.propertyType === 'villa').length,
    commercial: properties.filter(p => p.propertyType === 'commercial').length,
    office: properties.filter(p => p.propertyType === 'office').length,
    penthouse: properties.filter(p => p.propertyType === 'penthouse').length,
  };

  const propertyTypeLabels: Record<string, string> = {
    apartment: 'آپارتمان',
    villa: 'ویلا',
    commercial: 'تجاری',
    office: 'اداری',
    penthouse: 'پنت‌هاوس',
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Welcome Banner & Quick Actions */}
      <div className="bg-gradient-to-l from-emerald-700 via-emerald-600 to-teal-700 rounded-3xl p-5 lg:p-7 text-white shadow-lg shadow-emerald-700/15 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-white/5 rounded-full -translate-x-12 -translate-y-12 blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 backdrop-blur text-xs font-medium mb-2.5">
              <Flame className="w-3.5 h-3.5 text-amber-300" />
              <span>سیستم هوشمند املاک و CRM</span>
            </div>
            <h2 className="text-xl lg:text-2xl font-black tracking-tight">
              میز کار و داشبورد مدیریت
            </h2>
            <p className="text-xs lg:text-sm text-emerald-100 mt-1 max-w-xl">
              گزارش عملکرد لحظه‌ای فایل‌های ملکی، متقاضیان فعال، پیگیری‌های زمان‌بندی شده و درآمد کمیسیون.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onOpenNewProperty}
              className="flex items-center gap-2 bg-white text-emerald-800 hover:bg-emerald-50 px-3.5 py-2.5 rounded-2xl text-xs lg:text-sm font-bold shadow-md transition-all active:scale-95"
            >
              <Plus className="w-4 h-4 text-emerald-600" />
              <span>ثبت ملک جدید</span>
            </button>
            <button
              onClick={onOpenNewCustomer}
              className="flex items-center gap-2 bg-white/15 hover:bg-white/25 backdrop-blur text-white px-3.5 py-2.5 rounded-2xl text-xs lg:text-sm font-medium transition-all active:scale-95"
            >
              <Users className="w-4 h-4" />
              <span>ثبت متقاضی</span>
            </button>
            <button
              onClick={() => onNavigateTab('converter')}
              className="flex items-center gap-2 bg-white/15 hover:bg-white/25 backdrop-blur text-white px-3.5 py-2.5 rounded-2xl text-xs lg:text-sm font-medium transition-all active:scale-95"
            >
              <ArrowLeftRight className="w-4 h-4" />
              <span>تبدیل رهن/اجاره</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Primary Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-5">
        {/* Metric 1: Properties */}
        <div 
          onClick={() => onNavigateTab('properties')}
          className="bg-white dark:bg-slate-800/90 rounded-2xl lg:rounded-3xl p-4 lg:p-5 border border-slate-200/80 dark:border-slate-700/80 hover:border-emerald-500/50 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">فایل‌های ملکی</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Building2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl lg:text-3xl font-extrabold text-slate-900 dark:text-white">
              {totalProperties}
            </span>
            <span className="text-[11px] text-slate-400">فایل</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
            <span>فروش: {saleProperties}</span>
            <span className="text-slate-300 dark:text-slate-600">•</span>
            <span>رهن/اجاره: {rentProperties}</span>
          </div>
        </div>

        {/* Metric 2: Customers */}
        <div 
          onClick={() => onNavigateTab('customers')}
          className="bg-white dark:bg-slate-800/90 rounded-2xl lg:rounded-3xl p-4 lg:p-5 border border-slate-200/80 dark:border-slate-700/80 hover:border-blue-500/50 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">مشتریان و متقاضیان</span>
            <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl lg:text-3xl font-extrabold text-slate-900 dark:text-white">
              {totalCustomers}
            </span>
            <span className="text-[11px] text-slate-400">نفر</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
            <span>خریدار: {activeBuyers}</span>
            <span className="text-slate-300 dark:text-slate-600">•</span>
            <span>مستاجر: {activeTenants}</span>
          </div>
        </div>

        {/* Metric 3: Today's Followups */}
        <div 
          onClick={() => onNavigateTab('followups')}
          className="bg-white dark:bg-slate-800/90 rounded-2xl lg:rounded-3xl p-4 lg:p-5 border border-slate-200/80 dark:border-slate-700/80 hover:border-amber-500/50 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">پیگیری‌های امروز</span>
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <CalendarCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl lg:text-3xl font-extrabold text-slate-900 dark:text-white">
              {pendingTodayTasks.length}
            </span>
            <span className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold">اقدام باقی‌مانده</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
            <span>کل پیگیری‌های امروز: {todayTasks.length}</span>
          </div>
        </div>

        {/* Metric 4: Closed Deals & Revenue */}
        <div 
          onClick={() => onNavigateTab('commission')}
          className="bg-white dark:bg-slate-800/90 rounded-2xl lg:rounded-3xl p-4 lg:p-5 border border-slate-200/80 dark:border-slate-700/80 hover:border-purple-500/50 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">قراردادها و کمیسیون</span>
            <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Coins className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-lg lg:text-xl font-black text-slate-900 dark:text-white truncate">
              {formatToman(totalCommissionRevenue, false)}
            </div>
            <div className="text-[10px] text-purple-600 dark:text-purple-400 font-bold">تومان کل کمیسیون</div>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
            <span>سهم دفتر: {formatToman(agencyCommissionRevenue, false)}</span>
          </div>
        </div>
      </div>

      {/* Middle Grid: Charts & Analytics + Today's Urgent Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Analytical Charts Card (2 Cols) */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-700/80 shadow-xs">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-bold text-sm lg:text-base text-slate-900 dark:text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                <span>نمودار توزیع سبد ملکی و تفکیک بازار</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">وضعیت موجودی املاک به تفکیک کاربری و نوع معامله</p>
            </div>
            <button
              onClick={() => onNavigateTab('properties')}
              className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold flex items-center gap-1"
            >
              <span>مشاهده لیست</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Visual Distribution Bars */}
          <div className="space-y-3.5">
            {Object.entries(typeCounts).map(([typeKey, count]) => {
              const percent = totalProperties > 0 ? Math.round((count / totalProperties) * 100) : 0;
              return (
                <div key={typeKey} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700 dark:text-slate-300">
                      {propertyTypeLabels[typeKey] || typeKey}
                    </span>
                    <span className="text-slate-500 dark:text-slate-400 font-mono">
                      {count} فایل ({percent}٪)
                    </span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-500"
                      style={{ width: `${Math.max(percent, 4)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Deal type split ratio */}
          <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-700/80 grid grid-cols-2 gap-4">
            <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/50">
              <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">املاک فروش و پیش‌فروش</div>
              <div className="text-lg font-black text-emerald-700 dark:text-emerald-400 mt-1">
                {saleProperties} فایل ({totalProperties > 0 ? Math.round((saleProperties / totalProperties) * 100) : 0}٪)
              </div>
              <div className="text-[11px] text-emerald-600/80 dark:text-emerald-400/80 mt-0.5">آماده عقد مبایعه‌نامه</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-teal-50 dark:bg-teal-950/30 border border-teal-100 dark:border-teal-900/50">
              <div className="text-xs font-semibold text-teal-800 dark:text-teal-300">املاک رهن و اجاره</div>
              <div className="text-lg font-black text-teal-700 dark:text-teal-400 mt-1">
                {rentProperties} فایل ({totalProperties > 0 ? Math.round((rentProperties / totalProperties) * 100) : 0}٪)
              </div>
              <div className="text-[11px] text-teal-600/80 dark:text-teal-400/80 mt-0.5">آماده تنظیم اجاره‌نامه</div>
            </div>
          </div>
        </div>

        {/* Today's Urgent Tasks (1 Col) */}
        <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-700/80 shadow-xs flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">پیگیری‌های امروز</h3>
            </div>
            <button
              onClick={onOpenNewTask}
              className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>افزودن</span>
            </button>
          </div>

          <div className="flex-1 mt-3 space-y-2.5 overflow-y-auto max-h-[320px]">
            {todayTasks.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center py-8 text-center text-slate-400">
                <CheckCircle2 className="w-10 h-10 text-emerald-500/40 mb-2" />
                <p className="text-xs">هیچ وظیفه‌ای برای امروز باقی نمانده است.</p>
                <button
                  onClick={onOpenNewTask}
                  className="mt-3 text-xs text-emerald-600 font-medium hover:underline"
                >
                  ثبت پیگیری جدید
                </button>
              </div>
            ) : (
              todayTasks.map((task) => (
                <div
                  key={task.id}
                  className={`p-3 rounded-2xl border transition-all ${
                    task.status === 'completed'
                      ? 'bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-60'
                      : 'bg-amber-50/50 dark:bg-amber-950/20 border-amber-200/60 dark:border-amber-900/40'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <button
                      onClick={() => onToggleTaskStatus(task.id, task.status === 'completed' ? 'pending' : 'completed')}
                      className={`mt-0.5 w-4 h-4 rounded-md border flex items-center justify-center transition-colors ${
                        task.status === 'completed'
                          ? 'bg-emerald-600 border-emerald-600 text-white'
                          : 'border-slate-300 dark:border-slate-600 hover:border-emerald-500'
                      }`}
                    >
                      {task.status === 'completed' && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </button>
                    <div className="flex-1 text-right">
                      <div className={`text-xs font-bold ${task.status === 'completed' ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'}`}>
                        {task.title}
                      </div>
                      {task.customerName && (
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                          مشتری: {task.customerName}
                        </div>
                      )}
                      {task.dueTime && (
                        <div className="text-[10px] text-amber-600 dark:text-amber-400 mt-1 flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3" />
                          <span>{task.dueTime}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <button
            onClick={() => onNavigateTab('followups')}
            className="w-full mt-3 py-2 text-center text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-emerald-600 bg-slate-50 dark:bg-slate-800 rounded-xl transition-colors"
          >
            مشاهده تقویم و همه پیگیری‌ها
          </button>
        </div>
      </div>

      {/* Bottom Grid: Recent Properties + Active Customers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Recent Properties Section */}
        <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-700/80 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-600" />
              <span>فایل‌های ملکی اخیر</span>
            </h3>
            <button
              onClick={() => onNavigateTab('properties')}
              className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold flex items-center gap-1"
            >
              <span>مشاهده همه ({properties.length})</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-3 space-y-3">
            {properties.slice(0, 3).map((prop) => (
              <div
                key={prop.id}
                onClick={() => onSelectProperty(prop)}
                className="flex items-center gap-3 p-2.5 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-700/50 border border-transparent hover:border-slate-100 dark:hover:border-slate-700 transition-all cursor-pointer"
              >
                <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 bg-slate-100 dark:bg-slate-700">
                  <ImageWithFallback
                    src={prop.images[0] || ''}
                    alt={prop.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0 text-right">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] px-2 py-0.5 rounded-md font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                      {prop.code}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {prop.district}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate mt-1">
                    {prop.title}
                  </h4>
                  <div className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400 mt-1">
                    {prop.dealType === 'sale'
                      ? formatToman(prop.salePrice)
                      : `رهن: ${formatToman(prop.mortgagePrice, false)} | اجاره: ${formatToman(prop.rentPrice)}`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Customers Section */}
        <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-700/80 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-600" />
              <span>متقاضیان و مشتریان فعال</span>
            </h3>
            <button
              onClick={() => onNavigateTab('customers')}
              className="text-xs text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1"
            >
              <span>مدیریت CRM ({customers.length})</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-3 space-y-3">
            {customers.slice(0, 3).map((cust) => (
              <div
                key={cust.id}
                onClick={() => onSelectCustomer(cust)}
                className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700/60 hover:border-blue-400 transition-all cursor-pointer text-right"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-slate-800 dark:text-slate-100">
                    {cust.fullName}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300">
                    {cust.customerType === 'buyer' ? 'خریدار' : cust.customerType === 'tenant' ? 'مستاجر' : 'سرمایه‌گذار'}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 truncate">
                  نیاز: {cust.preferredDistricts.join('، ')} • متراژ {cust.minArea || '-'} تا {cust.maxArea || '-'} متر
                </div>
                <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1">
                  بودجه: {cust.dealType === 'buy' ? formatToman(cust.budgetMax) : `تا رهن ${formatToman(cust.mortgageMax, false)}`}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
