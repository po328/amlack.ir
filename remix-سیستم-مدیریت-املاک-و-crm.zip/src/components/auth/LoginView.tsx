import React, { useState } from 'react';
import { 
  Building2, 
  Lock, 
  User as UserIcon, 
  Eye, 
  EyeOff, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles,
  ArrowLeft,
  Users,
  KeyRound
} from 'lucide-react';
import { apiService } from '../../services/apiService';
import { User, Tenant } from '../../types';

interface LoginViewProps {
  onLoginSuccess: (user: User, tenant: Tenant, token: string) => void;
  isDark?: boolean;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('shahr_realestate');
  const [password, setPassword] = useState('password123');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setErrorMessage('لطفاً نام کاربری و کلمه عبور را وارد نمایید.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const data = await apiService.login(username.trim(), password.trim());
      onLoginSuccess(data.user, data.tenant, data.token);
    } catch (err: any) {
      setErrorMessage(err.message || 'خطا در برقراری ارتباط با سرور.');
    } finally {
      setIsLoading(false);
    }
  };

  const presetAccounts = [
    {
      label: 'املاک شهر (مدیر آژانس)',
      roleDesc: 'مدیر آژانس • دسترسی کامل سازمانی',
      username: 'shahr_realestate',
      password: 'password123',
      color: 'emerald',
      badge: 'آژانس A'
    },
    {
      label: 'سارا عباسی (مشاور امور مشتریان)',
      roleDesc: 'مشاور CRM • دسترسی به مشتریان و وظایف (بدون مالی)',
      username: 'sara_crm',
      password: 'password123',
      color: 'blue',
      badge: 'کارمند ۱'
    },
    {
      label: 'رضا کبیری (کارشناس فایلینگ)',
      roleDesc: 'مشاور فایل • ثبت و ویرایش املاک (بدون حذف و مالی)',
      username: 'reza_properties',
      password: 'password123',
      color: 'teal',
      badge: 'کارمند ۲'
    },
    {
      label: 'املاک مدرن (مدیر آژانس)',
      roleDesc: 'دفتر مستقل دیگر • تفکیک ۱۰۰٪ داده‌ها و فایل‌ها',
      username: 'modern_realestate',
      password: 'password123',
      color: 'indigo',
      badge: 'آژانس B'
    },
    {
      label: 'مدیر ارشد سامانه (Super Admin)',
      roleDesc: 'نظارت کلی • کنترل شعب، پلن‌ها و مانیتورینگ سیستم',
      username: 'superadmin',
      password: 'admin123456',
      color: 'purple',
      badge: 'مدیر کل'
    }
  ];

  const applyPreset = (u: string, p: string) => {
    setUsername(u);
    setPassword(p);
    setErrorMessage(null);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-50 via-slate-100 to-slate-200 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 font-sans selection:bg-emerald-500 selection:text-white transition-colors duration-200" dir="rtl">
      <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200/80 dark:border-slate-800 p-6 sm:p-8 relative overflow-hidden">
        {/* Top subtle decorative pattern */}
        <div className="absolute top-0 right-0 left-0 h-2 bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-500" />

        {/* Brand Header */}
        <div className="text-center mb-6 pt-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-emerald-600 dark:bg-emerald-500 text-white shadow-lg shadow-emerald-500/25 mb-3">
            <Building2 className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            سامانه یکپارچه مدیریت املاک
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-medium">
            پلتفرم چندمستأجره (Multi-Tenant) با تفکیک کامل داده‌ها و کنترل سطح دسترسی (RBAC)
          </p>
        </div>

        {/* Error Notification */}
        {errorMessage && (
          <div className="mb-5 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 flex items-start gap-2.5 text-rose-800 dark:text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
            <div className="leading-relaxed">{errorMessage}</div>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              نام کاربری یا شناسه آژانس
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                <UserIcon className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="مثال: shahr_realestate یا sara_crm"
                dir="ltr"
                className="w-full pr-10 pl-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/60 text-slate-900 dark:text-white text-sm font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none transition-all placeholder:text-slate-400"
                required
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                کلمه عبور امن
              </label>
              <span className="text-[11px] text-slate-400 font-medium">
                رمزنگاری PBKDF2 با سالت اختصاصی
              </span>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                dir="ltr"
                className="w-full pr-10 pl-11 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/60 text-slate-900 dark:text-white text-sm font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none transition-all"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-sm shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer mt-2"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <span>ورود امن به پنل مدیریت</span>
                <ArrowLeft className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Quick Role Selection for Verification */}
        <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              انتخاب سریع حساب کاربری برای بررسی سطوح دسترسی:
            </span>
            <span className="text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full font-mono">
              Demo Accounts
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {presetAccounts.map((p) => (
              <button
                key={p.username}
                type="button"
                onClick={() => applyPreset(p.username, p.password)}
                className={`p-2.5 rounded-xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                  username === p.username
                    ? 'border-emerald-500 bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200'
                    : 'border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-800/30'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-slate-800 dark:text-slate-200">
                    {p.label}
                  </span>
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                    {p.badge}
                  </span>
                </div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-snug line-clamp-1">
                  {p.roleDesc}
                </div>
                <div className="mt-1.5 flex items-center justify-between text-[10px] font-mono text-slate-400">
                  <span>نام: {p.username}</span>
                  <span>رمز: {p.password}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Security Badges */}
        <div className="mt-5 flex items-center justify-center gap-4 text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            ایزولاسیون کامل دیتابیس
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Lock className="w-3.5 h-3.5 text-emerald-500" />
            حفاظت در برابر Brute-force
          </span>
        </div>
      </div>
    </div>
  );
};
