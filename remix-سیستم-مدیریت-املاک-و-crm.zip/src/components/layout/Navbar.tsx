import React, { useState } from 'react';
import { 
  Sun, 
  Moon, 
  Bell, 
  Plus, 
  Building2, 
  Users, 
  CalendarCheck, 
  ChevronDown, 
  ShieldCheck, 
  UserCheck,
  Search,
  FileCheck2,
  Database,
  Building,
  LogOut,
  KeyRound,
  Shield
} from 'lucide-react';
import { User, FollowUp, Tenant } from '../../types';

interface NavbarProps {
  currentTab: string;
  isDark: boolean;
  onToggleTheme: () => void;
  currentUser: User;
  onLogout: () => void;
  onChangePassword: () => void;
  todayTasks: FollowUp[];
  onOpenNewProperty: () => void;
  onOpenNewCustomer: () => void;
  onOpenNewTask: () => void;
  onOpenNewContract?: () => void;
  onNavigateToTasks: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  agencyName: string;
  tenants?: Tenant[];
  currentTenantId?: string;
  onSwitchTenant?: (tenantId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  isDark,
  onToggleTheme,
  currentUser,
  onLogout,
  onChangePassword,
  todayTasks,
  onOpenNewProperty,
  onOpenNewCustomer,
  onOpenNewTask,
  onOpenNewContract,
  onNavigateToTasks,
  searchQuery,
  onSearchChange,
  agencyName,
  tenants = [],
  currentTenantId = 'tenant-negin-1',
  onSwitchTenant
}) => {
  const [showQuickMenu, setShowQuickMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showTaskDropdown, setShowTaskDropdown] = useState(false);
  const [showTenantDropdown, setShowTenantDropdown] = useState(false);

  const getTabTitle = (tab: string) => {
    switch (tab) {
      case 'dashboard': return 'داشبورد مدیریت';
      case 'properties': return 'فایل‌های ملکی';
      case 'customers': return 'مدیریت مشتریان (CRM)';
      case 'contracts': return 'قراردادها و امور مالی';
      case 'converter': return 'تبدیل رهن و اجاره';
      case 'commission': return 'محاسبه کمیسیون';
      case 'followups': return 'پیگیری‌ها و وظایف';
      case 'favorites': return 'فایل‌های نشان‌شده';
      case 'admin': return 'تنظیمات و پشتیبان';
      case 'superadmin': return 'مرکز کنترل کل شعب (Super Admin)';
      default: return 'مدیریت املاک';
    }
  };

  const currentTenant = tenants.find((t) => t.id === currentTenantId);

  // Permission Checks
  const isSuperAdmin = currentUser.role === 'super_admin';
  const isOwner = currentUser.role === 'owner';
  const perms = (currentUser.permissions || []).map(p => p.replace(':', '.'));

  const canAddProperty = isSuperAdmin || isOwner || perms.includes('*') || perms.some(p => p.startsWith('properties'));
  const canAddCustomer = isSuperAdmin || isOwner || perms.includes('*') || perms.some(p => p.startsWith('customers'));
  const canAddContract = isSuperAdmin || isOwner || perms.includes('*') || perms.some(p => p.startsWith('contracts') || p.startsWith('finances'));

  const getRoleLabel = () => {
    if (currentUser.role === 'super_admin') return 'مدیر ارشد سامانه (Super Admin)';
    if (currentUser.role === 'owner') return 'مدیر و مالک آژانس';
    if (currentUser.role === 'manager' || currentUser.role === 'admin') return 'مدیر داخلی';
    return 'مشاور املاک';
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur border-b border-slate-200 dark:border-slate-800 px-4 lg:px-6 py-2.5 transition-colors">
      <div className="flex items-center justify-between gap-3">
        {/* Left Side: Active Section Title + Agency Selector */}
        <div className="flex items-center gap-3">
          {/* Agency Badge: Super Admin can switch tenants; individual agencies see their own verified badge */}
          <div className="relative">
            {isSuperAdmin ? (
              <button
                onClick={() => setShowTenantDropdown(!showTenantDropdown)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 hover:bg-purple-100 dark:hover:bg-purple-900/60 border border-purple-200 dark:border-purple-800/60 transition-colors text-right"
                title="تغییر شعبه (مخصوص مدیر ارشد)"
              >
                <div className="w-6 h-6 rounded-lg bg-purple-600 text-white flex items-center justify-center font-black text-xs shadow-xs">
                  {currentTenant?.name ? currentTenant.name.slice(0, 1) : 'ش'}
                </div>
                <div className="text-right">
                  <div className="font-extrabold text-xs text-purple-900 dark:text-purple-200 flex items-center gap-1">
                    <span>{currentTenant?.name || agencyName}</span>
                    <ChevronDown className="w-3 h-3 text-purple-400" />
                  </div>
                  <div className="text-[10px] text-purple-600 dark:text-purple-400 font-medium">
                    سوپر ادمین • تغییر شعبه
                  </div>
                </div>
              </button>
            ) : (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700/60 text-right">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-black text-xs shadow-xs">
                  {currentTenant?.name ? currentTenant.name.slice(0, 1) : agencyName.slice(0, 1)}
                </div>
                <div className="text-right">
                  <div className="font-extrabold text-xs text-slate-800 dark:text-slate-100">
                    {currentTenant?.name || agencyName}
                  </div>
                  <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 inline" />
                    <span>محیط اختصاصی آژانس</span>
                  </div>
                </div>
              </div>
            )}

            {/* Tenant Switcher Dropdown (Super Admin Only) */}
            {isSuperAdmin && showTenantDropdown && (
              <div className="absolute right-0 mt-2 w-72 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700 p-2 z-50 animate-in fade-in">
                <div className="p-2 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
                  <span className="font-bold text-xs text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <Building className="w-4 h-4 text-purple-600" />
                    انتخاب آژانس املاک
                  </span>
                  <span className="text-[10px] bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 font-bold px-2 py-0.5 rounded-md">
                    Multi-Tenant
                  </span>
                </div>
                <div className="py-1 space-y-1">
                  {tenants.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => {
                        if (onSwitchTenant) onSwitchTenant(t.id);
                        setShowTenantDropdown(false);
                      }}
                      className={`w-full flex items-center justify-between p-2 rounded-xl text-xs transition-colors text-right ${
                        t.id === currentTenantId
                          ? 'bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-bold border border-purple-200 dark:border-purple-800'
                          : 'hover:bg-slate-50 dark:hover:bg-slate-700/60 text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-[11px]">
                          {t.name.slice(0, 1)}
                        </div>
                        <div>
                          <div>{t.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{t.slug}</div>
                        </div>
                      </div>
                      {t.id === currentTenantId && (
                        <span className="text-[10px] text-purple-600 font-bold">فعال</span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="hidden lg:block border-r border-slate-200 dark:border-slate-800 pr-3">
            <h1 className="text-base font-black text-slate-900 dark:text-white">
              {getTabTitle(currentTab)}
            </h1>
          </div>
        </div>

        {/* Center: Global Search Bar */}
        <div className="flex-1 max-w-md mx-2 hidden sm:block">
          <div className="relative">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="جستجو در املاک، مشتریان، شماره تماس یا کد فایل..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-3 pr-9 py-1.5 text-xs lg:text-sm rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 border border-transparent focus:border-emerald-500 focus:bg-white dark:focus:bg-slate-900 focus:outline-none transition-all"
            />
            {searchQuery && (
              <button 
                onClick={() => onSearchChange('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Right Side: Quick Action + Notifications + Theme + User Menu */}
        <div className="flex items-center gap-2">
          {/* Quick Add Button (Role & Permission Scoped) */}
          {(canAddProperty || canAddCustomer || canAddContract) && (
            <div className="relative">
              <button
                onClick={() => setShowQuickMenu(!showQuickMenu)}
                className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs lg:text-sm font-medium px-3 py-2 rounded-xl shadow-xs transition-all"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden md:inline">ثبت سریع</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {showQuickMenu && (
                <div 
                  className="absolute left-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-100 dark:border-slate-700 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100"
                  onClick={() => setShowQuickMenu(false)}
                >
                  {canAddProperty && (
                    <button
                      onClick={onOpenNewProperty}
                      className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs lg:text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/60 transition-colors text-right"
                    >
                      <Building2 className="w-4 h-4 text-emerald-600" />
                      <span>ثبت فایل ملکی جدید</span>
                    </button>
                  )}
                  {canAddCustomer && (
                    <button
                      onClick={onOpenNewCustomer}
                      className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs lg:text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/60 transition-colors text-right"
                    >
                      <Users className="w-4 h-4 text-blue-600" />
                      <span>ثبت مشتری جدید</span>
                    </button>
                  )}
                  <button
                    onClick={onOpenNewTask}
                    className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs lg:text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/60 transition-colors text-right"
                  >
                    <CalendarCheck className="w-4 h-4 text-amber-600" />
                    <span>ثبت پیگیری / یادآوری</span>
                  </button>
                  {canAddContract && onOpenNewContract && (
                    <button
                      onClick={onOpenNewContract}
                      className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs lg:text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/60 transition-colors text-right border-t border-slate-100 dark:border-slate-700"
                    >
                      <FileCheck2 className="w-4 h-4 text-purple-600" />
                      <span>ثبت قرارداد رسمی</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Today Tasks Notification Badge */}
          <div className="relative">
            <button
              onClick={() => setShowTaskDropdown(!showTaskDropdown)}
              className="relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="پیگیری‌های امروز"
            >
              <Bell className="w-4 h-4 lg:w-5 lg:h-5" />
              {todayTasks.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              )}
            </button>

            {showTaskDropdown && (
              <div className="absolute left-0 mt-2 w-72 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700 p-3 z-50">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-700">
                  <span className="font-bold text-xs text-slate-800 dark:text-slate-100">
                    پیگیری‌های امروز ({todayTasks.length})
                  </span>
                  <button
                    onClick={() => {
                      setShowTaskDropdown(false);
                      onNavigateToTasks();
                    }}
                    className="text-xs text-emerald-600 hover:underline"
                  >
                    مشاهده همه
                  </button>
                </div>

                <div className="mt-2 max-h-56 overflow-y-auto space-y-2">
                  {todayTasks.length === 0 ? (
                    <p className="text-center text-xs text-slate-400 py-4">پیگیری فوری برای امروز ثبت نشده است</p>
                  ) : (
                    todayTasks.map((task) => (
                      <div
                        key={task.id}
                        className="p-2 rounded-xl bg-slate-50 dark:bg-slate-700/50 text-xs border border-slate-100 dark:border-slate-700"
                      >
                        <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                          {task.title}
                        </div>
                        {task.customerName && (
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                            مشتری: {task.customerName}
                          </div>
                        )}
                        <div className="text-[10px] text-amber-600 dark:text-amber-400 mt-1 font-medium">
                          ساعت: {task.dueTime || 'در طول روز'}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Theme Toggle Button */}
          <button
            onClick={onToggleTheme}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title={isDark ? 'حالت روز' : 'حالت شب'}
          >
            {isDark ? <Sun className="w-4 h-4 lg:w-5 lg:h-5 text-amber-400" /> : <Moon className="w-4 h-4 lg:w-5 lg:h-5 text-slate-600" />}
          </button>

          {/* Authenticated User Profile & Actions Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-right cursor-pointer"
            >
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-xs ring-2 ring-emerald-500/30">
                {currentUser.fullName ? currentUser.fullName.slice(0, 1) : 'ک'}
              </div>
              <div className="hidden xl:block">
                <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  {currentUser.fullName}
                </div>
                <div className="text-[10px] text-slate-400 flex items-center gap-1">
                  {currentUser.role === 'super_admin' ? (
                    <span className="text-purple-600 dark:text-purple-400 font-bold">مدیر ارشد</span>
                  ) : currentUser.role === 'owner' ? (
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">مدیر آژانس</span>
                  ) : (
                    <span>مشاور املاک</span>
                  )}
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden xl:block" />
            </button>

            {showUserMenu && (
              <div className="absolute left-0 mt-2 w-64 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700 p-2 z-50 animate-in fade-in">
                <div className="p-2.5 border-b border-slate-100 dark:border-slate-700">
                  <div className="font-extrabold text-xs text-slate-900 dark:text-white">
                    {currentUser.fullName}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    {getRoleLabel()}
                  </div>
                  <div className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 mt-1">
                    @{currentUser.username}
                  </div>
                </div>

                <div className="py-1.5 space-y-1">
                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      onChangePassword();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/60 transition-colors text-right cursor-pointer"
                  >
                    <KeyRound className="w-4 h-4 text-amber-500" />
                    <span>تغییر کلمه عبور حساب</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      onLogout();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors text-right cursor-pointer font-bold border-t border-slate-100 dark:border-slate-700 mt-1"
                  >
                    <LogOut className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                    <span>خروج امن از سیستم</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

