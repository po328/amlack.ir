import React from 'react';
import {
  LayoutDashboard,
  Building2,
  Users,
  ArrowLeftRight,
  Calculator,
  CalendarCheck,
  Star,
  Settings,
  ShieldAlert,
  PhoneCall,
  FileCheck2,
  Sparkles,
  LogOut
} from 'lucide-react';
import { User } from '../../types';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  propertiesCount: number;
  customersCount: number;
  todayTasksCount: number;
  favoritesCount: number;
  contractsCount?: number;
  currentUser: User;
  agencyName: string;
  agencyPhone: string;
  onLogout?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  propertiesCount,
  customersCount,
  todayTasksCount,
  favoritesCount,
  contractsCount = 0,
  currentUser,
  agencyName,
  agencyPhone,
  onLogout
}) => {
  const isSuperAdmin = currentUser.role === 'super_admin';
  const isOwner = currentUser.role === 'owner';
  const perms = (currentUser.permissions || []).map(p => p.replace(':', '.'));

  const hasPerm = (pPattern: string) => {
    if (isSuperAdmin || isOwner || perms.includes('*')) return true;
    return perms.some(p => p.startsWith(pPattern));
  };

  const rawMenuItems = [
    {
      id: 'dashboard',
      label: 'داشبورد مدیریت',
      icon: LayoutDashboard,
      badge: null,
      visible: true
    },
    {
      id: 'properties',
      label: 'فایل‌های املاک',
      icon: Building2,
      badge: propertiesCount,
      visible: hasPerm('properties')
    },
    {
      id: 'customers',
      label: 'مشتریان و CRM',
      icon: Users,
      badge: customersCount,
      visible: hasPerm('customers')
    },
    {
      id: 'contracts',
      label: 'قراردادها و مالی',
      icon: FileCheck2,
      badge: contractsCount > 0 ? contractsCount : null,
      badgeColor: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300',
      visible: isSuperAdmin || isOwner || hasPerm('finances') || hasPerm('contracts')
    },
    {
      id: 'followups',
      label: 'پیگیری و وظایف',
      icon: CalendarCheck,
      badge: todayTasksCount > 0 ? `${todayTasksCount} امروز` : null,
      badgeColor: 'bg-amber-500 text-white',
      visible: true
    },
    {
      id: 'converter',
      label: 'تبدیل رهن و اجاره',
      icon: ArrowLeftRight,
      badge: null,
      visible: true
    },
    {
      id: 'commission',
      label: 'محاسبه کمیسیون',
      icon: Calculator,
      badge: null,
      visible: true
    },
    {
      id: 'favorites',
      label: 'فایل‌های نشان‌شده',
      icon: Star,
      badge: favoritesCount > 0 ? favoritesCount : null,
      visible: true
    },
    {
      id: 'admin',
      label: 'تنظیمات و پشتیبان',
      icon: Settings,
      badge: isOwner ? 'مدیر' : null,
      badgeColor: 'bg-emerald-600/20 text-emerald-700 dark:text-emerald-400',
      visible: isSuperAdmin || isOwner || hasPerm('settings')
    },
    ...(isSuperAdmin ? [{
      id: 'superadmin',
      label: 'مرکز کنترل کل شعب (SaaS)',
      icon: Sparkles,
      badge: 'SuperAdmin',
      badgeColor: 'bg-purple-600 text-white',
      visible: true
    }] : [])
  ];

  const menuItems = rawMenuItems.filter(item => item.visible);

  return (
    <aside className="hidden lg:flex flex-col w-64 h-screen sticky top-0 bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 select-none z-40 transition-colors">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
        <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-bold text-lg shadow-md shadow-emerald-500/20">
          <Building2 className="w-6 h-6" />
        </div>
        <div>
          <div className="font-extrabold text-sm text-slate-900 dark:text-white tracking-tight">
            {agencyName}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
            سامانه جامع مدیریت و CRM
          </div>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs lg:text-sm font-medium transition-all ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/30'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>

              {item.badge !== null && (
                <span
                  className={`text-[11px] px-2 py-0.5 rounded-full font-bold ${
                    item.badgeColor || (isActive ? 'bg-white/20 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300')
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Info Box */}
      <div className="p-4 border-t border-slate-100 dark:border-slate-800">
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700/60 text-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-[11px]">پشتیبانی آژانس:</span>
            <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-bold" dir="ltr">
              <PhoneCall className="w-3 h-3" />
              {agencyPhone}
            </span>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
            <span>نسخه وب‌پایه (PWA)</span>
            <span className="text-emerald-600 font-semibold">v2.4</span>
          </div>

          {onLogout && (
            <button
              onClick={onLogout}
              className="mt-2.5 w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>خروج از حساب کاربری</span>
            </button>
          )}
        </div>
      </div>
    </aside>
  );
};
