import React, { useState } from 'react';
import {
  LayoutDashboard,
  Building2,
  Users,
  CalendarCheck,
  MoreHorizontal,
  ArrowLeftRight,
  Calculator,
  Star,
  Settings,
  X
} from 'lucide-react';

interface BottomNavProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  todayTasksCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  todayTasksCount
}) => {
  const [showMoreModal, setShowMoreModal] = useState(false);

  const mainNavItems = [
    { id: 'dashboard', label: 'داشبورد', icon: LayoutDashboard },
    { id: 'properties', label: 'املاک', icon: Building2 },
    { id: 'customers', label: 'مشتریان', icon: Users },
    { id: 'followups', label: 'پیگیری', icon: CalendarCheck, badge: todayTasksCount > 0 ? todayTasksCount : null },
  ];

  const handleSelectMore = (tab: string) => {
    onSelectTab(tab);
    setShowMoreModal(false);
  };

  return (
    <>
      {/* More Bottom Sheet on Mobile */}
      {showMoreModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end lg:hidden animate-in fade-in">
          <div 
            className="bg-white dark:bg-slate-900 rounded-t-3xl p-5 border-t border-slate-200 dark:border-slate-800 shadow-2xl animate-in slide-in-from-bottom-5 duration-200"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <span className="font-bold text-sm text-slate-800 dark:text-slate-100">سایر ابزارها و بخش‌ها</span>
              <button 
                onClick={() => setShowMoreModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-4">
              <button
                onClick={() => handleSelectMore('contracts')}
                className={`flex items-center gap-3 p-3.5 rounded-2xl border text-xs font-semibold transition-all ${
                  currentTab === 'contracts'
                    ? 'bg-emerald-50 border-emerald-300 dark:bg-emerald-950/40 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                    : 'bg-slate-50 dark:bg-slate-800/80 border-slate-100 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                }`}
              >
                <div className="p-2 rounded-xl bg-indigo-600/10 text-indigo-600 dark:text-indigo-400">
                  <Calculator className="w-4 h-4" />
                </div>
                <span>قراردادها و مالی</span>
              </button>

              <button
                onClick={() => handleSelectMore('converter')}
                className={`flex items-center gap-3 p-3.5 rounded-2xl border text-xs font-semibold transition-all ${
                  currentTab === 'converter'
                    ? 'bg-emerald-50 border-emerald-300 dark:bg-emerald-950/40 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                    : 'bg-slate-50 dark:bg-slate-800/80 border-slate-100 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                }`}
              >
                <div className="p-2 rounded-xl bg-emerald-600/10 text-emerald-600 dark:text-emerald-400">
                  <ArrowLeftRight className="w-4 h-4" />
                </div>
                <span>تبدیل رهن و اجاره</span>
              </button>

              <button
                onClick={() => handleSelectMore('commission')}
                className={`flex items-center gap-3 p-3.5 rounded-2xl border text-xs font-semibold transition-all ${
                  currentTab === 'commission'
                    ? 'bg-emerald-50 border-emerald-300 dark:bg-emerald-950/40 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                    : 'bg-slate-50 dark:bg-slate-800/80 border-slate-100 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                }`}
              >
                <div className="p-2 rounded-xl bg-blue-600/10 text-blue-600 dark:text-blue-400">
                  <Calculator className="w-4 h-4" />
                </div>
                <span>محاسبه کمیسیون</span>
              </button>

              <button
                onClick={() => handleSelectMore('favorites')}
                className={`flex items-center gap-3 p-3.5 rounded-2xl border text-xs font-semibold transition-all ${
                  currentTab === 'favorites'
                    ? 'bg-emerald-50 border-emerald-300 dark:bg-emerald-950/40 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                    : 'bg-slate-50 dark:bg-slate-800/80 border-slate-100 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                }`}
              >
                <div className="p-2 rounded-xl bg-amber-600/10 text-amber-600 dark:text-amber-400">
                  <Star className="w-4 h-4" />
                </div>
                <span>فایل‌های نشان‌شده</span>
              </button>

              <button
                onClick={() => handleSelectMore('admin')}
                className={`flex items-center gap-3 p-3.5 rounded-2xl border text-xs font-semibold transition-all ${
                  currentTab === 'admin'
                    ? 'bg-emerald-50 border-emerald-300 dark:bg-emerald-950/40 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                    : 'bg-slate-50 dark:bg-slate-800/80 border-slate-100 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                }`}
              >
                <div className="p-2 rounded-xl bg-purple-600/10 text-purple-600 dark:text-purple-400">
                  <Settings className="w-4 h-4" />
                </div>
                <span>تنظیمات و مدیریت</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Persistent Bottom Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 py-1.5 px-3 select-none transition-colors">
        <div className="flex items-center justify-around">
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all ${
                  isActive
                    ? 'text-emerald-600 dark:text-emerald-400 font-bold'
                    : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                <div className="relative">
                  <Icon className="w-5 h-5" />
                  {item.badge && (
                    <span className="absolute -top-1 -right-2 min-w-4 h-4 px-1 rounded-full bg-amber-500 text-white text-[9px] flex items-center justify-center font-bold">
                      {item.badge}
                    </span>
                  )}
                </div>
                <span className="text-[10px] mt-1">{item.label}</span>
              </button>
            );
          })}

          {/* More Toggle */}
          <button
            onClick={() => setShowMoreModal(true)}
            className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all ${
              ['converter', 'commission', 'favorites', 'admin'].includes(currentTab)
                ? 'text-emerald-600 dark:text-emerald-400 font-bold'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            <MoreHorizontal className="w-5 h-5" />
            <span className="text-[10px] mt-1">بیشتر</span>
          </button>
        </div>
      </nav>
    </>
  );
};
