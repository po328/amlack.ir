import React, { useState, useRef } from 'react';
import { UploadCloud, X, Plus, Image as ImageIcon, Star, AlertCircle, Loader2, Link as LinkIcon } from 'lucide-react';
import { compressAndResizeImage, isValidImageFile, isValidImageUrl } from '../../utils/imageUtils';
import { useToast } from '../../context/ToastContext';

interface ImageUploaderProps {
  images: string[];
  onChange: (images: string[]) => void;
  maxImages?: number;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({
  images,
  onChange,
  maxImages = 8
}) => {
  const { showToast } = useToast();
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [urlInputValue, setUrlInputValue] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;

    if (images.length + files.length > maxImages) {
      showToast(`حداکثر ${maxImages} تصویر برای هر فایل ملکی مجاز است.`, 'warning');
      return;
    }

    setIsProcessing(true);
    const newImages: string[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!isValidImageFile(file)) {
        showToast(`فایل ${file.name} فرمت معتبر تصویری (JPG, PNG, WebP) نیست.`, 'error');
        continue;
      }

      // Max raw file size: 10MB
      if (file.size > 10 * 1024 * 1024) {
        showToast(`حجم تصویر ${file.name} بیشتر از ۱۰ مگابایت است.`, 'warning');
        continue;
      }

      try {
        const compressedDataUrl = await compressAndResizeImage(file, 1200, 900, 0.82);
        newImages.push(compressedDataUrl);
      } catch (err: any) {
        showToast(err?.message || 'خطا در فشرده‌سازی تصویر', 'error');
      }
    }

    if (newImages.length > 0) {
      onChange([...images, ...newImages]);
      showToast(`${newImages.length} تصویر با موفقیت بهینه و بارگذاری شد.`, 'success');
    }

    setIsProcessing(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleRemoveImage = (index: number) => {
    const updated = images.filter((_, i) => i !== index);
    onChange(updated);
  };

  const handleSetPrimary = (index: number) => {
    if (index === 0) return;
    const selected = images[index];
    const rest = images.filter((_, i) => i !== index);
    onChange([selected, ...rest]);
    showToast('تصویر به عنوان عکس اصلی تنظیم شد.', 'info');
  };

  const handleAddUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInputValue.trim()) return;

    if (!isValidImageUrl(urlInputValue)) {
      showToast('آدرس اینترنتی تصویر نامعتبر است.', 'error');
      return;
    }

    if (images.length >= maxImages) {
      showToast(`حداکثر ${maxImages} تصویر مجاز است.`, 'warning');
      return;
    }

    onChange([...images, urlInputValue.trim()]);
    setUrlInputValue('');
    setShowUrlInput(false);
    showToast('لینک تصویر اضافه شد.', 'success');
  };

  return (
    <div className="space-y-3" dir="rtl">
      <div className="flex items-center justify-between">
        <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
          تصاویر و آلبوم ملک ({images.length} از {maxImages})
        </label>
        <button
          type="button"
          onClick={() => setShowUrlInput(!showUrlInput)}
          className="text-[11px] text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
        >
          <LinkIcon className="w-3 h-3" />
          <span>{showUrlInput ? 'بستن ورودی لینک' : 'افزودن با لینک مستقیم'}</span>
        </button>
      </div>

      {/* Direct URL input if toggled */}
      {showUrlInput && (
        <form onSubmit={handleAddUrl} className="flex gap-2 p-2 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
          <input
            type="url"
            value={urlInputValue}
            onChange={(e) => setUrlInputValue(e.target.value)}
            placeholder="https://example.com/property.jpg"
            className="flex-1 px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none font-mono"
          />
          <button
            type="submit"
            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors"
          >
            ثبت لینک
          </button>
        </form>
      )}

      {/* Drag and Drop Zone */}
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-2xl p-4 text-center cursor-pointer transition-all duration-200 ${
          isDragging
            ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20 scale-[1.01]'
            : 'border-slate-300 dark:border-slate-700 hover:border-emerald-500/70 bg-slate-50/70 dark:bg-slate-900/40 hover:bg-slate-50 dark:hover:bg-slate-900/70'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/jpeg,image/png,image/webp,image/gif,image/avif"
          onChange={(e) => handleFiles(e.target.files)}
          className="hidden"
        />

        <div className="flex flex-col items-center justify-center gap-2 py-2">
          {isProcessing ? (
            <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs">
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>در حال بهینه‌سازی و فشرده‌سازی خودکار تصاویر...</span>
            </div>
          ) : (
            <>
              <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <UploadCloud className="w-5 h-5" />
              </div>
              <div className="text-xs text-slate-700 dark:text-slate-300 font-bold">
                تصاویر را به اینجا بکشید یا برای انتخاب فایل کلیک کنید
              </div>
              <p className="text-[10px] text-slate-400">
                پشتیبانی از فرمت‌های JPG، PNG و WebP • فشرده‌سازی خودکار بدون افت کیفیت
              </p>
            </>
          )}
        </div>
      </div>

      {/* Thumbnails list */}
      {images.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
          {images.map((imgUrl, index) => (
            <div
              key={index}
              className="group relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 aspect-4/3 bg-slate-100 dark:bg-slate-800 shadow-xs"
            >
              <img
                src={imgUrl}
                alt={`تصویر شماره ${index + 1}`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />

              {/* Primary badge */}
              {index === 0 && (
                <div className="absolute top-1.5 right-1.5 px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-black shadow-xs flex items-center gap-1">
                  <Star className="w-2.5 h-2.5 fill-current" />
                  <span>عکس اصلی</span>
                </div>
              )}

              {/* Action overlay */}
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                {index !== 0 && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSetPrimary(index);
                    }}
                    className="p-1.5 rounded-lg bg-white/20 hover:bg-white text-white hover:text-emerald-800 text-[10px] transition-colors"
                    title="تنظیم به عنوان عکس اصلی"
                  >
                    <Star className="w-3.5 h-3.5" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRemoveImage(index);
                  }}
                  className="p-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-[10px] transition-colors"
                  title="حذف تصویر"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
