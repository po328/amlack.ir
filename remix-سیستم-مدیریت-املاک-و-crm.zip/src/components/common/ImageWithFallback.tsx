import React, { useState } from 'react';
import { getPropertyFallbackImage } from '../../utils/imageUtils';

interface ImageWithFallbackProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallbackSrc?: string;
  containerClassName?: string;
  showSkeleton?: boolean;
  propertyType?: string;
}

export const ImageWithFallback: React.FC<ImageWithFallbackProps> = ({
  src,
  alt = 'تصویر ملک',
  className = '',
  containerClassName = '',
  fallbackSrc,
  showSkeleton = true,
  propertyType,
  ...props
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  const defaultFallback = getPropertyFallbackImage(propertyType);
  const finalFallback = fallbackSrc || defaultFallback;
  const finalSrc = hasError || !src ? finalFallback : src;

  return (
    <div className={`relative overflow-hidden ${containerClassName}`}>
      {/* Skeleton loader with shimmer */}
      {showSkeleton && isLoading && (
        <div 
          className="absolute inset-0 bg-slate-200 dark:bg-slate-800 animate-pulse z-10 flex items-center justify-center"
          aria-hidden="true"
        >
          <div className="w-8 h-8 rounded-full border-2 border-emerald-500/20 border-t-emerald-500 animate-spin" />
        </div>
      )}

      <img
        src={finalSrc}
        alt={alt}
        referrerPolicy="no-referrer"
        loading="lazy"
        onLoad={() => setIsLoading(false)}
        onError={() => {
          setIsLoading(false);
          setHasError(true);
        }}
        className={`transition-opacity duration-300 ${
          isLoading ? 'opacity-0' : 'opacity-100'
        } ${className}`}
        {...props}
      />
    </div>
  );
};
