import React, { useState, useEffect } from 'react';
import { 
  Database, 
  ShieldCheck, 
  Download, 
  Upload, 
  RotateCcw, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  FileCheck,
  RefreshCw,
  HardDrive
} from 'lucide-react';
import { apiService } from '../../services/apiService';
import { toPersianDigits } from '../../utils/formatters';

interface BackupManagerProps {
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  onDataReset?: () => void;
}

export const BackupManager: React.FC<BackupManagerProps> = ({ showToast, onDataReset }) => {
  const [backups, setBackups] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  const fetchBackups = async () => {
    try {
      setIsLoading(true);
      const data = await apiService.getBackups();
      setBackups(data);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBackups();
  }, []);

  const handleCreateBackup = async () => {
    try {
      setIsLoading(true);
      const result = await apiService.createBackup();
      showToast('نسخه پشتیبان پایگاه داده با موفقیت در فضای ذخیره‌سازی ایزوله ایجاد شد.', 'success');
      await fetchBackups();
    } catch (err: any) {
      showToast(err.message || 'خطا در ایجاد پشتیبان', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetData = async () => {
    try {
      setIsLoading(true);
      await apiService.resetTenantData();
      setIsResetConfirmOpen(false);
      showToast('اطلاعات پیش‌فرض دمو برای این آژانس بازیابی شد.', 'info');
      if (onDataReset) onDataReset();
      await fetchBackups();
    } catch (err: any) {
      showToast(err.message || 'خطا در بازنشانی اطلاعات', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Overview Banner */}
      <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 p-4 rounded-2xl flex items-start gap-3">
        <ShieldCheck className="w-6 h-6 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
        <div>
          <h4 className="text-sm font-black text-emerald-900 dark:text-emerald-200">
            سیستم پایداری داده‌ها و نسخه‌های پشتیبان (ACID SQLite WAL)
          </h4>
          <p className="text-xs text-emerald-800 dark:text-emerald-400 mt-1 leading-relaxed">
            تمامی عملیات در سطح تراکنش‌های اتمیک SQLite و مکانیزم Write-Ahead Logging (WAL) ذخیره شده و قبل از هر ارتقای نسخه، یک اسنپ‌شات خودکار تهیه می‌شود. داده‌های آژانس شما هرگز مفقود نخواهند شد.
          </p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <HardDrive className="w-5 h-5 text-slate-500" />
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
            عملیات پشتیبان‌گیری و ایمنی
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCreateBackup}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-all disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            تهیه پشتیبان دستی جدید
          </button>

          <button
            onClick={() => setIsResetConfirmOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            بازیابی داده‌های پیش‌فرض دمو
          </button>
        </div>
      </div>

      {/* Backups List */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-slate-400" />
            تاریخچه اسنپ‌شات‌های پشتیبان سیستم
          </span>
          <button
            onClick={fetchBackups}
            className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            بروزرسانی لیست
          </button>
        </div>

        {backups.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs">
            پشتیبان اختصاصی ثبت نشده است. روی «تهیه پشتیبان دستی جدید» کلیک کنید.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {backups.map((b) => (
              <div key={b.id} className="p-3.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center">
                    <FileCheck className="w-4 h-4 text-emerald-500" />
                  </div>
                  <div>
                    <div className="font-mono font-bold text-slate-800 dark:text-slate-200">{b.filename}</div>
                    <div className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                      <span>نوع: {b.backup_type === 'pre_migration' ? 'قبل از ارتقاء مایگریشن' : 'دستی'}</span>
                      <span>•</span>
                      <span>حجم: {Math.round((b.filesize || 0) / 1024)} کیلوبایت</span>
                    </div>
                  </div>
                </div>

                <div className="text-left font-mono text-[11px] text-slate-400">
                  {toPersianDigits(new Date(b.created_at).toLocaleString('fa-IR'))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Confirmation Modal: Reset Data */}
      {isResetConfirmOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-md p-6 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <div className="flex items-center gap-3 text-amber-500 mb-3">
              <AlertTriangle className="w-6 h-6" />
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                تأیید بازیابی اطلاعات دمو
              </h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
              با این اقدام، اطلاعات نمونه استاندارد شامل ۷ ملک شاخص، ۵ مشتری متقاضی و وظایف این آژانس بازنشانی می‌شوند. قبل از این اقدام یک فایل اسنپ‌شات خودکار ذخیره می‌شود. آیا ادامه می‌دهید؟
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setIsResetConfirmOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold"
              >
                انصراف
              </button>
              <button
                onClick={handleResetData}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-xs"
              >
                تأیید و بازنشانی
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
