import React, { useState } from 'react';
import {
  Settings,
  Building,
  Users,
  Percent,
  Download,
  RotateCcw,
  Save,
  Check,
  Database
} from 'lucide-react';
import { User, AppSettings } from '../../types';
import { useToast } from '../../context/ToastContext';
import { ConfirmModal } from '../common/ConfirmModal';
import { BackupManager } from './BackupManager';

interface SettingsViewProps {
  settings: AppSettings;
  users: User[];
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onAddUser: (user: Omit<User, 'id'>) => void;
  onResetData: () => void;
  onExportData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  users,
  onUpdateSettings,
  onAddUser,
  onResetData,
  onExportData
}) => {
  const [activeTab, setActiveTab] = useState<'agency' | 'rates' | 'users' | 'backup'>('agency');

  // Agency info state
  const [agencyName, setAgencyName] = useState(settings.agencyName || 'املاک نگین پایتخت');
  const [phone, setPhone] = useState(settings.phone || '02122003344');
  const [managerName, setManagerName] = useState(settings.managerName || 'حاج محمود کبیری');
  const [licenseNumber, setLicenseNumber] = useState('۱۴۰۳/۹۸۷۲');
  const [address, setAddress] = useState(settings.address || 'تهران، سعادت‌آباد، میدان کاج');
  const [city, setCity] = useState(settings.city || 'تهران');

  // Rates
  const [defaultRate, setDefaultRate] = useState(settings.defaultConversionRate || 3.0);
  const [vatPercent, setVatPercent] = useState(settings.vatPercent || 10);
  const [agentShare, setAgentShare] = useState(settings.agentCommissionSharePercent || 50);

  // New user state
  const [newFullName, setNewFullName] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newUserRole, setNewUserRole] = useState<'admin' | 'agent' | 'manager'>('agent');
  const [newUserPhone, setNewUserPhone] = useState('');
  const { showToast } = useToast();
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveAgency = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({
      agencyName,
      phone,
      managerName,
      address,
      city,
      defaultConversionRate: Number(defaultRate),
      vatPercent: Number(vatPercent),
      agentCommissionSharePercent: Number(agentShare)
    });
    setSavedSuccess(true);
    showToast('تنظیمات آژانس با موفقیت ذخیره شد.', 'success');
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFullName.trim()) return;

    onAddUser({
      fullName: newFullName,
      username: newUsername || `agent_${Date.now().toString().slice(-4)}`,
      role: newUserRole,
      phone: newUserPhone,
      isActive: true
    });

    setNewFullName('');
    setNewUsername('');
    setNewUserPhone('');
    showToast('مشاور جدید با موفقیت به سیستم اضافه شد.', 'success');
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-200 text-right">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 lg:p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg lg:text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-slate-700 dark:text-slate-300" />
            <span>تنظیمات نرم‌افزار و مدیریت مشاورین</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            پیکربندی هویت آژانس، نرخ‌های پیش‌فرض محاسبات مالی، پرسنل و پشتیبان‌گیری
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 text-xs font-bold animate-in fade-in">
            <Check className="w-4 h-4" />
            <span>تنظیمات ذخیره شد</span>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700 max-w-xl">
        {[
          { id: 'agency', label: 'مشخصات آژانس', icon: Building },
          { id: 'rates', label: 'تنظیمات نرخ و مالیات', icon: Percent },
          { id: 'users', label: 'مشاورین و دسترسی‌ها', icon: Users },
          { id: 'backup', label: 'پشتیبان‌گیری داده‌ها', icon: Download },
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                activeTab === tab.id
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: Agency Info */}
      {activeTab === 'agency' && (
        <form onSubmit={handleSaveAgency} className="bg-white dark:bg-slate-900 rounded-3xl p-5 lg:p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <div className="font-bold text-sm text-slate-800 dark:text-slate-200 pb-2 border-b border-slate-100 dark:border-slate-800">
            اطلاعات رسمی دفتر املاک
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                نام آژانس املاک
              </label>
              <input
                type="text"
                value={agencyName}
                onChange={(e) => setAgencyName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                شماره پروانه کسب اتحادیه
              </label>
              <input
                type="text"
                value={licenseNumber}
                onChange={(e) => setLicenseNumber(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                نام مدیر مسئول
              </label>
              <input
                type="text"
                value={managerName}
                onChange={(e) => setManagerName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                تلفن ثابت دفتر
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-mono"
                dir="ltr"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                نشانی دفتر املاک
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20"
            >
              <Save className="w-4 h-4" />
              <span>ذخیره تغییرات آژانس</span>
            </button>
          </div>
        </form>
      )}

      {/* TAB 2: Rates & Tax */}
      {activeTab === 'rates' && (
        <form onSubmit={handleSaveAgency} className="bg-white dark:bg-slate-900 rounded-3xl p-5 lg:p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <div className="font-bold text-sm text-slate-800 dark:text-slate-200 pb-2 border-b border-slate-100 dark:border-slate-800">
            تنظیمات پیش‌فرض محاسبات مالی و تعرفه‌ها
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                درصد پیش‌فرض تبدیل رهن به اجاره (ماهانه)
              </label>
              <input
                type="number"
                step="0.1"
                value={defaultRate}
                onChange={(e) => setDefaultRate(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-mono"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                عرف بازار: ۳.۰ درصد (معادل ۳۰ هزار تومان به ازای هر ۱ میلیون تومان ودیعه)
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                درصد مالیات بر ارزش افزوده (VAT)
              </label>
              <input
                type="number"
                step="1"
                value={vatPercent}
                onChange={(e) => setVatPercent(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-mono"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                قانون بودجه جاری: ۱۰ درصد
              </span>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20"
            >
              <Save className="w-4 h-4" />
              <span>ذخیره نرخ‌ها</span>
            </button>
          </div>
        </form>
      )}

      {/* TAB 3: Staff & Users */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          {/* Add User Form */}
          <form onSubmit={handleCreateUser} className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
            <div className="font-bold text-xs text-slate-800 dark:text-slate-200">
              + تعریف مشاور ملکی جدید
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <input
                type="text"
                placeholder="نام و نام خانوادگی مشاور"
                value={newFullName}
                onChange={(e) => setNewFullName(e.target.value)}
                className="px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                required
              />
              <input
                type="text"
                placeholder="شماره موبایل"
                value={newUserPhone}
                onChange={(e) => setNewUserPhone(e.target.value)}
                className="px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-mono"
                dir="ltr"
              />
              <select
                value={newUserRole}
                onChange={(e) => setNewUserRole(e.target.value as any)}
                className="px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
              >
                <option value="agent">مشاور ملکی (Agent)</option>
                <option value="admin">مدیر سیستم (Admin)</option>
                <option value="manager">مدیر دفتر (Manager)</option>
              </select>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 shadow-xs"
              >
                ثبت مشاور
              </button>
            </div>
          </form>

          {/* User List */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
            <div className="font-bold text-xs text-slate-800 dark:text-slate-200 pb-2 border-b border-slate-100 dark:border-slate-800">
              لیست پرسنل و مشاورین فعال ({users.length})
            </div>

            <div className="space-y-2">
              {users.map((u) => (
                <div
                  key={u.id}
                  className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/70 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold flex items-center justify-center">
                      {(u.fullName || 'م').slice(0, 1)}
                    </div>
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white">{u.fullName}</span>
                      <span className="text-slate-400 mr-2 font-mono">({u.phone || u.username})</span>
                    </div>
                  </div>

                  <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                    u.role === 'admin'
                      ? 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300'
                      : 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300'
                  }`}>
                    {u.role === 'admin' ? 'مدیر ارشد' : 'مشاور قرارداد'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Backup & Reset */}
      {activeTab === 'backup' && (
        <div className="space-y-6">
          <BackupManager showToast={showToast} onDataReset={onResetData} />

          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div className="font-bold text-xs text-slate-800 dark:text-slate-200 pb-2 border-b border-slate-100 dark:border-slate-800 mb-3">
              خروجی مستقل داده‌ها (JSON Export)
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              جهت انتقال اطلاعات به سایر سامانه‌ها یا بایگانی آفلاین، می‌توانید تمامی فایل‌های ملکی و اطلاعات متقاضیان را در قالب فایل JSON دانلود کنید.
            </p>
            <button
              onClick={onExportData}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold shadow-xs transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>دریافت خروجی JSON</span>
            </button>
          </div>
        </div>
      )}

      {/* Reset Confirmation Modal */}
      <ConfirmModal
        isOpen={showResetConfirm}
        title="بازنشانی پایگاه داده"
        description="آیا از بازنشانی داده‌های نرم‌افزار به حالت اولیه اطمینان دارید؟ تمام تغییرات ثبت شده پاکسازی خواهند شد."
        confirmLabel="بله، بازنشانی شود"
        cancelLabel="انصراف"
        isDanger={true}
        onConfirm={() => {
          onResetData();
          setShowResetConfirm(false);
          showToast('اطلاعات با موفقیت بازنشانی شد.', 'info');
        }}
        onCancel={() => setShowResetConfirm(false)}
      />
    </div>
  );
};
