import React, { useState } from 'react';
import {
  X,
  Star,
  Edit,
  Trash2,
  Copy,
  Phone,
  ArrowLeftRight,
  Calculator,
  Building,
  Calendar,
  Maximize2,
  Layers,
  MapPin,
  Check,
  Users,
  Printer,
  ChevronLeft,
  ChevronRight,
  Eye
} from 'lucide-react';
import { Property, Customer, AppSettings, User } from '../../types';
import { formatToman, numberToPersianWords, toPersianDigits, formatPersianDate } from '../../utils/formatters';
import { ImageWithFallback } from '../common/ImageWithFallback';
import { ConfirmModal } from '../common/ConfirmModal';
import { PropertyPrintModal } from './PropertyPrintModal';
import { useToast } from '../../context/ToastContext';

interface PropertyDetailModalProps {
  property: Property | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (property: Property) => void;
  onDelete: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onOpenConverterWithProperty?: (mortgage: number, rent: number) => void;
  onOpenCommissionWithProperty?: (dealType: 'sale' | 'rent', amount: number, mortgage?: number, rent?: number) => void;
  customers?: Customer[];
  onSelectCustomer?: (customer: Customer) => void;
  settings?: AppSettings;
  currentUser?: User | null;
}

export const PropertyDetailModal: React.FC<PropertyDetailModalProps> = ({
  property,
  isOpen,
  onClose,
  onEdit,
  onDelete,
  onToggleFavorite,
  onOpenConverterWithProperty,
  onOpenCommissionWithProperty,
  customers = [],
  onSelectCustomer,
  settings,
  currentUser
}) => {
  const { showToast } = useToast();
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [showMatchingCustomers, setShowMatchingCustomers] = useState(false);

  const isSuperAdmin = currentUser?.role === 'super_admin';
  const isOwner = currentUser?.role === 'owner';
  const perms = (currentUser?.permissions || []).map((p: string) => p.replace(':', '.'));
  const canEdit = isSuperAdmin || isOwner || perms.includes('*') || perms.some((p: string) => p.startsWith('properties.edit') || p.startsWith('properties'));
  const canDelete = isSuperAdmin || isOwner || perms.includes('*') || perms.some((p: string) => p.startsWith('properties.delete'));
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  if (!isOpen || !property) return null;

  const images = property.images && property.images.length > 0
    ? property.images
    : [];

  const handleCopyText = async () => {
    const text = `🏠 ${property.title}
کد فایل: ${property.code}
نوع معامله: ${property.dealType === 'sale' ? 'فروش' : property.dealType === 'rent' ? 'رهن و اجاره' : 'پیش‌فروش'}
متراژ: ${property.area} متر | ${property.rooms} خواب
محدوده: ${property.district}
${property.dealType === 'sale' ? `قیمت: ${formatToman(property.salePrice)}` : `رهن: ${formatToman(property.mortgagePrice, false)} - اجاره: ${formatToman(property.rentPrice)}`}
امکانات: ${property.features.join('، ')}
توضیحات: ${property.description || 'ندارد'}`;

    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      showToast('مشخصات فایل ملکی کپی شد.', 'success');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast('خطا در کپی کردن متن', 'error');
    }
  };

  const handleDeleteConfirmed = () => {
    onDelete(property.id);
    setShowDeleteConfirm(false);
    showToast('فایل ملکی با موفقیت حذف گردید.', 'info');
    onClose();
  };

  // Find matching customers from CRM
  const matchingCustomers = customers.filter(c => {
    if (property.dealType === 'sale') {
      if (c.dealType !== 'buy') return false;
      if (property.salePrice && c.budgetMax && property.salePrice > c.budgetMax * 1.15) return false;
    } else {
      if (c.dealType !== 'rent') return false;
      if (property.mortgagePrice && c.mortgageMax && property.mortgagePrice > c.mortgageMax * 1.2) return false;
    }
    // District match
    if (c.preferredDistricts && c.preferredDistricts.length > 0) {
      const hasDistrictMatch = c.preferredDistricts.some(d => property.district.includes(d) || d.includes(property.district));
      if (!hasDistrictMatch && c.preferredDistricts.length > 2) return false;
    }
    return true;
  });

  return (
    <>
      <div 
        className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-2 lg:p-4 overflow-y-auto animate-in fade-in"
        dir="rtl"
        role="dialog"
        aria-modal="true"
      >
        <div 
          className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 animate-in zoom-in-95"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-lg font-mono text-xs font-black bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                {property.code}
              </span>
              <span className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                property.dealType === 'sale' 
                  ? 'bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300'
                  : 'bg-teal-100 text-teal-900 dark:bg-teal-950/60 dark:text-teal-300'
              }`}>
                {property.dealType === 'sale' ? 'فروش' : property.dealType === 'rent' ? 'رهن و اجاره' : 'پیش‌فروش'}
              </span>
              <span className="text-xs text-slate-400 hidden sm:inline mr-2">
                ثبت: {formatPersianDate(property.createdAt)}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => onToggleFavorite(property.id)}
                className={`p-2 rounded-xl border transition-colors ${
                  property.isFavorite
                    ? 'bg-amber-50 border-amber-300 text-amber-500 dark:bg-amber-950/40 dark:border-amber-700'
                    : 'border-slate-200 dark:border-slate-700 text-slate-400 hover:text-amber-500'
                }`}
                title="نشان کردن"
              >
                <Star className={`w-4 h-4 ${property.isFavorite ? 'fill-current' : ''}`} />
              </button>
              
              <button
                type="button"
                onClick={() => setShowPrintModal(true)}
                className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                title="چاپ شناسنامه و بروشور ملک"
              >
                <Printer className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={handleCopyText}
                className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                title="کپی مشخصات برای اشتراک‌گذاری"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              </button>

              {canEdit && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onEdit(property);
                  }}
                  className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                  title="ویرایش اطلاعات"
                >
                  <Edit className="w-4 h-4" />
                </button>
              )}

              {canDelete && (
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(true)}
                  className="p-2 rounded-xl border border-red-200 dark:border-red-900/50 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                  title="حذف فایل"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}

              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                aria-label="بستن"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Modal Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-5 text-right">
            {/* Gallery Section */}
            <div className="space-y-2">
              <div 
                className="w-full h-64 lg:h-80 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800 relative group cursor-pointer"
                onClick={() => setLightboxOpen(true)}
              >
                <ImageWithFallback
                  src={images[selectedImageIndex] || ''}
                  alt={property.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-102"
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="px-3.5 py-1.5 rounded-xl bg-black/60 text-white text-xs font-bold backdrop-blur-xs flex items-center gap-1.5">
                    <Eye className="w-4 h-4" />
                    مشاهده اندازه کامل
                  </span>
                </div>
                {images.length > 0 && (
                  <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur px-3 py-1 rounded-full text-white text-xs font-mono">
                    {toPersianDigits(selectedImageIndex + 1)} / {toPersianDigits(images.length)}
                  </div>
                )}
              </div>

              {images.length > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedImageIndex(idx)}
                      className={`w-16 h-16 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${
                        selectedImageIndex === idx
                          ? 'border-emerald-500 scale-95 shadow-md ring-2 ring-emerald-500/20'
                          : 'border-transparent opacity-70 hover:opacity-100'
                      }`}
                    >
                      <ImageWithFallback src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Title & Price Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700/60">
              <div>
                <h2 className="text-lg lg:text-xl font-extrabold text-slate-900 dark:text-white">
                  {property.title}
                </h2>
                <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mt-1">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>{property.city}، {property.district}</span>
                </div>
              </div>

              <div className="text-left">
                {property.dealType === 'sale' || property.dealType === 'presale' ? (
                  <div>
                    <div className="text-xl lg:text-2xl font-black text-emerald-600 dark:text-emerald-400">
                      {formatToman(property.salePrice)}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {numberToPersianWords(property.salePrice || 0)}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-1">
                    <div className="text-base lg:text-lg font-black text-teal-600 dark:text-teal-400">
                      رهن: {formatToman(property.mortgagePrice, false)}
                    </div>
                    <div className="text-base lg:text-lg font-black text-teal-600 dark:text-teal-400">
                      اجاره: {formatToman(property.rentPrice)}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Specs Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center">
                  <Maximize2 className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">متراژ</div>
                  <div className="font-extrabold text-sm text-slate-800 dark:text-slate-100 font-mono">
                    {toPersianDigits(property.area)} متر
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 flex items-center justify-center">
                  <Building className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">تعداد اتاق</div>
                  <div className="font-extrabold text-sm text-slate-800 dark:text-slate-100">
                    {property.rooms > 0 ? `${toPersianDigits(property.rooms)} خواب` : 'بدون خواب'}
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-600 flex items-center justify-center">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">طبقه</div>
                  <div className="font-extrabold text-sm text-slate-800 dark:text-slate-100 font-mono">
                    {property.floor ? `طبقه ${toPersianDigits(property.floor)}` : '-'}
                    {property.totalFloors ? ` از ${toPersianDigits(property.totalFloors)}` : ''}
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 flex items-center justify-center">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">سال ساخت</div>
                  <div className="font-extrabold text-sm text-slate-800 dark:text-slate-100 font-mono">
                    {property.yearBuilt ? toPersianDigits(property.yearBuilt) : 'نوساز'}
                  </div>
                </div>
              </div>
            </div>

            {/* Features */}
            <div className="space-y-2">
              <h4 className="font-bold text-xs text-slate-900 dark:text-white">امکانات و تجهیزات ملک</h4>
              <div className="flex flex-wrap gap-2">
                {property.features && property.features.length > 0 ? (
                  property.features.map((feat, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs border border-slate-200/60 dark:border-slate-700/60"
                    >
                      {feat}
                    </span>
                  ))
                ) : (
                  <span className="text-xs text-slate-400">امکاناتی ثبت نشده است</span>
                )}
              </div>
            </div>

            {/* Description */}
            {property.description && (
              <div className="space-y-1.5">
                <h4 className="font-bold text-xs text-slate-900 dark:text-white">توضیحات و مشخصات تکمیلی</h4>
                <p className="text-xs lg:text-sm text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/40 p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
                  {property.description}
                </p>
              </div>
            )}

            {/* Owner & Confidential Address */}
            <div className="p-4 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-amber-900 dark:text-amber-300">اطلاعات مالک و آدرس دقیق (محرمانه)</div>
                <div className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                  مالک: {property.ownerName || 'ثبت نشده'} • مشاور مسئول: {property.assignedAgentName || 'دفتر املاک'}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {property.address || 'آدرس ثبت نشده است'}
                </div>
              </div>

              {property.ownerPhone && (
                <a
                  href={`tel:${property.ownerPhone}`}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-amber-600 text-white text-xs font-bold shadow-xs hover:bg-amber-700 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span dir="ltr">{property.ownerPhone}</span>
                </a>
              )}
            </div>

            {/* Tool Shortcuts & CRM Matching */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                {property.dealType === 'rent' && onOpenConverterWithProperty && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenConverterWithProperty(property.mortgagePrice || 0, property.rentPrice || 0);
                    }}
                    className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-300 text-xs font-bold border border-teal-200 dark:border-teal-800 hover:bg-teal-100 transition-colors"
                  >
                    <ArrowLeftRight className="w-4 h-4" />
                    <span>تبدیل مستقیم رهن و اجاره</span>
                  </button>
                )}

                {onOpenCommissionWithProperty && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenCommissionWithProperty(
                        property.dealType === 'rent' ? 'rent' : 'sale',
                        property.salePrice || 0,
                        property.mortgagePrice || 0,
                        property.rentPrice || 0
                      );
                    }}
                    className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-800 dark:text-purple-300 text-xs font-bold border border-purple-200 dark:border-purple-800 hover:bg-purple-100 transition-colors"
                  >
                    <Calculator className="w-4 h-4" />
                    <span>محاسبه حق‌الزحمه کمیسیون</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setShowMatchingCustomers(!showMatchingCustomers)}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 text-xs font-bold border border-blue-200 dark:border-blue-800 hover:bg-blue-100 transition-colors"
                >
                  <Users className="w-4 h-4" />
                  <span>مشتریان منطبق در سامانه ({toPersianDigits(matchingCustomers.length)})</span>
                </button>
              </div>

              {/* Matching Customers */}
              {showMatchingCustomers && (
                <div className="p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/50 space-y-2.5 animate-in fade-in">
                  <div className="font-bold text-xs text-blue-900 dark:text-blue-300">
                    خریداران و مستاجران منطبق با مشخصات این فایل:
                  </div>
                  {matchingCustomers.length === 0 ? (
                    <p className="text-xs text-slate-400">در حال حاضر مشتری فعالی منطبق با این مشخصات ثبت نشده است.</p>
                  ) : (
                    matchingCustomers.map(cust => (
                      <div
                        key={cust.id}
                        className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700/70 flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-800 dark:text-slate-100">{cust.fullName}</span>
                          <span className="text-slate-400 mr-2" dir="ltr">({cust.phone})</span>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                            مناطق درخواستی: {cust.preferredDistricts.join('، ')}
                          </div>
                        </div>
                        {onSelectCustomer && (
                          <button
                            type="button"
                            onClick={() => {
                              onClose();
                              onSelectCustomer(cust);
                            }}
                            className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors"
                          >
                            مشاهده پرونده مشتری
                          </button>
                        )}
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox / Fullscreen Image Viewer */}
      {lightboxOpen && images.length > 0 && (
        <div 
          className="fixed inset-0 z-60 bg-black/90 flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => setLightboxOpen(false)}
        >
          <button
            type="button"
            onClick={() => setLightboxOpen(false)}
            className="absolute top-4 left-4 p-2 text-white/80 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          {images.length > 1 && (
            <>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedImageIndex((prev) => (prev > 0 ? prev - 1 : images.length - 1));
                }}
                className="absolute right-4 p-3 text-white/80 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition-colors"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedImageIndex((prev) => (prev < images.length - 1 ? prev + 1 : 0));
                }}
                className="absolute left-4 p-3 text-white/80 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition-colors"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
            </>
          )}

          <div 
            className="max-w-5xl max-h-[85vh] rounded-2xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <ImageWithFallback
              src={images[selectedImageIndex]}
              alt={property.title}
              className="w-full h-full object-contain max-h-[85vh]"
            />
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <ConfirmModal
        isOpen={showDeleteConfirm}
        title="حذف فایل ملکی"
        description={`آیا از حذف فایل "${property.title}" (کد: ${property.code}) اطمینان کامل دارید؟ این اقدام غیرقابل بازگشت است.`}
        confirmLabel="بله، حذف شود"
        cancelLabel="انصراف"
        isDanger={true}
        onConfirm={handleDeleteConfirmed}
        onCancel={() => setShowDeleteConfirm(false)}
      />

      {/* Print Brochure Modal */}
      <PropertyPrintModal
        property={property}
        isOpen={showPrintModal}
        onClose={() => setShowPrintModal(false)}
        settings={settings}
      />
    </>
  );
};
