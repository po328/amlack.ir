import React, { useState, useMemo } from 'react';
import {
  Plus,
  Search,
  Filter,
  SlidersHorizontal,
  Grid3X3,
  List,
  Star,
  Building2,
  MapPin,
  Maximize2,
  Layers,
  ChevronDown,
  X,
  Sparkles
} from 'lucide-react';
import { Property, PropertyType, DealType, PropertyStatus, User } from '../../types';
import { formatToman, toPersianDigits } from '../../utils/formatters';
import { ImageWithFallback } from '../common/ImageWithFallback';
import { EmptyState } from '../common/EmptyState';

interface PropertyListProps {
  properties: Property[];
  onOpenNewProperty: () => void;
  onSelectProperty: (property: Property) => void;
  onToggleFavorite: (id: string) => void;
  externalSearchQuery?: string;
  currentUser?: User | null;
}

export const PropertyList: React.FC<PropertyListProps> = ({
  properties,
  onOpenNewProperty,
  onSelectProperty,
  onToggleFavorite,
  externalSearchQuery = '',
  currentUser
}) => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState(externalSearchQuery);
  const [selectedDealType, setSelectedDealType] = useState<string>('all');
  const [selectedPropertyType, setSelectedPropertyType] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'price_asc' | 'price_desc' | 'area_desc'>('newest');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  const isSuperAdmin = currentUser?.role === 'super_admin';
  const isOwner = currentUser?.role === 'owner';
  const perms = (currentUser?.permissions || []).map(p => p.replace(':', '.'));
  const canCreate = isSuperAdmin || isOwner || perms.includes('*') || perms.some(p => p.startsWith('properties.create') || p.startsWith('properties'));

  // Advanced Filters State
  const [minPrice, setMinPrice] = useState<number | ''>('');
  const [maxPrice, setMaxPrice] = useState<number | ''>('');
  const [minMortgage, setMinMortgage] = useState<number | ''>('');
  const [maxMortgage, setMaxMortgage] = useState<number | ''>('');
  const [minRent, setMinRent] = useState<number | ''>('');
  const [maxRent, setMaxRent] = useState<number | ''>('');
  const [minArea, setMinArea] = useState<number | ''>('');
  const [maxArea, setMaxArea] = useState<number | ''>('');
  const [minRooms, setMinRooms] = useState<number | ''>('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);

  const availableFeatures = ['پارکینگ سندی', 'آسانسور', 'انباری', 'بالکن', 'استخر و سونا', 'روف‌گاردن اختصاصی'];

  // Extract distinct districts
  const districts = useMemo(() => {
    const list = Array.from(new Set(properties.map(p => p.district).filter(Boolean)));
    return list;
  }, [properties]);

  const toggleFeature = (feat: string) => {
    if (selectedFeatures.includes(feat)) {
      setSelectedFeatures(selectedFeatures.filter(f => f !== feat));
    } else {
      setSelectedFeatures([...selectedFeatures, feat]);
    }
  };

  const resetAllFilters = () => {
    setSearchQuery('');
    setSelectedDealType('all');
    setSelectedPropertyType('all');
    setMinPrice('');
    setMaxPrice('');
    setMinMortgage('');
    setMaxMortgage('');
    setMinRent('');
    setMaxRent('');
    setMinArea('');
    setMaxArea('');
    setMinRooms('');
    setSelectedDistrict('');
    setSelectedStatus('all');
    setSelectedFeatures([]);
  };

  // Filter & Sort Logic
  const filteredProperties = useMemo(() => {
    return properties.filter((p) => {
      // General search query
      const query = (searchQuery || externalSearchQuery).trim().toLowerCase();
      if (query) {
        const matchTitle = p.title.toLowerCase().includes(query);
        const matchCode = p.code.toLowerCase().includes(query);
        const matchDistrict = p.district.toLowerCase().includes(query);
        const matchAddress = p.address?.toLowerCase().includes(query);
        if (!matchTitle && !matchCode && !matchDistrict && !matchAddress) return false;
      }

      // Deal type
      if (selectedDealType !== 'all' && p.dealType !== selectedDealType) return false;

      // Property type
      if (selectedPropertyType !== 'all' && p.propertyType !== selectedPropertyType) return false;

      // Status
      if (selectedStatus !== 'all' && p.status !== selectedStatus) return false;

      // District
      if (selectedDistrict && p.district !== selectedDistrict) return false;

      // Area
      if (minArea !== '' && p.area < Number(minArea)) return false;
      if (maxArea !== '' && p.area > Number(maxArea)) return false;

      // Rooms
      if (minRooms !== '' && p.rooms < Number(minRooms)) return false;

      // Sale Price
      if (p.dealType === 'sale') {
        if (minPrice !== '' && (p.salePrice || 0) < Number(minPrice)) return false;
        if (maxPrice !== '' && (p.salePrice || 0) > Number(maxPrice)) return false;
      }

      // Rent & Mortgage
      if (p.dealType === 'rent') {
        if (minMortgage !== '' && (p.mortgagePrice || 0) < Number(minMortgage)) return false;
        if (maxMortgage !== '' && (p.mortgagePrice || 0) > Number(maxMortgage)) return false;
        if (minRent !== '' && (p.rentPrice || 0) < Number(minRent)) return false;
        if (maxRent !== '' && (p.rentPrice || 0) > Number(maxRent)) return false;
      }

      // Features
      if (selectedFeatures.length > 0) {
        const hasAllFeatures = selectedFeatures.every(feat => p.features.includes(feat));
        if (!hasAllFeatures) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'newest') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      if (sortBy === 'price_asc') {
        const pA = a.dealType === 'sale' ? (a.salePrice || 0) : (a.mortgagePrice || 0);
        const pB = b.dealType === 'sale' ? (b.salePrice || 0) : (b.mortgagePrice || 0);
        return pA - pB;
      }
      if (sortBy === 'price_desc') {
        const pA = a.dealType === 'sale' ? (a.salePrice || 0) : (a.mortgagePrice || 0);
        const pB = b.dealType === 'sale' ? (b.salePrice || 0) : (b.mortgagePrice || 0);
        return pB - pA;
      }
      if (sortBy === 'area_desc') {
        return b.area - a.area;
      }
      return 0;
    });
  }, [
    properties,
    searchQuery,
    externalSearchQuery,
    selectedDealType,
    selectedPropertyType,
    selectedStatus,
    selectedDistrict,
    minPrice,
    maxPrice,
    minMortgage,
    maxMortgage,
    minRent,
    maxRent,
    minArea,
    maxArea,
    minRooms,
    selectedFeatures,
    sortBy
  ]);

  const propertyTypeLabels: Record<string, string> = {
    apartment: 'آپارتمان',
    villa: 'ویلا',
    commercial: 'تجاری',
    office: 'اداری',
    penthouse: 'پنت‌هاوس',
    land: 'زمین'
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-200">
      {/* Top Header & Search Controls */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 lg:p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg lg:text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-emerald-600" />
              <span>مدیریت فایل‌های ملکی</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              آرشیو کامل املاک با جستجوی هوشمند، فیلتر ترکیبی و مشاهده مشخصات
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold border transition-colors ${
                showAdvancedFilters
                  ? 'bg-emerald-50 border-emerald-300 dark:bg-emerald-950/40 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>فیلتر پیشرفته</span>
              {(minPrice || maxPrice || minMortgage || maxMortgage || minArea || selectedDistrict || selectedFeatures.length > 0) && (
                <span className="w-2 h-2 rounded-full bg-emerald-600" />
              )}
            </button>

            {/* View Mode Toggle */}
            <div className="hidden sm:flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-lg text-xs transition-colors ${
                  viewMode === 'grid'
                    ? 'bg-white dark:bg-slate-700 text-emerald-600 shadow-xs'
                    : 'text-slate-400 hover:text-slate-600'
                }`}
                title="نمایش کارتی"
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-1.5 rounded-lg text-xs transition-colors ${
                  viewMode === 'list'
                    ? 'bg-white dark:bg-slate-700 text-emerald-600 shadow-xs'
                    : 'text-slate-400 hover:text-slate-600'
                }`}
                title="نمایش لیستی"
              >
                <List className="w-4 h-4" />
              </button>
            </div>

            {canCreate && (
              <button
                onClick={onOpenNewProperty}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs lg:text-sm font-bold shadow-md shadow-emerald-600/20 transition-all active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>افزودن ملک</span>
              </button>
            )}
          </div>
        </div>

        {/* Search Bar & Quick Chips */}
        <div className="space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجو در عنوان، کد فایل، منطقه، آدرس یا مشخصات..."
              className="w-full pr-10 pl-4 py-2.5 text-xs lg:text-sm rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-emerald-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            )}
          </div>

          {/* Quick Filters Row */}
          <div className="flex flex-wrap items-center gap-2 overflow-x-auto pb-1">
            {/* Deal Type Chips */}
            <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700">
              {[
                { id: 'all', label: 'همه' },
                { id: 'sale', label: 'فروش' },
                { id: 'rent', label: 'رهن و اجاره' },
                { id: 'presale', label: 'پیش‌فروش' },
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setSelectedDealType(item.id)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                    selectedDealType === item.id
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Property Type Dropdown */}
            <select
              value={selectedPropertyType}
              onChange={(e) => setSelectedPropertyType(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300 font-medium focus:outline-none"
            >
              <option value="all">همه انواع ملک</option>
              <option value="apartment">آپارتمان</option>
              <option value="villa">ویلا</option>
              <option value="commercial">تجاری</option>
              <option value="office">اداری</option>
              <option value="penthouse">پنت‌هاوس</option>
            </select>

            {/* District Dropdown */}
            {districts.length > 0 && (
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300 font-medium focus:outline-none"
              >
                <option value="">همه مناطق ({districts.length})</option>
                {districts.map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            )}

            {/* Sort Selector */}
            <div className="mr-auto flex items-center gap-1 text-xs text-slate-500">
              <span>مرتب‌سازی:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300 font-semibold focus:outline-none"
              >
                <option value="newest">جدیدترین</option>
                <option value="price_asc">قیمت: کم به زیاد</option>
                <option value="price_desc">قیمت: زیاد به کم</option>
                <option value="area_desc">بیشترین متراژ</option>
              </select>
            </div>
          </div>
        </div>

        {/* Advanced Filters Drawer Panel */}
        {showAdvancedFilters && (
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-4 animate-in slide-in-from-top-2 duration-150">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-800 dark:text-slate-200">
                فیلترهای پیشرفته و دقیق
              </span>
              <button
                onClick={resetAllFilters}
                className="text-xs text-red-500 hover:underline font-medium"
              >
                پاکسازی همه فیلترها
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-right">
              {/* Sale Price Range */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  حداقل قیمت فروش (تومان)
                </label>
                <input
                  type="number"
                  placeholder="مثلا: ۵۰۰۰۰۰۰۰۰۰"
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-2.5 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  حداکثر قیمت فروش (تومان)
                </label>
                <input
                  type="number"
                  placeholder="مثلا: ۲۰۰۰۰۰۰۰۰۰۰"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-2.5 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              {/* Area Range */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  حداقل متراژ (متر مربع)
                </label>
                <input
                  type="number"
                  placeholder="مثلا: ۷۰"
                  value={minArea}
                  onChange={(e) => setMinArea(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-2.5 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  حداقل تعداد خواب
                </label>
                <input
                  type="number"
                  placeholder="مثلا: ۲"
                  value={minRooms}
                  onChange={(e) => setMinRooms(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-2.5 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              {/* Mortgage & Rent filters */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  حداکثر ودیعه / رهن (تومان)
                </label>
                <input
                  type="number"
                  placeholder="مثلا: ۱۰۰۰۰۰۰۰۰۰"
                  value={maxMortgage}
                  onChange={(e) => setMaxMortgage(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-2.5 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  حداکثر اجاره ماهانه (تومان)
                </label>
                <input
                  type="number"
                  placeholder="مثلا: ۳۰۰۰۰۰۰۰"
                  value={maxRent}
                  onChange={(e) => setMaxRent(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-2.5 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  وضعیت فایل
                </label>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                >
                  <option value="all">همه وضعیت‌ها</option>
                  <option value="active">فقط فعال</option>
                  <option value="negotiating">در حال مذاکره</option>
                  <option value="sold">معامله شده</option>
                </select>
              </div>
            </div>

            {/* Features Checkboxes */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1.5">
                امکانات الزامی:
              </label>
              <div className="flex flex-wrap gap-2">
                {availableFeatures.map((feat) => {
                  const isChecked = selectedFeatures.includes(feat);
                  return (
                    <button
                      key={feat}
                      type="button"
                      onClick={() => toggleFeature(feat)}
                      className={`px-3 py-1 rounded-xl text-xs transition-all ${
                        isChecked
                          ? 'bg-emerald-600 text-white font-bold'
                          : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {feat}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Results Count Banner */}
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-2">
        <span>نمایش {filteredProperties.length} از {properties.length} فایل ملکی</span>
        {(searchQuery || selectedDealType !== 'all' || selectedPropertyType !== 'all' || minPrice || selectedFeatures.length > 0) && (
          <button
            onClick={resetAllFilters}
            className="text-emerald-600 hover:underline font-semibold"
          >
            پاکسازی فیلترها
          </button>
        )}
      </div>

      {/* Empty State */}
      {filteredProperties.length === 0 && (
        <EmptyState
          icon={Building2}
          title="ملکی با مشخصات انتخابی یافت نشد"
          description="می‌توانید فیلترهای اعمال شده را تغییر دهید یا فایل ملکی جدیدی ثبت کنید."
          actionText="ثبت ملک جدید"
          onAction={onOpenNewProperty}
        />
      )}

      {/* Grid Mode View */}
      {viewMode === 'grid' && filteredProperties.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-5">
          {filteredProperties.map((prop) => (
            <div
              key={prop.id}
              className="bg-white dark:bg-slate-800/90 rounded-3xl overflow-hidden border border-slate-200/80 dark:border-slate-700/80 hover:border-emerald-500/50 hover:shadow-xl transition-all flex flex-col group"
            >
              {/* Image & Badges */}
              <div
                onClick={() => onSelectProperty(prop)}
                className="relative h-48 bg-slate-100 dark:bg-slate-800 cursor-pointer overflow-hidden"
              >
                <ImageWithFallback
                  src={prop.images[0] || ''}
                  alt={prop.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />

                {/* Top Badges */}
                <div className="absolute top-3 right-3 left-3 flex items-center justify-between pointer-events-none">
                  <span className="px-2.5 py-1 rounded-lg text-xs font-black font-mono bg-white/90 dark:bg-slate-900/90 text-slate-800 dark:text-slate-100 shadow-sm backdrop-blur">
                    {prop.code}
                  </span>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite(prop.id);
                    }}
                    className={`pointer-events-auto p-2 rounded-xl backdrop-blur transition-all ${
                      prop.isFavorite
                        ? 'bg-amber-500 text-white shadow-md'
                        : 'bg-black/40 text-white hover:text-amber-400'
                    }`}
                  >
                    <Star className={`w-4 h-4 ${prop.isFavorite ? 'fill-current' : ''}`} />
                  </button>
                </div>

                {/* Bottom Overlay Info */}
                <div className="absolute bottom-3 right-3 left-3 flex items-center justify-between text-white text-xs">
                  <span className={`px-2.5 py-0.5 rounded-full font-bold text-[11px] ${
                    prop.dealType === 'sale'
                      ? 'bg-amber-500'
                      : 'bg-teal-500'
                  }`}>
                    {prop.dealType === 'sale' ? 'فروش' : 'رهن و اجاره'}
                  </span>

                  <span className="flex items-center gap-1 font-medium drop-shadow-sm">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{prop.district}</span>
                  </span>
                </div>
              </div>

              {/* Content Body */}
              <div 
                onClick={() => onSelectProperty(prop)}
                className="p-4 flex-1 flex flex-col justify-between cursor-pointer text-right space-y-3"
              >
                <div>
                  <h3 className="font-bold text-sm lg:text-base text-slate-900 dark:text-white line-clamp-1 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                    {prop.title}
                  </h3>
                  <div className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                    {prop.propertyType ? propertyTypeLabels[prop.propertyType] : 'مسکونی'} • {prop.city}
                  </div>
                </div>

                {/* Specs Chips */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-700/60 text-xs text-slate-600 dark:text-slate-300">
                  <span className="flex items-center gap-1 font-mono">
                    <Maximize2 className="w-3.5 h-3.5 text-slate-400" />
                    <span>{toPersianDigits(prop.area)} متر</span>
                  </span>
                  <span>•</span>
                  <span>{prop.rooms > 0 ? `${toPersianDigits(prop.rooms)} خواب` : 'فلت'}</span>
                  <span>•</span>
                  <span>{prop.floor ? `طبقه ${toPersianDigits(prop.floor)}` : 'همکف'}</span>
                </div>

                {/* Price Display */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60">
                  {prop.dealType === 'sale' ? (
                    <div>
                      <div className="text-xs text-slate-400">قیمت فروش:</div>
                      <div className="text-base font-black text-emerald-600 dark:text-emerald-400 mt-0.5">
                        {formatToman(prop.salePrice)}
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="text-xs font-extrabold text-teal-600 dark:text-teal-400">
                        رهن: {formatToman(prop.mortgagePrice, false)}
                      </div>
                      <div className="text-xs font-bold text-slate-700 dark:text-slate-300 mt-0.5">
                        اجاره: {formatToman(prop.rentPrice)}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* List / Table Mode View */}
      {viewMode === 'list' && filteredProperties.length > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl overflow-hidden border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/70 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="py-3 px-4">کد / تصویر</th>
                  <th className="py-3 px-4">عنوان ملک</th>
                  <th className="py-3 px-4">نوع معامله</th>
                  <th className="py-3 px-4">منطقه</th>
                  <th className="py-3 px-4">متراژ / خواب</th>
                  <th className="py-3 px-4">قیمت / ودیعه و اجاره</th>
                  <th className="py-3 px-4">وضعیت</th>
                  <th className="py-3 px-4 text-center">علاقه‌مندی</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredProperties.map((prop) => (
                  <tr
                    key={prop.id}
                    onClick={() => onSelectProperty(prop)}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-10 h-10 rounded-lg overflow-hidden shrink-0 bg-slate-100 dark:bg-slate-800">
                          <ImageWithFallback
                            src={prop.images[0] || ''}
                            alt=""
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
                          {prop.code}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white max-w-xs truncate">
                      {prop.title}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-md font-bold text-[11px] ${
                        prop.dealType === 'sale'
                          ? 'bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300'
                          : 'bg-teal-100 text-teal-900 dark:bg-teal-950/60 dark:text-teal-300'
                      }`}>
                        {prop.dealType === 'sale' ? 'فروش' : 'رهن و اجاره'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                      {prop.district}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300 font-mono">
                      {prop.area} متر • {prop.rooms} خواب
                    </td>
                    <td className="py-3 px-4 font-black text-emerald-600 dark:text-emerald-400">
                      {prop.dealType === 'sale'
                        ? formatToman(prop.salePrice)
                        : `رهن: ${formatToman(prop.mortgagePrice, false)} | اجاره: ${formatToman(prop.rentPrice)}`}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 font-semibold">
                        {prop.status === 'active' ? 'فعال' : prop.status === 'negotiating' ? 'مذاکره' : 'معامله شد'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => onToggleFavorite(prop.id)}
                        className={`p-1.5 rounded-lg ${
                          prop.isFavorite ? 'text-amber-500' : 'text-slate-300 hover:text-amber-500'
                        }`}
                      >
                        <Star className={`w-4 h-4 ${prop.isFavorite ? 'fill-current' : ''}`} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
