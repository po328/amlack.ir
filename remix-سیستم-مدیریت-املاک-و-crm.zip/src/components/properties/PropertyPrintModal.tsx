import React, { useRef } from 'react';
import { Printer, X, Building2, MapPin, Layers, Calendar, Phone, Check } from 'lucide-react';
import { Property, AppSettings } from '../../types';
import { formatToman, numberToPersianWords, toPersianDigits, formatPersianDate } from '../../utils/formatters';
import { ImageWithFallback } from '../common/ImageWithFallback';

interface PropertyPrintModalProps {
  property: Property | null;
  settings?: AppSettings;
  isOpen: boolean;
  onClose: () => void;
}

export const PropertyPrintModal: React.FC<PropertyPrintModalProps> = ({
  property,
  settings,
  isOpen,
  onClose
}) => {
  const printContentRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !property) return null;

  const agencyName = settings?.agencyName || 'املاک نگین پایتخت';
  const agencyPhone = settings?.phone || '۰۲۱۲۲۰۰۳۳۴۴';
  const managerName = settings?.managerName || 'مدیریت املاک';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-[9990] bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white animate-in fade-in" dir="rtl">
      <div className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 print:shadow-none print:border-none print:max-h-none print:w-full">
        {/* Modal Toolbar (hidden when printing) */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 print:hidden">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-sm text-slate-800 dark:text-white">
              پیش‌نمایش چاپ شناسنامه ملکی (بروشور فایل)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md transition-all active:scale-95"
            >
              <Printer className="w-4 h-4" />
              <span>چاپ / ذخیره PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Area */}
        <div ref={printContentRef} className="p-6 sm:p-8 overflow-y-auto space-y-6 text-slate-900 dark:text-slate-100 print:text-black print:p-0">
          {/* Header with Agency Branding */}
          <div className="flex items-center justify-between pb-4 border-b-2 border-emerald-600">
            <div>
              <h1 className="text-xl font-black text-emerald-800 dark:text-emerald-400 print:text-emerald-800">
                {agencyName}
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                تلفن تماس: {toPersianDigits(agencyPhone)} | نشانی: {settings?.address || 'تهران'}
              </p>
            </div>
            <div className="text-left font-mono">
              <div className="px-3 py-1 bg-slate-100 dark:bg-slate-800 print:bg-slate-100 rounded-lg text-xs font-black">
                کد فایل: {property.code}
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                تاریخ صدور: {formatPersianDate(new Date().toISOString())}
              </div>
            </div>
          </div>

          {/* Title & Badge */}
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black">{property.title}</h2>
            <span className="px-3 py-1 rounded-xl text-xs font-bold bg-emerald-100 text-emerald-900 print:bg-emerald-100 print:text-emerald-900">
              {property.dealType === 'sale' ? 'فروش قطعی' : 'رهن و اجاره مسکونی'}
            </span>
          </div>

          {/* Primary Photo */}
          {property.images && property.images.length > 0 && (
            <div className="rounded-2xl overflow-hidden aspect-16/9 bg-slate-100 max-h-72">
              <ImageWithFallback
                src={property.images[0]}
                alt={property.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          {/* Key Specs Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 print:bg-slate-50 border border-slate-200 dark:border-slate-700">
              <span className="text-[11px] text-slate-400 block">متراژ زیربنا</span>
              <span className="text-sm font-extrabold">{toPersianDigits(property.area)} متر مربع</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 print:bg-slate-50 border border-slate-200 dark:border-slate-700">
              <span className="text-[11px] text-slate-400 block">تعداد اتاق خواب</span>
              <span className="text-sm font-extrabold">{toPersianDigits(property.rooms)} خواب</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 print:bg-slate-50 border border-slate-200 dark:border-slate-700">
              <span className="text-[11px] text-slate-400 block">سال ساخت / سن بنا</span>
              <span className="text-sm font-extrabold">{property.yearBuilt ? `${toPersianDigits(property.yearBuilt)}` : 'نوساز'}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 print:bg-slate-50 border border-slate-200 dark:border-slate-700">
              <span className="text-[11px] text-slate-400 block">محدوده جغرافیایی</span>
              <span className="text-sm font-extrabold">{property.district}</span>
            </div>
          </div>

          {/* Financial Breakdown */}
          <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 print:bg-emerald-50 border border-emerald-200 dark:border-emerald-800 space-y-2">
            <span className="text-xs font-bold text-emerald-950 dark:text-emerald-200 block">شرایط مالی قرارداد</span>
            {property.dealType === 'sale' ? (
              <div className="flex items-baseline justify-between">
                <span className="text-xs text-slate-600 dark:text-slate-300">قیمت کل:</span>
                <span className="text-base font-black text-emerald-800 dark:text-emerald-300">
                  {formatToman(property.salePrice)}
                </span>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-xs text-slate-600 dark:text-slate-300 block">ودیعه (رهن):</span>
                  <span className="text-sm font-black text-emerald-800 dark:text-emerald-300">{formatToman(property.mortgagePrice, false)}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-600 dark:text-slate-300 block">اجاره ماهیانه:</span>
                  <span className="text-sm font-black text-emerald-800 dark:text-emerald-300">{formatToman(property.rentPrice)}</span>
                </div>
              </div>
            )}
          </div>

          {/* Features */}
          {property.features && property.features.length > 0 && (
            <div>
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2">
                امکانات و تجهیزات شاخص
              </span>
              <div className="flex flex-wrap gap-2">
                {property.features.map((f, i) => (
                  <span
                    key={i}
                    className="px-2.5 py-1 rounded-lg text-xs bg-slate-100 dark:bg-slate-800 print:bg-slate-100 border border-slate-200 dark:border-slate-700 flex items-center gap-1 font-medium"
                  >
                    <Check className="w-3 h-3 text-emerald-600" />
                    <span>{f}</span>
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Description */}
          {property.description && (
            <div>
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                توضیحات تکمیلی فایل
              </span>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 print:bg-slate-50 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
                {property.description}
              </p>
            </div>
          )}

          {/* Print Footer */}
          <div className="pt-4 border-t border-slate-200 text-center text-[10px] text-slate-400">
            شناسنامه ملک صادر شده توسط سامانه هوشمند املاک {agencyName} • کلیه اطلاعات نزد آژانس محفوظ و معتبر است.
          </div>
        </div>
      </div>
    </div>
  );
};
