import React, { useState, useEffect } from 'react';
import { X, Building2, Layers, Coins, Image as ImageIcon, UserCheck, Check, AlertCircle } from 'lucide-react';
import { Property, PropertyType, DealType, PropertyStatus } from '../../types';
import { ImageUploader } from '../common/ImageUploader';
import { useToast } from '../../context/ToastContext';
import { toPersianDigits, formatToman } from '../../utils/formatters';

interface PropertyFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (propertyData: any) => void;
  initialProperty?: Property | null;
}

export const PropertyFormModal: React.FC<PropertyFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialProperty
}) => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<'basic' | 'financial' | 'specs' | 'images' | 'owner'>('basic');

  // Form fields
  const [title, setTitle] = useState('');
  const [code, setCode] = useState('');
  const [propertyType, setPropertyType] = useState<PropertyType>('apartment');
  const [dealType, setDealType] = useState<DealType>('sale');
  const [area, setArea] = useState<number | ''>(100);
  const [rooms, setRooms] = useState<number | ''>(2);
  const [floor, setFloor] = useState<number | ''>(2);
  const [totalFloors, setTotalFloors] = useState<number | ''>(5);
  const [yearBuilt, setYearBuilt] = useState<number | ''>(1402);
  const [salePrice, setSalePrice] = useState<number | ''>(10000000000);
  const [mortgagePrice, setMortgagePrice] = useState<number | ''>(600000000);
  const [rentPrice, setRentPrice] = useState<number | ''>(20000000);
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('تهران');
  const [district, setDistrict] = useState('سعادت‌آباد');
  const [description, setDescription] = useState('');
  const [features, setFeatures] = useState<string[]>(['پارکینگ سندی', 'آسانسور', 'انباری']);
  const [newFeatureInput, setNewFeatureInput] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [status, setStatus] = useState<PropertyStatus>('active');
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [assignedAgentName, setAssignedAgentName] = useState('علی رضایی');

  // Validation errors
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (initialProperty) {
      setTitle(initialProperty.title || '');
      setCode(initialProperty.code || '');
      setPropertyType(initialProperty.propertyType || 'apartment');
      setDealType(initialProperty.dealType || 'sale');
      setArea(initialProperty.area || 100);
      setRooms(initialProperty.rooms !== undefined ? initialProperty.rooms : 2);
      setFloor(initialProperty.floor !== undefined ? initialProperty.floor : 1);
      setTotalFloors(initialProperty.totalFloors !== undefined ? initialProperty.totalFloors : 4);
      setYearBuilt(initialProperty.yearBuilt || 1400);
      setSalePrice(initialProperty.salePrice || 0);
      setMortgagePrice(initialProperty.mortgagePrice || 0);
      setRentPrice(initialProperty.rentPrice || 0);
      setAddress(initialProperty.address || '');
      setCity(initialProperty.city || 'تهران');
      setDistrict(initialProperty.district || '');
      setDescription(initialProperty.description || '');
      setFeatures(initialProperty.features || []);
      setImages(initialProperty.images || []);
      setStatus(initialProperty.status || 'active');
      setOwnerName(initialProperty.ownerName || '');
      setOwnerPhone(initialProperty.ownerPhone || '');
      setAssignedAgentName(initialProperty.assignedAgentName || 'علی رضایی');
    } else {
      setCode('ملک-' + Math.floor(100 + Math.random() * 900));
      setTitle('');
      setArea(100);
      setRooms(2);
      setFloor(2);
      setTotalFloors(5);
      setYearBuilt(1402);
      setSalePrice(8500000000);
      setMortgagePrice(500000000);
      setRentPrice(15000000);
      setAddress('');
      setDistrict('سعادت‌آباد');
      setDescription('');
      setOwnerName('');
      setOwnerPhone('');
      setFeatures(['پارکینگ سندی', 'آسانسور', 'انباری']);
      setImages([]);
    }
    setErrors({});
    setActiveTab('basic');
  }, [initialProperty, isOpen]);

  if (!isOpen) return null;

  const handleAddFeature = () => {
    const val = newFeatureInput.trim();
    if (val && !features.includes(val)) {
      setFeatures([...features, val]);
      setNewFeatureInput('');
    }
  };

  const handleRemoveFeature = (feat: string) => {
    setFeatures(features.filter(f => f !== feat));
  };

  const validateForm = (): boolean => {
    const errs: Record<string, string> = {};

    if (!title.trim()) {
      errs.title = 'لطفاً عنوان فایل ملکی را وارد کنید.';
    }
    if (!district.trim()) {
      errs.district = 'لطفاً منطقه / محله را مشخص نمایید.';
    }
    if (!area || Number(area) <= 0) {
      errs.area = 'متراژ باید عددی بزرگتر از صفر باشد.';
    }

    if (dealType === 'sale' || dealType === 'presale') {
      if (!salePrice || Number(salePrice) <= 0) {
        errs.salePrice = 'قیمت کل فروش را به درستی وارد کنید.';
      }
    } else {
      if ((!mortgagePrice || Number(mortgagePrice) <= 0) && (!rentPrice || Number(rentPrice) <= 0)) {
        errs.mortgagePrice = 'حداقل یکی از مقادیر ودیعه یا اجاره باید مشخص شود.';
      }
    }

    if (ownerPhone && !/^09\d{9}$/.test(ownerPhone.trim())) {
      errs.ownerPhone = 'شماره تماس باید ۱۱ رقمی و با ۰۹ آغاز شود.';
    }

    setErrors(errs);
    if (Object.keys(errs).length > 0) {
      // Switch to tab containing the error
      if (errs.title || errs.district) {
        setActiveTab('basic');
      } else if (errs.salePrice || errs.mortgagePrice) {
        setActiveTab('financial');
      } else if (errs.area) {
        setActiveTab('specs');
      } else if (errs.ownerPhone) {
        setActiveTab('owner');
      }
      showToast('لطفاً خطاهای فرم را برطرف نمایید.', 'error');
      return false;
    }
    return true;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const numArea = Number(area) || 0;
    const numSale = Number(salePrice) || 0;

    const payload = {
      code,
      title: title.trim(),
      propertyType,
      dealType,
      area: numArea,
      rooms: Number(rooms) || 0,
      floor: floor !== '' ? Number(floor) : undefined,
      totalFloors: totalFloors !== '' ? Number(totalFloors) : undefined,
      yearBuilt: yearBuilt !== '' ? Number(yearBuilt) : undefined,
      salePrice: dealType === 'sale' || dealType === 'presale' ? numSale : 0,
      pricePerMeter: (dealType === 'sale' || dealType === 'presale') && numArea > 0 ? Math.round(numSale / numArea) : 0,
      mortgagePrice: dealType === 'rent' ? Number(mortgagePrice) || 0 : 0,
      rentPrice: dealType === 'rent' ? Number(rentPrice) || 0 : 0,
      address: address.trim(),
      city: city.trim() || 'تهران',
      district: district.trim(),
      description: description.trim(),
      features,
      images,
      status,
      ownerName: ownerName.trim(),
      ownerPhone: ownerPhone.trim(),
      assignedAgentName: assignedAgentName.trim() || 'مشاور دفتر',
      isFavorite: initialProperty ? initialProperty.isFavorite : false
    };

    onSave(payload);
    showToast(initialProperty ? 'مشخصات ملک با موفقیت به‌روزرسانی شد.' : 'فایل ملکی جدید با موفقیت ثبت شد.', 'success');
    onClose();
  };

  const navTabs = [
    { id: 'basic', label: 'اطلاعات پایه', icon: Building2 },
    { id: 'financial', label: 'شرایط مالی', icon: Coins },
    { id: 'specs', label: 'مشخصات و امکانات', icon: Layers },
    { id: 'images', label: `تصاویر (${images.length})`, icon: ImageIcon },
    { id: 'owner', label: 'مالک و مشاور', icon: UserCheck }
  ];

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 lg:p-6 overflow-y-auto animate-in fade-in"
      dir="rtl"
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 animate-in zoom-in-95"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                {initialProperty ? 'ویرایش شناسنامه فایل ملکی' : 'ثبت فایل ملکی جدید'}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                کد سیستمی: <span className="font-mono text-emerald-600 font-bold">{code}</span>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="بستن"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 px-6 pt-3 pb-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 overflow-x-auto">
          {navTabs.map((tab) => {
            const Icon = tab.icon;
            const hasTabError = (tab.id === 'basic' && (errors.title || errors.district)) ||
                               (tab.id === 'financial' && (errors.salePrice || errors.mortgagePrice)) ||
                               (tab.id === 'specs' && errors.area) ||
                               (tab.id === 'owner' && errors.ownerPhone);

            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {hasTabError && (
                  <span className="w-2 h-2 rounded-full bg-red-400 animate-ping" />
                )}
              </button>
            );
          })}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5 text-right">
          {/* TAB 1: BASIC INFO */}
          {activeTab === 'basic' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    کد فایل
                  </label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>
                <div className="sm:col-span-3">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    عنوان فایل ملکی <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => {
                      setTitle(e.target.value);
                      if (errors.title) setErrors({ ...errors, title: '' });
                    }}
                    placeholder="مثلا: آپارتمان ۱۲۰ متری نوساز تک‌واحدی سعادت‌آباد"
                    className={`w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border focus:outline-none ${
                      errors.title ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 dark:border-slate-700 focus:border-emerald-500'
                    }`}
                  />
                  {errors.title && (
                    <p className="text-[11px] text-red-500 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      <span>{errors.title}</span>
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    نوع ملک
                  </label>
                  <select
                    value={propertyType}
                    onChange={(e) => setPropertyType(e.target.value as PropertyType)}
                    className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-emerald-500 focus:outline-none"
                  >
                    <option value="apartment">آپارتمان مسکونی</option>
                    <option value="villa">ویلا / باغ ویلا</option>
                    <option value="commercial">تجاری / مغازه</option>
                    <option value="office">موقعیت اداری</option>
                    <option value="penthouse">پنت‌هاوس</option>
                    <option value="land">زمین / کلنگی</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    نوع معامله
                  </label>
                  <select
                    value={dealType}
                    onChange={(e) => setDealType(e.target.value as DealType)}
                    className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-emerald-500 focus:outline-none font-bold text-emerald-600 dark:text-emerald-400"
                  >
                    <option value="sale">فروش قطعی</option>
                    <option value="rent">رهن و اجاره</option>
                    <option value="presale">پیش‌فروش ساختمانی</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    وضعیت فایل
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as PropertyStatus)}
                    className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-emerald-500 focus:outline-none"
                  >
                    <option value="active">فعال (آماده بازدید و معامله)</option>
                    <option value="negotiating">در حال مذاکره و نشست</option>
                    <option value="sold">معامله شده (فروخته شد)</option>
                    <option value="rented">اجاره داده شده</option>
                    <option value="archived">بایگانی راکد</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    منطقه / محله <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={district}
                    onChange={(e) => {
                      setDistrict(e.target.value);
                      if (errors.district) setErrors({ ...errors, district: '' });
                    }}
                    placeholder="مثلا: سعادت‌آباد، فرشته، پونک"
                    className={`w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border focus:outline-none ${
                      errors.district ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 dark:border-slate-700 focus:border-emerald-500'
                    }`}
                  />
                  {errors.district && (
                    <p className="text-[11px] text-red-500 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      <span>{errors.district}</span>
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    شهر
                  </label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  آدرس دقیق ملک (محرمانه در اختیار مشاوران)
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="بلوار، خیابان، کوچه، پلاک، طبقه و واحد"
                  className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  توضیحات تکمیلی و ویژگی‌های کلیدی
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                  placeholder="نورگیری، ویو، موقعیت سند، وضعیت تخلیه، شرایط پرداخت..."
                  className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none leading-relaxed"
                />
              </div>
            </div>
          )}

          {/* TAB 2: FINANCIAL */}
          {activeTab === 'financial' && (
            <div className="space-y-5 animate-in fade-in">
              {dealType === 'sale' || dealType === 'presale' ? (
                <div className="p-5 rounded-3xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200/80 dark:border-emerald-900/60 space-y-3">
                  <label className="block text-xs font-black text-emerald-950 dark:text-emerald-200">
                    قیمت کل فروش (تومان) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    value={salePrice}
                    onChange={(e) => {
                      setSalePrice(e.target.value === '' ? '' : Number(e.target.value));
                      if (errors.salePrice) setErrors({ ...errors, salePrice: '' });
                    }}
                    step="50000000"
                    min="0"
                    className={`w-full px-4 py-3 text-base font-black rounded-2xl bg-white dark:bg-slate-800 border focus:outline-none ${
                      errors.salePrice ? 'border-red-500 ring-2 ring-red-500' : 'border-emerald-300 dark:border-emerald-700 focus:ring-2 focus:ring-emerald-500'
                    }`}
                  />
                  {errors.salePrice && (
                    <p className="text-xs text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{errors.salePrice}</span>
                    </p>
                  )}
                  {salePrice !== '' && Number(salePrice) > 0 && (
                    <div className="p-3 rounded-xl bg-emerald-100/60 dark:bg-emerald-900/40 text-xs text-emerald-900 dark:text-emerald-200 flex items-center justify-between">
                      <span>معادل به حروف:</span>
                      <span className="font-bold">{formatToman(Number(salePrice))}</span>
                    </div>
                  )}
                  {salePrice !== '' && Number(salePrice) > 0 && area && Number(area) > 0 && (
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">
                      قیمت هر متر مربع: {formatToman(Math.round(Number(salePrice) / Number(area)))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-5 rounded-3xl bg-teal-50/70 dark:bg-teal-950/20 border border-teal-200/80 dark:border-teal-900/60">
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-teal-950 dark:text-teal-200">
                      مبلغ ودیعه / رهن (تومان)
                    </label>
                    <input
                      type="number"
                      value={mortgagePrice}
                      onChange={(e) => setMortgagePrice(e.target.value === '' ? '' : Number(e.target.value))}
                      step="10000000"
                      min="0"
                      className="w-full px-4 py-2.5 text-sm font-black rounded-2xl bg-white dark:bg-slate-800 border border-teal-300 dark:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                    {mortgagePrice !== '' && Number(mortgagePrice) > 0 && (
                      <div className="text-[11px] text-teal-800 dark:text-teal-300">
                        {formatToman(Number(mortgagePrice), false)}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-black text-teal-950 dark:text-teal-200">
                      اجاره ماهیانه (تومان)
                    </label>
                    <input
                      type="number"
                      value={rentPrice}
                      onChange={(e) => setRentPrice(e.target.value === '' ? '' : Number(e.target.value))}
                      step="1000000"
                      min="0"
                      className="w-full px-4 py-2.5 text-sm font-black rounded-2xl bg-white dark:bg-slate-800 border border-teal-300 dark:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                    {rentPrice !== '' && Number(rentPrice) > 0 && (
                      <div className="text-[11px] text-teal-800 dark:text-teal-300">
                        {formatToman(Number(rentPrice))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: SPECS & FEATURES */}
          {activeTab === 'specs' && (
            <div className="space-y-5 animate-in fade-in">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    متراژ (متر مربع) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    value={area}
                    onChange={(e) => {
                      setArea(e.target.value === '' ? '' : Number(e.target.value));
                      if (errors.area) setErrors({ ...errors, area: '' });
                    }}
                    min="1"
                    className={`w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border focus:outline-none font-mono ${
                      errors.area ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 dark:border-slate-700 focus:border-emerald-500'
                    }`}
                  />
                  {errors.area && (
                    <p className="text-[10px] text-red-500 mt-1">{errors.area}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    تعداد اتاق خواب
                  </label>
                  <input
                    type="number"
                    value={rooms}
                    onChange={(e) => setRooms(e.target.value === '' ? '' : Number(e.target.value))}
                    min="0"
                    className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    طبقه
                  </label>
                  <input
                    type="number"
                    value={floor}
                    onChange={(e) => setFloor(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    سال ساخت
                  </label>
                  <input
                    type="number"
                    value={yearBuilt}
                    onChange={(e) => setYearBuilt(e.target.value === '' ? '' : Number(e.target.value))}
                    placeholder="۱۴۰۲"
                    className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Feature Chips */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  امکانات و تجهیزات ملک
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newFeatureInput}
                    onChange={(e) => setNewFeatureInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddFeature();
                      }
                    }}
                    placeholder="افزودن امکانات (مثلا: روف‌گاردن، استخر، لابی مجلل)..."
                    className="flex-1 px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={handleAddFeature}
                    className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-xs font-bold transition-colors"
                  >
                    افزودن
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {features.map((feat) => (
                    <span
                      key={feat}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 text-xs border border-emerald-200 dark:border-emerald-800"
                    >
                      <Check className="w-3 h-3 text-emerald-600" />
                      <span>{feat}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveFeature(feat)}
                        className="text-emerald-500 hover:text-red-500 font-bold pr-1"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: IMAGES */}
          {activeTab === 'images' && (
            <div className="space-y-4 animate-in fade-in">
              <ImageUploader
                images={images}
                onChange={setImages}
                maxImages={10}
              />
            </div>
          )}

          {/* TAB 5: OWNER & AGENT */}
          {activeTab === 'owner' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-4 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  اطلاعات مالک (محرمانه در دیتابیس املاک)
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      نام مالک
                    </label>
                    <input
                      type="text"
                      value={ownerName}
                      onChange={(e) => setOwnerName(e.target.value)}
                      placeholder="نام و نام خانوادگی مالک"
                      className="w-full px-3 py-2 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      شماره تماس مالک
                    </label>
                    <input
                      type="tel"
                      value={ownerPhone}
                      onChange={(e) => {
                        setOwnerPhone(e.target.value);
                        if (errors.ownerPhone) setErrors({ ...errors, ownerPhone: '' });
                      }}
                      placeholder="09121234567"
                      className={`w-full px-3 py-2 text-xs rounded-xl bg-white dark:bg-slate-900 border font-mono text-left focus:outline-none ${
                        errors.ownerPhone ? 'border-red-500' : 'border-slate-200 dark:border-slate-700'
                      }`}
                      dir="ltr"
                    />
                    {errors.ownerPhone && (
                      <p className="text-[10px] text-red-500 mt-1">{errors.ownerPhone}</p>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  مشاور مسئول فایل
                </label>
                <input
                  type="text"
                  value={assignedAgentName}
                  onChange={(e) => setAssignedAgentName(e.target.value)}
                  placeholder="نام مشاور ملکی"
                  className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <div className="text-xs text-slate-400">
              {activeTab !== 'owner' ? (
                <button
                  type="button"
                  onClick={() => {
                    const idx = navTabs.findIndex(t => t.id === activeTab);
                    if (idx < navTabs.length - 1) {
                      setActiveTab(navTabs[idx + 1].id as any);
                    }
                  }}
                  className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline"
                >
                  مرحله بعدی ←
                </button>
              ) : null}
            </div>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                انصراف
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-md shadow-emerald-600/20 transition-all active:scale-95"
              >
                {initialProperty ? 'ذخیره تغییرات شناسنامه' : 'ثبت قطعی فایل در سامانه'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
