import React, { useState, useEffect } from 'react';
import { 
  Building, 
  Users, 
  FileText, 
  TrendingUp, 
  ShieldCheck, 
  Plus, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  ExternalLink,
  Layers,
  Database,
  ArrowRight
} from 'lucide-react';
import { PlatformStats, Tenant } from '../../types';
import { toPersianDigits, formatCurrency } from '../../utils/formatters';

interface SuperAdminDashboardProps {
  stats: PlatformStats | null;
  tenants: Tenant[];
  currentTenantId: string;
  onSwitchTenant: (tenantId: string) => void;
  onCreateTenant: (data: any) => Promise<void>;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const SuperAdminDashboard: React.FC<SuperAdminDashboardProps> = ({
  stats,
  tenants,
  currentTenantId,
  onSwitchTenant,
  onCreateTenant,
  showToast
}) => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [agencyName, setAgencyName] = useState('');
  const [slug, setSlug] = useState('');
  const [managerName, setManagerName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('تهران');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [subscriptionPlan, setSubscriptionPlan] = useState<'trial' | 'standard' | 'premium' | 'enterprise'>('standard');
  const [ownerUsername, setOwnerUsername] = useState('');
  const [ownerPassword, setOwnerPassword] = useState('123456');

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!agencyName || !slug || !managerName || !phone) {
      showToast('لطفاً فیلدهای الزامی را پر کنید.', 'error');
      return;
    }

    try {
      await onCreateTenant({
        name: agencyName,
        slug: slug.toLowerCase().trim(),
        managerName,
        phone,
        email,
        city,
        licenseNumber,
        subscriptionPlan,
        ownerUsername,
        ownerPassword
      });

      setIsCreateModalOpen(false);
      // Reset
      setAgencyName('');
      setSlug('');
      setManagerName('');
      setPhone('');
      setEmail('');
      setLicenseNumber('');
      showToast('آژانس جدید با محیط و دیتابیس اختصاصی ایجاد گردید.', 'success');
    } catch (err: any) {
      showToast(err.message || 'خطا در ثبت آژانس', 'error');
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in" dir="rtl">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg text-xs font-black bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
              Super Admin Core
            </span>
            <span className="text-xs text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
              <Database className="w-3.5 h-3.5" />
              محیط چندمستأجره ابری (Multi-Tenant) فعال
            </span>
          </div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white mt-1">
            مرکز کنترل و نظارت پلتفرم املاک کشور
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            مدیریت متمرکز آژانس‌های املاک، ایزولاسیون کامل دیتابیس، پلن‌های اشتراک و نظارت ترافیک
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 active:bg-purple-800 text-white text-xs font-bold shadow-md transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          ثبت آژانس املاک جدید
        </button>
      </div>

      {/* Platform-Wide Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">کل دفاتر املاک فعال</span>
            <Building className="w-4 h-4 text-purple-600" />
          </div>
          <div className="mt-2 text-2xl font-black text-purple-600 dark:text-purple-400">
            {toPersianDigits(stats?.summary.totalTenants || tenants.length)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">محیط کاملاً مستقل و ایزوله</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">کل کاربران و مشاوران</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900 dark:text-white">
            {toPersianDigits(stats?.summary.totalUsers || 0)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">در سراسر شعب پلتفرم</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">فایل‌های ملکی کل سامانه</span>
            <Layers className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 text-2xl font-black text-emerald-600 dark:text-emerald-400">
            {toPersianDigits(stats?.summary.totalProperties || 0)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">بدون تداخل بین دفاتر</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">گردش کمیسیون کل شعب</span>
            <TrendingUp className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 text-xl font-black text-amber-600 dark:text-amber-400">
            {formatCurrency(stats?.summary.totalCommissions || 0)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">مجموع قراردادهای ثبت‌شده</div>
        </div>
      </div>

      {/* Real Estate Agencies Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Building className="w-4 h-4 text-purple-600" />
            فهرست آژانس‌های عضو سامانه و وضعیت تفکیک داده
          </h3>
          <span className="text-xs text-slate-400">
            تعداد: {toPersianDigits(tenants.length)} آژانس
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 font-bold border-b border-slate-200 dark:border-slate-800">
                <th className="p-3.5">نام آژانس</th>
                <th className="p-3.5">شناسه انگلیسی (Slug)</th>
                <th className="p-3.5">مدیریت / تماس</th>
                <th className="p-3.5">پروانه اتحادیه</th>
                <th className="p-3.5">پلن اشتراک</th>
                <th className="p-3.5">آمار (املاک / متقاضی)</th>
                <th className="p-3.5">وضعیت</th>
                <th className="p-3.5 text-center">ورود به محیط آژانس</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {tenants.map((t) => {
                const isCurrent = t.id === currentTenantId;
                return (
                  <tr key={t.id} className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors ${isCurrent ? 'bg-purple-50/50 dark:bg-purple-950/20' : ''}`}>
                    <td className="p-3.5 font-bold text-slate-900 dark:text-white">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 flex items-center justify-center font-black text-xs">
                          {t.name.slice(0, 1)}
                        </div>
                        <div>
                          <div>{t.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{t.id}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-3.5 font-mono text-slate-600 dark:text-slate-400">
                      {t.slug}
                    </td>
                    <td className="p-3.5">
                      <div className="font-bold text-slate-800 dark:text-slate-200">{t.manager_name}</div>
                      <div className="text-[11px] text-slate-400 font-mono">{toPersianDigits(t.phone)}</div>
                    </td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-400">
                      {t.license_number || 'در حال استعلام'}
                    </td>
                    <td className="p-3.5">
                      <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold ${
                        t.subscription_plan === 'enterprise' 
                          ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300'
                          : 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                      }`}>
                        {t.subscription_plan === 'enterprise' ? 'سازمانی نامحدود' : 'پرمیوم تخصصی'}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span className="font-bold text-slate-700 dark:text-slate-300">
                        {toPersianDigits(stats?.tenants.find((s) => s.id === t.id)?.properties_count || 0)} ملک
                      </span>
                      <span className="text-slate-400 mx-1">/</span>
                      <span className="text-slate-500">
                        {toPersianDigits(stats?.tenants.find((s) => s.id === t.id)?.customers_count || 0)} مشتری
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 flex items-center gap-1 w-fit">
                        <CheckCircle className="w-3 h-3" />
                        فعال
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      {isCurrent ? (
                        <span className="px-3 py-1.5 rounded-xl bg-purple-600 text-white font-bold text-[11px] shadow-xs">
                          محیط فعال فعلی
                        </span>
                      ) : (
                        <button
                          onClick={() => {
                            onSwitchTenant(t.id);
                            showToast(`محیط کاری به «${t.name}» تغییر یافت. تمام اطلاعات ایزوله این آژانس بارگذاری شد.`, 'info');
                          }}
                          className="px-3 py-1.5 rounded-xl border border-purple-300 dark:border-purple-800 text-purple-700 dark:text-purple-300 hover:bg-purple-100 dark:hover:bg-purple-950 font-bold text-[11px] flex items-center gap-1 mx-auto transition-colors"
                        >
                          ورود به پنل
                          <ArrowRight className="w-3 h-3 rotate-180" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Create Real Estate Agency */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-xl max-h-[90vh] overflow-y-auto p-6 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 flex items-center justify-center font-black">
                <Building className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  افتتاح آژانس املاک جدید در سامانه
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  ایجاد پایگاه داده مستقل، حساب مالک آژانس و تفکیک فضای اختصاصی آپلود
                </p>
              </div>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">نام رسمی آژانس املاک</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: املاک رویال نیاوران"
                    value={agencyName}
                    onChange={(e) => setAgencyName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">شناسه انگلیسی آژانس (Slug)</label>
                  <input
                    type="text"
                    required
                    placeholder="royal-niavaran"
                    value={slug}
                    onChange={(e) => setSlug(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">نام مدیر مسئول</label>
                  <input
                    type="text"
                    required
                    placeholder="نام و نام خانوادگی مدیر"
                    value={managerName}
                    onChange={(e) => setManagerName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">شماره تماس دفتر</label>
                  <input
                    type="text"
                    required
                    placeholder="02122334455"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">شماره پروانه کسب اتحادیه</label>
                  <input
                    type="text"
                    placeholder="الف/۸۸۹۹۰۰"
                    value={licenseNumber}
                    onChange={(e) => setLicenseNumber(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">پلن اشتراک</label>
                  <select
                    value={subscriptionPlan}
                    onChange={(e: any) => setSubscriptionPlan(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  >
                    <option value="trial">آزمایشی ۱۴ روزه</option>
                    <option value="standard">استاندارد (تا ۱۰ مشاور)</option>
                    <option value="premium">حرفه‌ای (تا ۲۵ مشاور)</option>
                    <option value="enterprise">سازمانی نامحدود</option>
                  </select>
                </div>
              </div>

              {/* Owner account credentials */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-2">حساب کاربری مدیر آژانس</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">نام کاربری مالک</label>
                    <input
                      type="text"
                      placeholder="admin_royal"
                      value={ownerUsername}
                      onChange={(e) => setOwnerUsername(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">کلمه عبور اولیه</label>
                    <input
                      type="password"
                      value={ownerPassword}
                      onChange={(e) => setOwnerPassword(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 font-bold"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold shadow-md"
                >
                  تأیید و راه‌اندازی آژانس
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
