import React, { useState } from 'react';
import {
  X,
  Phone,
  Mail,
  Calendar,
  Clock,
  Plus,
  Building2,
  Trash2,
  Edit,
  CheckCircle2,
  MessageSquare,
  Sparkles,
  MapPin,
  Coins,
  ArrowUpRight
} from 'lucide-react';
import { Customer, ContactInteraction, Property, FollowUp, User } from '../../types';
import { formatToman, formatPersianDate, toPersianDigits } from '../../utils/formatters';
import { ConfirmModal } from '../common/ConfirmModal';
import { EmptyState } from '../common/EmptyState';
import { ImageWithFallback } from '../common/ImageWithFallback';
import { useToast } from '../../context/ToastContext';

interface CustomerDetailModalProps {
  customer: Customer | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (customer: Customer) => void;
  onDelete: (id: string) => void;
  interactions: ContactInteraction[];
  onAddInteraction: (contactData: Omit<ContactInteraction, 'id'>) => void;
  onAddFollowUp: (taskData: Omit<FollowUp, 'id' | 'createdAt'>) => void;
  properties: Property[];
  onSelectProperty: (property: Property) => void;
  currentUser?: User | null;
}

export const CustomerDetailModal: React.FC<CustomerDetailModalProps> = ({
  customer,
  isOpen,
  onClose,
  onEdit,
  onDelete,
  interactions,
  onAddInteraction,
  onAddFollowUp,
  properties,
  onSelectProperty,
  currentUser
}) => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<'profile' | 'interactions' | 'matching' | 'newTask'>('profile');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const isSuperAdmin = currentUser?.role === 'super_admin';
  const isOwner = currentUser?.role === 'owner';
  const perms = (currentUser?.permissions || []).map(p => p.replace(':', '.'));
  const canEdit = isSuperAdmin || isOwner || perms.includes('*') || perms.some(p => p.startsWith('customers.edit') || p.startsWith('customers'));
  const canDelete = isSuperAdmin || isOwner || perms.includes('*') || perms.some(p => p.startsWith('customers.delete'));

  // New interaction state
  const [newLogType, setNewLogType] = useState<ContactInteraction['type']>('call');
  const [newLogNotes, setNewLogNotes] = useState('');
  const [newLogResult, setNewLogResult] = useState('');

  // New quick task state
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDate, setNewTaskDate] = useState(new Date().toISOString().split('T')[0]);
  const [newTaskTime, setNewTaskTime] = useState('16:00');
  const [newTaskPriority, setNewTaskPriority] = useState<'high' | 'medium' | 'low'>('high');

  if (!isOpen || !customer) return null;

  const customerInteractions = interactions.filter(i => i.customerId === customer.id);

  // Smart Matching Properties
  const matchingProperties = properties.filter((p) => {
    // Deal Type match
    if (customer.dealType === 'buy' && p.dealType !== 'sale' && p.dealType !== 'presale') return false;
    if (customer.dealType === 'rent' && p.dealType !== 'rent') return false;

    // Budget check
    if ((customer.dealType === 'buy' || customer.dealType === 'sell') && customer.budgetMax && p.salePrice) {
      if (p.salePrice > customer.budgetMax * 1.15) return false;
    }
    if (customer.dealType === 'rent' && customer.mortgageMax && p.mortgagePrice) {
      if (p.mortgagePrice > customer.mortgageMax * 1.2) return false;
    }

    // District match if specified
    if (customer.preferredDistricts && customer.preferredDistricts.length > 0) {
      const hasDistrict = customer.preferredDistricts.some(d => p.district.includes(d) || d.includes(p.district));
      if (!hasDistrict && customer.preferredDistricts.length > 2) return false;
    }

    return true;
  });

  const handleSaveInteraction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLogNotes.trim()) {
      showToast('لطفاً خلاصه مذاکره را وارد فرمایید.', 'error');
      return;
    }

    onAddInteraction({
      customerId: customer.id,
      customerName: customer.fullName,
      type: newLogType,
      date: new Date().toISOString(),
      notes: newLogNotes.trim(),
      result: newLogResult.trim() || 'ثبت در تاریخچه'
    });

    setNewLogNotes('');
    setNewLogResult('');
    showToast('گزارش تماس با موفقیت در پرونده ثبت شد.', 'success');
    setActiveTab('interactions');
  };

  const handleSaveTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) {
      showToast('لطفاً عنوان وظیفه پیگیری را وارد فرمایید.', 'error');
      return;
    }

    onAddFollowUp({
      title: newTaskTitle.trim(),
      customerId: customer.id,
      customerName: customer.fullName,
      dueDate: newTaskDate,
      dueTime: newTaskTime,
      priority: newTaskPriority,
      status: 'pending',
      notes: `پیگیری مربوط به پرونده ${customer.fullName}`
    });

    setNewTaskTitle('');
    showToast('وظیفه پیگیری در تقویم کاری ثبت شد.', 'success');
    setActiveTab('profile');
  };

  const handleDeleteConfirmed = () => {
    onDelete(customer.id);
    setShowDeleteConfirm(false);
    showToast('پرونده متقاضی با موفقیت حذف شد.', 'info');
    onClose();
  };

  return (
    <>
      <div 
        className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-2 lg:p-4 overflow-y-auto animate-in fade-in"
        dir="rtl"
        role="dialog"
        aria-modal="true"
      >
        <div 
          className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 animate-in zoom-in-95"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-base">
                {customer.fullName.slice(0, 1)}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                    {customer.fullName}
                  </h3>
                  <span className="text-[11px] px-2.5 py-0.5 rounded-full font-bold bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300">
                    {customer.customerType === 'buyer' ? 'خریدار' : customer.customerType === 'tenant' ? 'مستاجر' : 'مالک/سرمایه‌گذار'}
                  </span>
                </div>
                <div className="text-xs text-slate-400 mt-0.5">
                  عضویت از {formatPersianDate(customer.createdAt)}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <a
                href={`tel:${customer.phone}`}
                className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 transition-colors"
                title="تماس تلفنی"
              >
                <Phone className="w-4 h-4" />
              </a>
              {canEdit && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onEdit(customer);
                  }}
                  className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                  title="ویرایش"
                >
                  <Edit className="w-4 h-4" />
                </button>
              )}
              {canDelete && (
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(true)}
                  className="p-2 rounded-xl border border-red-200 dark:border-red-900/50 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                  title="حذف پرونده"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                aria-label="بستن"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 px-6 pt-3 pb-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 overflow-x-auto">
            {[
              { id: 'profile', label: 'اطلاعات پرونده و ترجیحات' },
              { id: 'matching', label: `فایل‌های پیشنهادی (${toPersianDigits(matchingProperties.length)})` },
              { id: 'interactions', label: `تاریخچه تماس و مذاکره (${toPersianDigits(customerInteractions.length)})` },
              { id: 'newTask', label: '+ تنظیم پیگیری بعدی' }
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Modal Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-5 text-right">
            {/* TAB: PROFILE */}
            {activeTab === 'profile' && (
              <div className="space-y-4 animate-in fade-in">
                {/* Contact Card */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700/60">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-[11px] text-slate-400">شماره تماس مستقیم</div>
                      <div className="text-xs lg:text-sm font-black font-mono text-slate-800 dark:text-slate-100" dir="ltr">
                        {customer.phone}
                      </div>
                    </div>
                  </div>

                  {customer.email && (
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-950/40 text-blue-600 flex items-center justify-center">
                        <Mail className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-[11px] text-slate-400">ایمیل</div>
                        <div className="text-xs font-mono text-slate-700 dark:text-slate-200 truncate max-w-[200px]" dir="ltr">
                          {customer.email}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Requirements & Budget */}
                <div className="space-y-3">
                  <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <Building2 className="w-4 h-4 text-blue-600" />
                    <span>مشخصات تقاضا و توان مالی</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                      <div className="text-[11px] text-slate-400">مناطق انتخابی</div>
                      <div className="text-xs font-bold text-slate-800 dark:text-slate-100 mt-1">
                        {customer.preferredDistricts && customer.preferredDistricts.length > 0
                          ? customer.preferredDistricts.join('، ')
                          : 'تمام مناطق'}
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                      <div className="text-[11px] text-slate-400">متراژ و خواب مدنظر</div>
                      <div className="text-xs font-bold text-slate-800 dark:text-slate-100 mt-1 font-mono">
                        {customer.minArea || '-'} الی {customer.maxArea || '-'} متر
                        {customer.minRooms ? ` • حداقل ${toPersianDigits(customer.minRooms)} خواب` : ''}
                      </div>
                    </div>
                  </div>

                  {/* Budget card */}
                  <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/50">
                    <div className="text-xs text-emerald-900 dark:text-emerald-300 font-bold">
                      سقف بودجه مالی ثبت شده:
                    </div>
                    <div className="text-base lg:text-lg font-black text-emerald-700 dark:text-emerald-300 mt-1">
                      {customer.dealType === 'buy' || customer.dealType === 'sell'
                        ? (customer.budgetMax ? formatToman(customer.budgetMax) : 'نامحدود')
                        : `رهن: ${formatToman(customer.mortgageMax, false)} • اجاره: ${formatToman(customer.rentMax)}`}
                    </div>
                  </div>
                </div>

                {/* Notes */}
                {customer.notes && (
                  <div className="space-y-1.5">
                    <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200">یادداشت‌ها و شرایط ویژه</h4>
                    <p className="text-xs lg:text-sm text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-2xl border border-slate-100 dark:border-slate-800 leading-relaxed">
                      {customer.notes}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* TAB: MATCHING PROPERTIES */}
            {activeTab === 'matching' && (
              <div className="space-y-3 animate-in fade-in">
                {matchingProperties.length === 0 ? (
                  <EmptyState
                    icon={Building2}
                    title="فایل ملکی منطبقی یافت نشد"
                    description="در حال حاضر فایلی با این محدوده بودجه و مشخصات ثبت نشده است."
                  />
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {matchingProperties.map((p) => (
                      <div
                        key={p.id}
                        onClick={() => {
                          onClose();
                          onSelectProperty(p);
                        }}
                        className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 hover:border-blue-500 cursor-pointer transition-all shadow-xs group"
                      >
                        <div className="flex gap-3">
                          <div className="w-16 h-16 rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-700 shrink-0">
                            <ImageWithFallback
                              src={p.images[0] || ''}
                              alt=""
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <span className="text-[10px] font-mono font-bold text-slate-400">{p.code}</span>
                            <h5 className="font-bold text-xs text-slate-900 dark:text-white truncate mt-0.5">
                              {p.title}
                            </h5>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                              {p.district} • {toPersianDigits(p.area)} متر
                            </div>
                            <div className="text-xs font-black text-emerald-600 dark:text-emerald-400 mt-1">
                              {p.dealType === 'sale' ? formatToman(p.salePrice) : formatToman(p.rentPrice)}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB: INTERACTIONS HISTORY */}
            {activeTab === 'interactions' && (
              <div className="space-y-4 animate-in fade-in">
                {/* Form to log quick interaction */}
                <form onSubmit={handleSaveInteraction} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
                  <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    ثبت نتیجه تماس یا جلسه جدید
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <select
                      value={newLogType}
                      onChange={(e) => setNewLogType(e.target.value as any)}
                      className="px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                    >
                      <option value="call">تماس تلفنی</option>
                      <option value="visit">بازدید حضوری از ملک</option>
                      <option value="meeting">جلسه و نشست حضوری</option>
                      <option value="whatsapp">پیام‌رسان / واتساپ</option>
                    </select>
                    <input
                      type="text"
                      value={newLogResult}
                      onChange={(e) => setNewLogResult(e.target.value)}
                      placeholder="نتیجه کلی (مثلا: هماهنگی بازدید، تمایل به تخفیف)"
                      className="sm:col-span-2 px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                    />
                  </div>
                  <textarea
                    value={newLogNotes}
                    onChange={(e) => setNewLogNotes(e.target.value)}
                    rows={2}
                    placeholder="مشروح نکات مطرح شده در تماس..."
                    className="w-full px-3 py-2 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none leading-relaxed"
                  />
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors"
                    >
                      ثبت در پرونده
                    </button>
                  </div>
                </form>

                {/* Log timeline */}
                {customerInteractions.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-6">هنوز تماسی برای این مشتری ثبت نشده است.</p>
                ) : (
                  <div className="space-y-2.5">
                    {customerInteractions.map((int) => (
                      <div
                        key={int.id}
                        className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-1.5"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                            <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
                            <span>{int.result || 'گزارش ارتباط'}</span>
                          </span>
                          <span className="text-slate-400 font-mono text-[11px]">
                            {formatPersianDate(int.date)}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                          {int.notes}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB: NEW TASK / FOLLOWUP */}
            {activeTab === 'newTask' && (
              <form onSubmit={handleSaveTask} className="space-y-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 animate-in fade-in">
                <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  ثبت یادآور و وظیفه پیگیری برای این متقاضی
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    عنوان وظیفه پیگیری *
                  </label>
                  <input
                    type="text"
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                    placeholder="مثلا: تماس جهت ارسال فیلم و مدارک ملک سعادت‌آباد"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      تاریخ پیگیری
                    </label>
                    <input
                      type="date"
                      value={newTaskDate}
                      onChange={(e) => setNewTaskDate(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      ساعت
                    </label>
                    <input
                      type="time"
                      value={newTaskTime}
                      onChange={(e) => setNewTaskTime(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      اولویت
                    </label>
                    <select
                      value={newTaskPriority}
                      onChange={(e) => setNewTaskPriority(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none"
                    >
                      <option value="high">فوری و مهم (بالا)</option>
                      <option value="medium">متوسط</option>
                      <option value="low">عادی</option>
                    </select>
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-600/20 transition-all active:scale-95"
                  >
                    ثبت وظیفه در تقویم پیگیری‌ها
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={showDeleteConfirm}
        title="حذف پرونده مشتری"
        description={`آیا از حذف پرونده "${customer.fullName}" (${customer.phone}) اطمینان دارید؟ تمام تاریخچه و یادداشت‌های این پرونده حذف خواهند شد.`}
        confirmLabel="بله، پرونده حذف شود"
        cancelLabel="انصراف"
        isDanger={true}
        onConfirm={handleDeleteConfirmed}
        onCancel={() => setShowDeleteConfirm(false)}
      />
    </>
  );
};
