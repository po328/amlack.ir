import React, { useState, useMemo } from 'react';
import {
  Users,
  Plus,
  Search,
  Phone,
  Filter,
  MapPin,
  Calendar,
  MessageSquare,
  CheckCircle2,
  Clock,
  Sparkles
} from 'lucide-react';
import { Customer, CustomerType, CustomerStatus, User } from '../../types';
import { formatToman, formatPersianDate, toPersianDigits } from '../../utils/formatters';
import { EmptyState } from '../common/EmptyState';

interface CustomerListProps {
  customers: Customer[];
  onOpenNewCustomer: () => void;
  onSelectCustomer: (customer: Customer) => void;
  externalSearchQuery?: string;
  currentUser?: User | null;
}

export const CustomerList: React.FC<CustomerListProps> = ({
  customers,
  onOpenNewCustomer,
  onSelectCustomer,
  externalSearchQuery = '',
  currentUser
}) => {
  const [searchQuery, setSearchQuery] = useState(externalSearchQuery);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  const isSuperAdmin = currentUser?.role === 'super_admin';
  const isOwner = currentUser?.role === 'owner';
  const perms = (currentUser?.permissions || []).map(p => p.replace(':', '.'));
  const canCreate = isSuperAdmin || isOwner || perms.includes('*') || perms.some(p => p.startsWith('customers.create') || p.startsWith('customers'));

  const filteredCustomers = useMemo(() => {
    return customers.filter((c) => {
      const q = (searchQuery || externalSearchQuery).trim().toLowerCase();
      if (q) {
        const matchName = c.fullName.toLowerCase().includes(q);
        const matchPhone = c.phone.includes(q);
        const matchDistricts = c.preferredDistricts?.some(d => d.toLowerCase().includes(q));
        if (!matchName && !matchPhone && !matchDistricts) return false;
      }

      if (selectedType !== 'all' && c.customerType !== selectedType) return false;
      if (selectedStatus !== 'all' && c.status !== selectedStatus) return false;

      return true;
    }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [customers, searchQuery, externalSearchQuery, selectedType, selectedStatus]);

  const customerTypeLabels: Record<string, string> = {
    buyer: 'خریدار',
    tenant: 'مستاجر',
    seller: 'فروشنده / مالک',
    landlord: 'موجر',
    investor: 'سرمایه‌گذار'
  };

  const customerStatusLabels: Record<string, { label: string; color: string }> = {
    active: { label: 'فعال در بازار', color: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300' },
    in_progress: { label: 'در حال مذاکره', color: 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300' },
    deal_closed: { label: 'معامله موفق', color: 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300' },
    cancelled: { label: 'انصراف', color: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400' }
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-200">
      {/* Header & Controls */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 lg:p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg lg:text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              <span>مدیریت متقاضیان و CRM</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              ثبت تقاضا، مشخصات تماس، توان مالی و تاریخچه مذاکرات خریداران و مستاجران
            </p>
          </div>

          {canCreate && (
            <button
              onClick={onOpenNewCustomer}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs lg:text-sm font-bold shadow-md shadow-blue-600/20 transition-all active:scale-95 self-start md:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>ثبت متقاضی جدید</span>
            </button>
          )}
        </div>

        {/* Search & Filters */}
        <div className="space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجو بر اساس نام متقاضی، شماره موبایل یا محله مدنظر..."
              className="w-full pr-10 pl-4 py-2.5 text-xs lg:text-sm rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>

          {/* Quick Filter Chips */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700">
              {[
                { id: 'all', label: 'همه متقاضیان' },
                { id: 'buyer', label: 'خریداران' },
                { id: 'tenant', label: 'مستاجران' },
                { id: 'investor', label: 'سرمایه‌گذاران' },
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setSelectedType(item.id)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                    selectedType === item.id
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none text-slate-700 dark:text-slate-300"
              >
                <option value="all">همه وضعیت‌ها</option>
                <option value="active">فعال در بازار</option>
                <option value="in_progress">در حال مذاکره</option>
                <option value="deal_closed">معامله موفق</option>
                <option value="cancelled">انصراف</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-2">
        <span>نمایش {toPersianDigits(filteredCustomers.length)} از {toPersianDigits(customers.length)} پرونده متقاضی</span>
        {(searchQuery || selectedType !== 'all' || selectedStatus !== 'all') && (
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedType('all');
              setSelectedStatus('all');
            }}
            className="text-blue-600 hover:underline font-semibold"
          >
            پاکسازی فیلترها
          </button>
        )}
      </div>

      {/* Empty State */}
      {filteredCustomers.length === 0 && (
        <EmptyState
          icon={Users}
          title="متقاضی با این مشخصات یافت نشد"
          description="می‌توانید عبارت جستجو را تغییر دهید یا پرونده مشتری جدیدی ثبت نمایید."
          actionText="ثبت متقاضی جدید"
          onAction={onOpenNewCustomer}
        />
      )}

      {/* Customer Cards Grid */}
      {filteredCustomers.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCustomers.map((cust) => {
            const statusInfo = customerStatusLabels[cust.status] || customerStatusLabels.active;
            return (
              <div
                key={cust.id}
                onClick={() => onSelectCustomer(cust)}
                className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs hover:border-blue-500/50 hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between space-y-4 group"
              >
                <div>
                  {/* Top Bar: Avatar, Name & Status */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-500/20 to-blue-600/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-black text-sm">
                        {cust.fullName.slice(0, 1)}
                      </div>
                      <div>
                        <h4 className="font-extrabold text-sm text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                          {cust.fullName}
                        </h4>
                        <span className="text-[11px] text-slate-400">
                          {customerTypeLabels[cust.customerType] || 'متقاضی'}
                        </span>
                      </div>
                    </div>

                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${statusInfo.color}`}>
                      {statusInfo.label}
                    </span>
                  </div>

                  {/* Requirements Summary */}
                  <div className="mt-3.5 space-y-2 text-right">
                    <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 text-xs">
                      <MapPin className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                      <span className="truncate">
                        مناطق: {cust.preferredDistricts && cust.preferredDistricts.length > 0 ? cust.preferredDistricts.join('، ') : 'نامشخص'}
                      </span>
                    </div>

                    <div className="text-slate-500 dark:text-slate-400 text-[11px]">
                      متراژ: {cust.minArea ? toPersianDigits(cust.minArea) : '-'} تا {cust.maxArea ? toPersianDigits(cust.maxArea) : '-'} متر 
                      {cust.minRooms ? ` • حداقل ${toPersianDigits(cust.minRooms)} خواب` : ''}
                    </div>

                    {/* Budget Badge */}
                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 mt-2">
                      <span className="text-[10px] text-slate-400 block">بودجه درخواستی:</span>
                      <div className="font-black text-xs text-emerald-600 dark:text-emerald-400 mt-0.5">
                        {cust.dealType === 'buy' || cust.dealType === 'sell'
                          ? (cust.budgetMax ? `تا ${formatToman(cust.budgetMax)}` : 'نامحدود')
                          : `رهن: ${formatToman(cust.mortgageMax, false)} • اجاره: ${formatToman(cust.rentMax)}`}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer Bar: Phone & Last contact */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-slate-400">
                    آخرین تماس: {formatPersianDate(cust.lastContactDate || cust.createdAt)}
                  </span>

                  <a
                    href={`tel:${cust.phone}`}
                    onClick={(e) => e.stopPropagation()}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-mono text-xs font-bold hover:bg-emerald-100"
                  >
                    <Phone className="w-3 h-3" />
                    <span dir="ltr">{cust.phone}</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
