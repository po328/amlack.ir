import React, { useState, useEffect } from 'react';
import { X, Users, AlertCircle, Phone, Mail, MapPin, Coins, Home, Check } from 'lucide-react';
import { Customer, CustomerType, CustomerStatus, PropertyType } from '../../types';
import { useToast } from '../../context/ToastContext';
import { formatToman } from '../../utils/formatters';

interface CustomerFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (customerData: any) => void;
  initialCustomer?: Customer | null;
}

export const CustomerFormModal: React.FC<CustomerFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialCustomer
}) => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<'personal' | 'preferences' | 'notes'>('personal');

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [customerType, setCustomerType] = useState<CustomerType>('buyer');
  const [dealType, setDealType] = useState<'buy' | 'rent' | 'sell' | 'let'>('buy');
  const [status, setStatus] = useState<CustomerStatus>('active');
  const [preferredPropertyTypes, setPreferredPropertyTypes] = useState<PropertyType[]>(['apartment']);
  const [minArea, setMinArea] = useState<number | ''>(80);
  const [maxArea, setMaxArea] = useState<number | ''>(130);
  const [minRooms, setMinRooms] = useState<number | ''>(2);
  const [preferredDistricts, setPreferredDistricts] = useState<string[]>(['سعادت‌آباد']);
  const [newDistrictInput, setNewDistrictInput] = useState('');
  const [budgetMin, setBudgetMin] = useState<number | ''>(5000000000);
  const [budgetMax, setBudgetMax] = useState<number | ''>(12000000000);
  const [mortgageMax, setMortgageMax] = useState<number | ''>(800000000);
  const [rentMax, setRentMax] = useState<number | ''>(25000000);
  const [notes, setNotes] = useState('');

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (initialCustomer) {
      setFullName(initialCustomer.fullName || '');
      setPhone(initialCustomer.phone || '');
      setEmail(initialCustomer.email || '');
      setCustomerType(initialCustomer.customerType || 'buyer');
      setDealType(initialCustomer.dealType || 'buy');
      setStatus(initialCustomer.status || 'active');
      setPreferredPropertyTypes(initialCustomer.preferredPropertyTypes || ['apartment']);
      setMinArea(initialCustomer.minArea !== undefined ? initialCustomer.minArea : '');
      setMaxArea(initialCustomer.maxArea !== undefined ? initialCustomer.maxArea : '');
      setMinRooms(initialCustomer.minRooms !== undefined ? initialCustomer.minRooms : '');
      setPreferredDistricts(initialCustomer.preferredDistricts || []);
      setBudgetMin(initialCustomer.budgetMin !== undefined ? initialCustomer.budgetMin : '');
      setBudgetMax(initialCustomer.budgetMax !== undefined ? initialCustomer.budgetMax : '');
      setMortgageMax(initialCustomer.mortgageMax !== undefined ? initialCustomer.mortgageMax : '');
      setRentMax(initialCustomer.rentMax !== undefined ? initialCustomer.rentMax : '');
      setNotes(initialCustomer.notes || '');
    } else {
      setFullName('');
      setPhone('');
      setEmail('');
      setNotes('');
      setCustomerType('buyer');
      setDealType('buy');
      setStatus('active');
      setPreferredDistricts(['سعادت‌آباد']);
      setBudgetMin(5000000000);
      setBudgetMax(12000000000);
      setMortgageMax(600000000);
      setRentMax(20000000);
    }
    setErrors({});
    setActiveTab('personal');
  }, [initialCustomer, isOpen]);

  if (!isOpen) return null;

  const handleAddDistrict = () => {
    const val = newDistrictInput.trim();
    if (val && !preferredDistricts.includes(val)) {
      setPreferredDistricts([...preferredDistricts, val]);
      setNewDistrictInput('');
    }
  };

  const handleRemoveDistrict = (dist: string) => {
    setPreferredDistricts(preferredDistricts.filter(d => d !== dist));
  };

  const togglePropertyType = (type: PropertyType) => {
    if (preferredPropertyTypes.includes(type)) {
      if (preferredPropertyTypes.length > 1) {
        setPreferredPropertyTypes(preferredPropertyTypes.filter(t => t !== type));
      }
    } else {
      setPreferredPropertyTypes([...preferredPropertyTypes, type]);
    }
  };

  const validate = (): boolean => {
    const errs: Record<string, string> = {};

    if (!fullName.trim()) {
      errs.fullName = 'نام و نام خانوادگی مشتری الزامی است.';
    }

    if (!phone.trim()) {
      errs.phone = 'شماره تلفن مشتری الزامی است.';
    } else if (!/^09\d{9}$/.test(phone.trim())) {
      errs.phone = 'شماره تلفن باید ۱۱ رقم و با ۰۹ شروع شود.';
    }

    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      errs.email = 'فرمت ایمیل نامعتبر است.';
    }

    setErrors(errs);
    if (Object.keys(errs).length > 0) {
      setActiveTab('personal');
      showToast('لطفاً فیلدهای الزامی را تصحیح فرمایید.', 'error');
      return false;
    }
    return true;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const payload = {
      fullName: fullName.trim(),
      phone: phone.trim(),
      email: email.trim(),
      customerType,
      dealType,
      status,
      preferredPropertyTypes,
      minArea: minArea !== '' ? Number(minArea) : undefined,
      maxArea: maxArea !== '' ? Number(maxArea) : undefined,
      minRooms: minRooms !== '' ? Number(minRooms) : undefined,
      preferredDistricts,
      budgetMin: budgetMin !== '' ? Number(budgetMin) : undefined,
      budgetMax: budgetMax !== '' ? Number(budgetMax) : undefined,
      mortgageMax: mortgageMax !== '' ? Number(mortgageMax) : undefined,
      rentMax: rentMax !== '' ? Number(rentMax) : undefined,
      notes: notes.trim()
    };

    onSave(payload);
    showToast(initialCustomer ? 'پرونده مشتری به‌روزرسانی شد.' : 'متقاضی جدید در CRM ثبت گردید.', 'success');
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 lg:p-6 overflow-y-auto animate-in fade-in"
      dir="rtl"
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 animate-in zoom-in-95"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                {initialCustomer ? 'ویرایش پرونده مشتری' : 'ثبت متقاضی جدید در سامانه'}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">مشخصات تماس، نیازها و توان پرداخت مالی</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="بستن"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Headers */}
        <div className="flex items-center gap-1 px-6 pt-3 pb-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          {[
            { id: 'personal', label: 'مشخصات تماس و نوع تقاضا' },
            { id: 'preferences', label: 'ترجیحات ملکی و بودجه' },
            { id: 'notes', label: 'یادداشت‌های مذاکره' }
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {tab.label}
              {tab.id === 'personal' && (errors.fullName || errors.phone) && (
                <span className="w-2 h-2 rounded-full bg-red-400 mr-1.5 inline-block" />
              )}
            </button>
          ))}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-right">
          {activeTab === 'personal' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    نام و نام خانوادگی <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => {
                      setFullName(e.target.value);
                      if (errors.fullName) setErrors({ ...errors, fullName: '' });
                    }}
                    placeholder="مثلا: دکتر فرشید کاظمی"
                    className={`w-full px-3.5 py-2.5 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border focus:outline-none ${
                      errors.fullName ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 dark:border-slate-700 focus:border-blue-500'
                    }`}
                  />
                  {errors.fullName && (
                    <p className="text-[11px] text-red-500 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      <span>{errors.fullName}</span>
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    شماره تلفن همراه <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                      if (errors.phone) setErrors({ ...errors, phone: '' });
                    }}
                    placeholder="09121234567"
                    className={`w-full px-3.5 py-2.5 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border font-mono text-left focus:outline-none ${
                      errors.phone ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 dark:border-slate-700 focus:border-blue-500'
                    }`}
                    dir="ltr"
                  />
                  {errors.phone && (
                    <p className="text-[11px] text-red-500 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      <span>{errors.phone}</span>
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    نقش مشتری
                  </label>
                  <select
                    value={customerType}
                    onChange={(e) => setCustomerType(e.target.value as CustomerType)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                  >
                    <option value="buyer">خریدار ملکی</option>
                    <option value="tenant">مستاجر</option>
                    <option value="seller">فروشنده (مالک)</option>
                    <option value="landlord">موجر (صاحبخانه)</option>
                    <option value="investor">سرمایه‌گذار</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    هدف معامله
                  </label>
                  <select
                    value={dealType}
                    onChange={(e) => setDealType(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-bold text-blue-600 dark:text-blue-400"
                  >
                    <option value="buy">خرید ملک</option>
                    <option value="rent">اجاره و رهن</option>
                    <option value="sell">فروش فایل</option>
                    <option value="let">واگذاری اجاره</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    وضعیت در CRM
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as CustomerStatus)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                  >
                    <option value="active">فعال و در حال جستجو</option>
                    <option value="in_progress">در حال مذاکره و بازدید</option>
                    <option value="deal_closed">معامله با موفقیت انجام شد</option>
                    <option value="cancelled">انصراف از خرید/اجاره</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  آدرس ایمیل (اختیاری)
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-left focus:outline-none"
                  dir="ltr"
                />
              </div>
            </div>
          )}

          {activeTab === 'preferences' && (
            <div className="space-y-4 animate-in fade-in">
              {/* Preferred property types */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  نوع ملک‌های مورد نظر:
                </label>
                <div className="flex flex-wrap gap-2">
                  {[
                    { id: 'apartment', label: 'آپارتمان' },
                    { id: 'villa', label: 'ویلا' },
                    { id: 'penthouse', label: 'پنت‌هاوس' },
                    { id: 'commercial', label: 'تجاری / مغازه' },
                    { id: 'office', label: 'اداری' },
                    { id: 'land', label: 'زمین / کلنگی' }
                  ].map(t => {
                    const isSelected = preferredPropertyTypes.includes(t.id as PropertyType);
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => togglePropertyType(t.id as PropertyType)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                          isSelected
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                        }`}
                      >
                        {t.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Districts */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  مناطق و محله‌های مورد نظر:
                </label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={newDistrictInput}
                    onChange={(e) => setNewDistrictInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddDistrict();
                      }
                    }}
                    placeholder="افزودن محله (مثلا: سعادت‌آباد، شهرک غرب)..."
                    className="flex-1 px-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleAddDistrict}
                    className="px-4 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold hover:bg-slate-300 transition-colors"
                  >
                    افزودن
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {preferredDistricts.map(dist => (
                    <span
                      key={dist}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 text-xs border border-blue-200 dark:border-blue-800"
                    >
                      <span>{dist}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveDistrict(dist)}
                        className="text-blue-500 hover:text-red-500 font-bold"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* Specs: Area & Rooms */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    حداقل متراژ (متر)
                  </label>
                  <input
                    type="number"
                    value={minArea}
                    onChange={(e) => setMinArea(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    حداکثر متراژ (متر)
                  </label>
                  <input
                    type="number"
                    value={maxArea}
                    onChange={(e) => setMaxArea(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    حداقل خواب
                  </label>
                  <input
                    type="number"
                    value={minRooms}
                    onChange={(e) => setMinRooms(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                  />
                </div>
              </div>

              {/* Budget Details */}
              {dealType === 'buy' || dealType === 'sell' ? (
                <div className="p-3.5 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/50 space-y-3">
                  <div className="text-xs font-bold text-emerald-900 dark:text-emerald-300">
                    بودجه خرید متقاضی (تومان)
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] text-slate-500 mb-1">حداقل بودجه</label>
                      <input
                        type="number"
                        value={budgetMin}
                        onChange={(e) => setBudgetMin(e.target.value === '' ? '' : Number(e.target.value))}
                        step="100000000"
                        className="w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-800 border border-emerald-200 dark:border-emerald-800 focus:outline-none font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-500 mb-1">حداکثر سقف بودجه</label>
                      <input
                        type="number"
                        value={budgetMax}
                        onChange={(e) => setBudgetMax(e.target.value === '' ? '' : Number(e.target.value))}
                        step="100000000"
                        className="w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-800 border border-emerald-200 dark:border-emerald-800 focus:outline-none font-bold"
                      />
                    </div>
                  </div>
                  {budgetMax !== '' && Number(budgetMax) > 0 && (
                    <div className="text-[11px] text-emerald-800 dark:text-emerald-300">
                      سقف بودجه: {formatToman(Number(budgetMax))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-3.5 rounded-2xl bg-teal-50/70 dark:bg-teal-950/20 border border-teal-200 dark:border-teal-900/50 space-y-3">
                  <div className="text-xs font-bold text-teal-900 dark:text-teal-300">
                    سقف ودیعه و اجاره متقاضی (تومان)
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] text-slate-500 mb-1">حداکثر ودیعه (رهن)</label>
                      <input
                        type="number"
                        value={mortgageMax}
                        onChange={(e) => setMortgageMax(e.target.value === '' ? '' : Number(e.target.value))}
                        step="50000000"
                        className="w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-800 border border-teal-200 dark:border-teal-800 focus:outline-none font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-500 mb-1">حداکثر اجاره ماهانه</label>
                      <input
                        type="number"
                        value={rentMax}
                        onChange={(e) => setRentMax(e.target.value === '' ? '' : Number(e.target.value))}
                        step="1000000"
                        className="w-full px-3 py-1.5 text-xs rounded-xl bg-white dark:bg-slate-800 border border-teal-200 dark:border-teal-800 focus:outline-none font-bold"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'notes' && (
            <div className="space-y-3 animate-in fade-in">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                یادداشت‌های پرونده و توضیحات مذاکره
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={5}
                placeholder="دلایل جابجایی، فوریت تصمیم‌گیری، شرایط نقدینگی، اولویت‌های خاص همسر یا فرزندان..."
                className="w-full px-3 py-2 text-xs lg:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none leading-relaxed"
              />
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              انصراف
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-md shadow-blue-600/20 transition-all active:scale-95"
            >
              {initialCustomer ? 'ذخیره تغییرات پرونده' : 'ثبت قطعی متقاضی'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
