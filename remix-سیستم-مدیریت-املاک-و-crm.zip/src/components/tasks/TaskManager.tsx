import React, { useState, useMemo } from 'react';
import {
  CheckSquare,
  Plus,
  Calendar,
  Clock,
  CheckCircle2,
  Trash2,
  User,
  Phone,
  Search,
  X,
  AlertCircle
} from 'lucide-react';
import { FollowUp, Customer } from '../../types';
import { formatPersianDate, toPersianDigits } from '../../utils/formatters';
import { EmptyState } from '../common/EmptyState';
import { ConfirmModal } from '../common/ConfirmModal';
import { useToast } from '../../context/ToastContext';

interface TaskManagerProps {
  tasks: FollowUp[];
  customers: Customer[];
  onToggleTask: (id: string) => void;
  onAddTask: (task: Omit<FollowUp, 'id' | 'createdAt'>) => void;
  onDeleteTask: (id: string) => void;
  onSelectCustomer?: (customer: Customer) => void;
}

export const TaskManager: React.FC<TaskManagerProps> = ({
  tasks,
  customers,
  onToggleTask,
  onAddTask,
  onDeleteTask,
  onSelectCustomer
}) => {
  const { showToast } = useToast();
  const [filterTab, setFilterTab] = useState<'today' | 'upcoming' | 'overdue' | 'completed' | 'all'>('today');
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [deletingTaskId, setDeletingTaskId] = useState<string | null>(null);

  // New task form state
  const [title, setTitle] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [dueDate, setDueDate] = useState(new Date().toISOString().split('T')[0]);
  const [dueTime, setDueTime] = useState('12:00');
  const [priority, setPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [notes, setNotes] = useState('');

  const todayStr = new Date().toISOString().split('T')[0];

  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      // Search
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchTitle = t.title.toLowerCase().includes(q);
        const matchCust = t.customerName?.toLowerCase().includes(q);
        if (!matchTitle && !matchCust) return false;
      }

      if (filterTab === 'completed') {
        return t.status === 'completed';
      }

      if (t.status === 'completed' && filterTab !== 'all') {
        return false;
      }

      if (filterTab === 'today') {
        return t.dueDate === todayStr;
      }
      if (filterTab === 'upcoming') {
        return t.dueDate > todayStr;
      }
      if (filterTab === 'overdue') {
        return t.dueDate < todayStr;
      }

      return true;
    }).sort((a, b) => {
      if (a.dueDate !== b.dueDate) {
        return a.dueDate.localeCompare(b.dueDate);
      }
      return (a.dueTime || '').localeCompare(b.dueTime || '');
    });
  }, [tasks, filterTab, searchQuery, todayStr]);

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast('لطفاً عنوان پیگیری را وارد فرمایید.', 'error');
      return;
    }

    const matchedCustomer = customers.find(c => c.id === selectedCustomerId);

    onAddTask({
      title: title.trim(),
      customerId: selectedCustomerId || undefined,
      customerName: matchedCustomer?.fullName,
      dueDate,
      dueTime,
      priority,
      status: 'pending',
      notes: notes.trim()
    });

    setTitle('');
    setSelectedCustomerId('');
    setNotes('');
    setShowAddModal(false);
    showToast('وظیفه پیگیری جدید در تقویم ثبت شد.', 'success');
  };

  const handleToggle = (id: string, currentlyDone: boolean) => {
    onToggleTask(id);
    showToast(currentlyDone ? 'وظیفه به حالت در انتظار تغییر یافت.' : 'وظیفه به عنوان انجام شده علامت خورد.', 'info');
  };

  const confirmDelete = () => {
    if (deletingTaskId) {
      onDeleteTask(deletingTaskId);
      setDeletingTaskId(null);
      showToast('وظیفه پیگیری حذف شد.', 'info');
    }
  };

  // Counts for tabs
  const todayCount = tasks.filter(t => t.dueDate === todayStr && t.status !== 'completed').length;
  const overdueCount = tasks.filter(t => t.dueDate < todayStr && t.status !== 'completed').length;
  const upcomingCount = tasks.filter(t => t.dueDate > todayStr && t.status !== 'completed').length;
  const completedCount = tasks.filter(t => t.status === 'completed').length;

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-200 text-right">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 lg:p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg lg:text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-emerald-600" />
            <span>مدیریت وظایف و پیگیری‌های مشاور</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            برنامه‌ریزی بازدیدها، تماس‌های دوره‌ای با مالکین و پیگیری درخواست‌های متقاضیان
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs lg:text-sm font-bold shadow-md shadow-emerald-600/20 transition-all active:scale-95 self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>ثبت پیگیری جدید</span>
        </button>
      </div>

      {/* Tabs & Search Filter */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Quick tab switcher */}
          <div className="flex items-center gap-1 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700 overflow-x-auto">
            {[
              { id: 'today', label: 'امروز', count: todayCount, badgeColor: 'bg-emerald-500 text-white' },
              { id: 'overdue', label: 'معوقه', count: overdueCount, badgeColor: 'bg-red-500 text-white' },
              { id: 'upcoming', label: 'آینده', count: upcomingCount, badgeColor: 'bg-blue-500 text-white' },
              { id: 'completed', label: 'انجام شده', count: completedCount, badgeColor: 'bg-slate-400 text-white' },
              { id: 'all', label: 'همه', count: tasks.length, badgeColor: 'bg-slate-300 dark:bg-slate-600 text-slate-800 dark:text-white' },
            ].map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilterTab(tab.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 transition-all ${
                  filterTab === tab.id
                    ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>{tab.label}</span>
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${tab.badgeColor}`}>
                  {toPersianDigits(tab.count)}
                </span>
              </button>
            ))}
          </div>

          <div className="relative sm:w-64">
            <Search className="w-3.5 h-3.5 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجو در وظایف یا مشتریان..."
              className="w-full pr-8 pl-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Task List */}
      {filteredTasks.length === 0 ? (
        <EmptyState
          icon={CheckCircle2}
          title="هیچ پیگیری در این بخش وجود ندارد"
          description="تمامی موارد بررسی شده‌اند یا هنوز وظیفه‌ای برای این بازه ثبت نشده است."
          actionText="ثبت پیگیری جدید"
          onAction={() => setShowAddModal(true)}
        />
      ) : (
        <div className="space-y-2.5">
          {filteredTasks.map((task) => {
            const isDone = task.status === 'completed';
            const matchedCustomer = customers.find(c => c.id === task.customerId);

            return (
              <div
                key={task.id}
                className={`p-4 rounded-3xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  isDone
                    ? 'bg-slate-50/70 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-65'
                    : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:shadow-md'
                }`}
              >
                <div className="flex items-start gap-3">
                  <button
                    type="button"
                    onClick={() => handleToggle(task.id, isDone)}
                    className={`mt-0.5 w-6 h-6 rounded-lg flex items-center justify-center border transition-all ${
                      isDone
                        ? 'bg-emerald-600 border-emerald-600 text-white'
                        : 'border-slate-300 dark:border-slate-600 hover:border-emerald-500'
                    }`}
                    aria-label={isDone ? 'علامت به عنوان انجام نشده' : 'علامت به عنوان انجام شده'}
                  >
                    {isDone && <CheckCircle2 className="w-4 h-4" />}
                  </button>

                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className={`text-sm font-bold ${isDone ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                        {task.title}
                      </h4>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        task.priority === 'high'
                          ? 'bg-red-100 text-red-700 dark:bg-red-950/60 dark:text-red-300'
                          : task.priority === 'medium'
                          ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                          : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                      }`}>
                        {task.priority === 'high' ? 'فوری' : task.priority === 'medium' ? 'متوسط' : 'عادی'}
                      </span>
                    </div>

                    {/* Metadata chips */}
                    <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-500 dark:text-slate-400 mt-1.5">
                      <span className="flex items-center gap-1 font-mono">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>{formatPersianDate(task.dueDate)}</span>
                      </span>

                      {task.dueTime && (
                        <span className="flex items-center gap-1 font-mono">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>ساعت {task.dueTime}</span>
                        </span>
                      )}

                      {task.customerName && (
                        <button
                          type="button"
                          onClick={() => matchedCustomer && onSelectCustomer && onSelectCustomer(matchedCustomer)}
                          className="flex items-center gap-1 font-medium text-blue-600 dark:text-blue-400 hover:underline"
                        >
                          <User className="w-3.5 h-3.5" />
                          <span>{task.customerName}</span>
                        </button>
                      )}
                    </div>

                    {task.notes && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        {task.notes}
                      </p>
                    )}
                  </div>
                </div>

                {/* Quick actions */}
                <div className="flex items-center gap-2 self-end sm:self-auto">
                  {matchedCustomer?.phone && (
                    <a
                      href={`tel:${matchedCustomer.phone}`}
                      className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 hover:bg-emerald-100 transition-colors"
                      title="تماس فوری با مشتری"
                    >
                      <Phone className="w-4 h-4" />
                    </a>
                  )}

                  <button
                    type="button"
                    onClick={() => setDeletingTaskId(task.id)}
                    className="p-2 rounded-xl text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                    title="حذف وظیفه"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Task Modal */}
      {showAddModal && (
        <div 
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto animate-in fade-in"
          role="dialog"
          aria-modal="true"
        >
          <div 
            className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-lg p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 animate-in zoom-in-95"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-600" />
                <span>ثبت پیگیری و وظیفه جدید</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  عنوان کار یا پیگیری <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="مثلا: هماهنگی ساعت بازدید با آقای محمدی"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  مشتری یا متقاضی مرتبط (اختیاری)
                </label>
                <select
                  value={selectedCustomerId}
                  onChange={(e) => setSelectedCustomerId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                >
                  <option value="">بدون انتخاب مشتری (پیگیری عمومی)</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.fullName} ({c.phone})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    تاریخ پیگیری
                  </label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    ساعت پیگیری
                  </label>
                  <input
                    type="time"
                    value={dueTime}
                    onChange={(e) => setDueTime(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  اولویت کار
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                >
                  <option value="high">فوری و مهم</option>
                  <option value="medium">متوسط</option>
                  <option value="low">عادی</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  یادداشت و نکات کلیدی
                </label>
                <textarea
                  rows={2}
                  placeholder="جزئیات مذاکره یا کلیدهای ملک..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition-all active:scale-95"
                >
                  ذخیره پیگیری
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmModal
        isOpen={Boolean(deletingTaskId)}
        title="حذف وظیفه پیگیری"
        description="آیا از حذف این وظیفه کاری اطمینان دارید؟"
        confirmLabel="بله، حذف شود"
        cancelLabel="انصراف"
        isDanger={true}
        onConfirm={confirmDelete}
        onCancel={() => setDeletingTaskId(null)}
      />
    </div>
  );
};
