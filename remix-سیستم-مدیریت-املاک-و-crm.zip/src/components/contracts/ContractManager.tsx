import React, { useState } from 'react';
import { 
  FileText, 
  Plus, 
  DollarSign, 
  Calendar, 
  UserCheck, 
  CheckCircle, 
  Clock, 
  Download, 
  Filter, 
  Search,
  Building,
  TrendingUp,
  Percent,
  Receipt
} from 'lucide-react';
import { Contract, FinancialTransaction, Property, Customer } from '../../types';
import { toPersianDigits, formatCurrency } from '../../utils/formatters';

interface ContractManagerProps {
  contracts: Contract[];
  transactions: FinancialTransaction[];
  properties: Property[];
  customers: Customer[];
  onAddContract: (contract: Partial<Contract>) => Promise<void>;
  onAddTransaction: (trans: Partial<FinancialTransaction>) => Promise<void>;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const ContractManager: React.FC<ContractManagerProps> = ({
  contracts,
  transactions,
  properties,
  customers,
  onAddContract,
  onAddTransaction,
  showToast
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'contracts' | 'finances'>('contracts');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDealType, setFilterDealType] = useState<string>('all');
  const [isNewContractOpen, setIsNewContractOpen] = useState(false);
  const [isNewExpenseOpen, setIsNewExpenseOpen] = useState(false);

  // Form states for new contract
  const [newDealType, setNewDealType] = useState<'sale' | 'rent' | 'presale'>('sale');
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [totalAmount, setTotalAmount] = useState<number>(0);
  const [mortgageAmount, setMortgageAmount] = useState<number>(0);
  const [rentAmount, setRentAmount] = useState<number>(0);
  const [commissionTotal, setCommissionTotal] = useState<number>(0);
  const [agentSharePercent, setAgentSharePercent] = useState<number>(40);
  const [agentName, setAgentName] = useState('');
  const [contractNotes, setContractNotes] = useState('');

  // Form state for new expense
  const [expenseTitle, setExpenseTitle] = useState('');
  const [expenseCategory, setExpenseCategory] = useState('utility');
  const [expenseAmount, setExpenseAmount] = useState<number>(0);
  const [expenseDesc, setExpenseDesc] = useState('');

  // Calculations
  const filteredContracts = contracts.filter((c) => {
    const matchesSearch = 
      c.contract_number.includes(searchQuery) ||
      c.client_name.includes(searchQuery) ||
      c.owner_name.includes(searchQuery);
    const matchesType = filterDealType === 'all' || c.deal_type === filterDealType;
    return matchesSearch && matchesType;
  });

  const totalContractVolume = contracts.reduce((sum, c) => sum + (c.total_amount || 0), 0);
  const totalCommissionRevenue = contracts.reduce((sum, c) => sum + (c.commission_total || 0), 0);
  const totalExpenses = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + (t.amount || 0), 0);
  const netAgencyProfit = totalCommissionRevenue - totalExpenses;

  const handleCreateContractSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ownerName || !clientName) {
      showToast('لطفاً مشخصات مالک و مشتری را تکمیل نمایید.', 'error');
      return;
    }

    const agencyShare = Math.round(commissionTotal * ((100 - agentSharePercent) / 100));
    const agentShare = Math.round(commissionTotal * (agentSharePercent / 100));

    try {
      await onAddContract({
        deal_type: newDealType,
        owner_name: ownerName,
        owner_phone: ownerPhone,
        client_name: clientName,
        client_phone: clientPhone,
        total_amount: totalAmount,
        mortgage_amount: mortgageAmount,
        rent_amount: rentAmount,
        commission_total: commissionTotal,
        agency_share: agencyShare,
        agent_share: agentShare,
        agent_name: agentName || 'مشاور معامله',
        tax_amount: Math.round(commissionTotal * 0.1),
        payment_status: 'paid',
        status: 'completed',
        notes: contractNotes
      });

      setIsNewContractOpen(false);
      // Reset
      setOwnerName('');
      setClientName('');
      setTotalAmount(0);
      setCommissionTotal(0);
      setContractNotes('');
      showToast('قرارداد جدید و کمیسیون مربوطه با موفقیت ثبت گردید.', 'success');
    } catch (err: any) {
      showToast(err.message || 'خطا در ثبت قرارداد', 'error');
    }
  };

  const handleCreateExpenseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseTitle || expenseAmount <= 0) {
      showToast('عنوان و مبلغ هزینه را به درستی وارد نمایید.', 'error');
      return;
    }

    try {
      await onAddTransaction({
        type: 'expense',
        category: expenseCategory,
        title: expenseTitle,
        amount: expenseAmount,
        payment_method: 'bank_transfer',
        date: new Date().toISOString().split('T')[0],
        description: expenseDesc
      });

      setIsNewExpenseOpen(false);
      setExpenseTitle('');
      setExpenseAmount(0);
      setExpenseDesc('');
      showToast('هزینه جدید با موفقیت در سیستم مالی ثبت شد.', 'success');
    } catch (err: any) {
      showToast(err.message || 'خطا در ثبت هزینه', 'error');
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in" dir="rtl">
      {/* Top Header & Metrics */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Receipt className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
            قراردادها و سیستم مالی آژانس
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            مدیریت اسناد معاملات رسمی، کمیسیون‌های دریافتی، سهم مشاورین و گزارش سود خالص
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsNewExpenseOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 transition-colors"
          >
            <DollarSign className="w-4 h-4 text-red-500" />
            ثبت هزینه دفتر
          </button>
          <button
            onClick={() => setIsNewContractOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            ثبت قرارداد جدید
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">تعداد کل قراردادها</span>
            <FileText className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900 dark:text-white">
            {toPersianDigits(contracts.length)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">ثبت‌شده در این آژانس</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">کل کمیسیون ناخالص</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-2 text-xl font-black text-emerald-600 dark:text-emerald-400">
            {formatCurrency(totalCommissionRevenue)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">مجموع دریافتی از معاملات</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">هزینه‌ها و پورسانت‌ها</span>
            <DollarSign className="w-4 h-4 text-red-500" />
          </div>
          <div className="mt-2 text-xl font-black text-red-600 dark:text-red-400">
            {formatCurrency(totalExpenses)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">پورسانت مشاور + هزینه‌های جاری</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">سود خالص آژانس</span>
            <CheckCircle className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="mt-2 text-xl font-black text-indigo-600 dark:text-indigo-400">
            {formatCurrency(netAgencyProfit)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">تراز مالی بعد از کسر سهم مشاوران</div>
        </div>
      </div>

      {/* Sub Tabs: Contracts vs Financial Journal */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        <button
          onClick={() => setActiveSubTab('contracts')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
            activeSubTab === 'contracts'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          فهرست قراردادهای رسمی ({toPersianDigits(contracts.length)})
        </button>
        <button
          onClick={() => setActiveSubTab('finances')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
            activeSubTab === 'finances'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          دفتر روزنامه و تراکنش‌ها ({toPersianDigits(transactions.length)})
        </button>
      </div>

      {/* Contracts Tab View */}
      {activeSubTab === 'contracts' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="جستجو با شماره قرارداد، مالک یا مشتری..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-3 pr-9 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Filter className="w-4 h-4 text-slate-400" />
              <select
                value={filterDealType}
                onChange={(e) => setFilterDealType(e.target.value)}
                className="px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none"
              >
                <option value="all">همه قراردادها</option>
                <option value="sale">فروش قطعی</option>
                <option value="rent">رهن و اجاره</option>
                <option value="presale">پیش‌فروش</option>
              </select>
            </div>
          </div>

          {filteredContracts.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
              <FileText className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300">قراردادی با این مشخصات یافت نشد.</p>
              <p className="text-xs text-slate-400 mt-1">از دکمه «ثبت قرارداد جدید» برای ثبت مبایعه‌نامه یا اجاره‌نامه استفاده کنید.</p>
            </div>
          ) : (
            <div className="overflow-x-auto bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-500 font-bold">
                    <th className="p-3.5">شماره قرارداد</th>
                    <th className="p-3.5">نوع معامله</th>
                    <th className="p-3.5">طرفین معامله (مالک / متقاضی)</th>
                    <th className="p-3.5">مبلغ کل معامله</th>
                    <th className="p-3.5">کمیسیون کل</th>
                    <th className="p-3.5">سهم آژانس / مشاور</th>
                    <th className="p-3.5">تاریخ عقد</th>
                    <th className="p-3.5">وضعیت</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredContracts.map((c) => (
                    <tr key={c.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="p-3.5 font-mono font-bold text-slate-900 dark:text-white">
                        {c.contract_number}
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2.5 py-1 rounded-lg text-[11px] font-bold ${
                          c.deal_type === 'sale'
                            ? 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                            : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                        }`}>
                          {c.deal_type === 'sale' ? 'فروش' : c.deal_type === 'rent' ? 'رهن و اجاره' : 'پیش‌فروش'}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <div className="font-bold text-slate-800 dark:text-slate-200">{c.client_name}</div>
                        <div className="text-[11px] text-slate-400">مالک: {c.owner_name}</div>
                      </td>
                      <td className="p-3.5 font-bold text-slate-900 dark:text-white">
                        {c.total_amount ? formatCurrency(c.total_amount) : `${formatCurrency(c.mortgage_amount || 0)} رهن`}
                      </td>
                      <td className="p-3.5 font-bold text-emerald-600 dark:text-emerald-400">
                        {formatCurrency(c.commission_total)}
                      </td>
                      <td className="p-3.5 text-[11px]">
                        <div>دفتر: <span className="font-bold text-slate-700 dark:text-slate-300">{formatCurrency(c.agency_share)}</span></div>
                        <div className="text-slate-400">مشاور ({c.agent_name || 'مشاور'}): {formatCurrency(c.agent_share)}</div>
                      </td>
                      <td className="p-3.5 text-slate-500 font-mono">
                        {toPersianDigits(c.contract_date)}
                      </td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                          تسویه شده
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Financial Transactions Journal */}
      {activeSubTab === 'finances' && (
        <div className="overflow-x-auto bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-500 font-bold">
                <th className="p-3.5">نوع تراکنش</th>
                <th className="p-3.5">سرفصل / عنوان</th>
                <th className="p-3.5">مبلغ (تومان)</th>
                <th className="p-3.5">روش پرداخت</th>
                <th className="p-3.5">طرف حساب / مشاور</th>
                <th className="p-3.5">تاریخ</th>
                <th className="p-3.5">توضیحات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {transactions.map((t) => (
                <tr key={t.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                  <td className="p-3.5">
                    <span className={`px-2.5 py-1 rounded-lg text-[11px] font-bold ${
                      t.type === 'income'
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300'
                    }`}>
                      {t.type === 'income' ? 'دریافت (درآمد)' : 'پرداخت (هزینه)'}
                    </span>
                  </td>
                  <td className="p-3.5 font-bold text-slate-800 dark:text-slate-200">{t.title}</td>
                  <td className={`p-3.5 font-extrabold ${t.type === 'income' ? 'text-emerald-600' : 'text-red-600'}`}>
                    {t.type === 'income' ? '+' : '-'}{formatCurrency(t.amount)}
                  </td>
                  <td className="p-3.5 text-slate-500">{t.payment_method === 'bank_transfer' ? 'انتقال بانکی/شبا' : 'کارتخوان'}</td>
                  <td className="p-3.5 text-slate-700 dark:text-slate-300">{t.agent_name || 'دفتر مرکزی'}</td>
                  <td className="p-3.5 font-mono text-slate-500">{toPersianDigits(t.date)}</td>
                  <td className="p-3.5 text-slate-400 text-[11px] max-w-xs truncate">{t.description || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal: New Contract */}
      {isNewContractOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="text-base font-black text-slate-900 dark:text-white mb-4">
              ثبت قرارداد رسمی و تنظیم کمیسیون
            </h3>
            <form onSubmit={handleCreateContractSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">نوع معامله</label>
                  <select
                    value={newDealType}
                    onChange={(e: any) => setNewDealType(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  >
                    <option value="sale">فروش قطعی</option>
                    <option value="rent">رهن و اجاره</option>
                    <option value="presale">پیش‌فروش</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">مشاور مسئول معامله</label>
                  <input
                    type="text"
                    placeholder="مثال: علی رضایی"
                    value={agentName}
                    onChange={(e) => setAgentName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">نام و شماره مالک</label>
                  <input
                    type="text"
                    required
                    placeholder="نام مالک"
                    value={ownerName}
                    onChange={(e) => setOwnerName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 mb-2"
                  />
                  <input
                    type="text"
                    placeholder="شماره تماس مالک"
                    value={ownerPhone}
                    onChange={(e) => setOwnerPhone(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">نام و شماره خریدار/مستاجر</label>
                  <input
                    type="text"
                    required
                    placeholder="نام مشتری"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 mb-2"
                  />
                  <input
                    type="text"
                    placeholder="شماره تماس متقاضی"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              {/* Financial values */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-200 dark:border-slate-800">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">ارزش کل معامله (تومان)</label>
                  <input
                    type="number"
                    value={totalAmount || ''}
                    onChange={(e) => setTotalAmount(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">کل کمیسیون توافقی (تومان)</label>
                  <input
                    type="number"
                    required
                    value={commissionTotal || ''}
                    onChange={(e) => setCommissionTotal(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">درصد سهم مشاور (%)</label>
                  <input
                    type="number"
                    value={agentSharePercent}
                    onChange={(e) => setAgentSharePercent(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">توضیحات و شروط قرارداد</label>
                <textarea
                  rows={3}
                  value={contractNotes}
                  onChange={(e) => setContractNotes(e.target.value)}
                  placeholder="نحوه پرداخت ثمن، تاریخ تحویل، چک‌ها و..."
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewContractOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 font-bold"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                >
                  ثبت قطعی قرارداد و کمیسیون
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: New Expense */}
      {isNewExpenseOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-md p-6 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <h3 className="text-base font-black text-slate-900 dark:text-white mb-4">
              ثبت هزینه و مخارج آژانس
            </h3>
            <form onSubmit={handleCreateExpenseSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">عنوان هزینه</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: هزینه قبض برق، اجاره ماهانه، اینترنت..."
                  value={expenseTitle}
                  onChange={(e) => setExpenseTitle(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">دسته‌بندی</label>
                <select
                  value={expenseCategory}
                  onChange={(e) => setExpenseCategory(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                >
                  <option value="utility">قبوض و هزینه‌های جاری</option>
                  <option value="office_rent">اجاره دفتر</option>
                  <option value="marketing">تبلیغات و دیوار / شیپور</option>
                  <option value="salary">حقوق و مساعده پرسنل</option>
                  <option value="tax">مالیات و عوارض</option>
                  <option value="other">سایر مخارج</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">مبلغ هزینه (تومان)</label>
                <input
                  type="number"
                  required
                  value={expenseAmount || ''}
                  onChange={(e) => setExpenseAmount(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">توضیحات</label>
                <textarea
                  rows={2}
                  value={expenseDesc}
                  onChange={(e) => setExpenseDesc(e.target.value)}
                  placeholder="شماره پیگیری فاکتور یا جزئیات..."
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewExpenseOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 font-bold"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold"
                >
                  ثبت پرداخت در دفاتر
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
