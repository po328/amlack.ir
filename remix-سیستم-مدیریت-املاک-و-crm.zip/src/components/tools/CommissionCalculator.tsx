import React, { useState } from 'react';
import {
  Calculator,
  Percent,
  Receipt,
  Copy,
  Check,
  ShieldCheck,
  HelpCircle,
  Building,
  KeyRound
} from 'lucide-react';
import {
  calculateSaleCommission,
  calculateRentCommission,
  formatToman,
  numberToPersianWords,
  toPersianDigits
} from '../../utils/formatters';

interface CommissionCalculatorProps {
  initialDealType?: 'sale' | 'rent';
  initialAmount?: number;
  initialMortgage?: number;
  initialRent?: number;
}

export const CommissionCalculator: React.FC<CommissionCalculatorProps> = ({
  initialDealType = 'sale',
  initialAmount = 8500000000,
  initialMortgage = 500000000,
  initialRent = 15000000
}) => {
  const [dealType, setDealType] = useState<'sale' | 'rent'>(initialDealType);

  // Sale inputs
  const [salePrice, setSalePrice] = useState<number>(initialAmount || 8500000000);
  const [saleRatePercent, setSaleRatePercent] = useState<number>(0.25); // 0.25% per party

  // Rent inputs
  const [mortgagePrice, setMortgagePrice] = useState<number>(initialMortgage);
  const [rentPrice, setRentPrice] = useState<number>(initialRent);

  // Tax percent
  const [taxPercent, setTaxPercent] = useState<number>(10); // 10% VAT
  const [includeTax, setIncludeTax] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);

  // Results
  const saleResult = calculateSaleCommission(salePrice, saleRatePercent, saleRatePercent, includeTax ? taxPercent : 0);
  const rentResult = calculateRentCommission(mortgagePrice, rentPrice, 3.0, 7.5, includeTax ? taxPercent : 0);

  const firstPartyFee = dealType === 'sale' ? saleResult.buyerFee : rentResult.tenantFee;
  const secondPartyFee = dealType === 'sale' ? saleResult.sellerFee : rentResult.landlordFee;
  const vatPerParty = includeTax ? Math.round(firstPartyFee * (taxPercent / 100)) : 0;
  const firstPartyWithTax = firstPartyFee + vatPerParty;
  const secondPartyWithTax = secondPartyFee + vatPerParty;
  const totalVat = dealType === 'sale' ? saleResult.vatAmount : rentResult.vatAmount;
  const totalCommission = dealType === 'sale' ? saleResult.totalCommission : rentResult.totalCommission;
  const totalAgencyIncome = dealType === 'sale' ? saleResult.totalFeeBeforeVat : rentResult.totalFeeBeforeVat;

  const handleCopyInvoice = () => {
    let invoice = '';
    if (dealType === 'sale') {
      invoice = `📄 صورت‌حساب کمیسیون معامله خرید و فروش
مبلغ کل معامله: ${formatToman(salePrice)}
نرخ کمیسیون هر طرف: ${saleRatePercent}٪
--------------------------------
سهم خریدار: ${formatToman(firstPartyFee)}
سهم فروشنده: ${formatToman(secondPartyFee)}
مالیات ارزش افزوده (${includeTax ? taxPercent : 0}٪): ${formatToman(totalVat)}
مجموع پرداختی هر طرف با مالیات: ${formatToman(firstPartyWithTax)}
مجموع کل درآمد قبل از مالیات: ${formatToman(totalAgencyIncome)}
کل دریافتی با مالیات: ${formatToman(totalCommission)}`;
    } else {
      invoice = `📄 صورت‌حساب کمیسیون معامله رهن و اجاره
مبلغ ودیعه: ${formatToman(mortgagePrice, false)}
مبلغ اجاره ماهیانه: ${formatToman(rentPrice)}
--------------------------------
سهم مستاجر: ${formatToman(firstPartyFee)}
سهم موجر: ${formatToman(secondPartyFee)}
مالیات ارزش افزوده (${includeTax ? taxPercent : 0}٪): ${formatToman(totalVat)}
مجموع پرداختی هر طرف با مالیات: ${formatToman(firstPartyWithTax)}
مجموع کل درآمد قبل از مالیات: ${formatToman(totalAgencyIncome)}
کل دریافتی با مالیات: ${formatToman(totalCommission)}`;
    }

    navigator.clipboard.writeText(invoice);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-5 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 lg:p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-right">
        <div>
          <h2 className="text-lg lg:text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Calculator className="w-5 h-5 text-purple-600" />
            <span>محاسبه‌گر حق کمیسیون و تعرفه اتحادیه</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            محاسبه دقیق دستمزد قانونی مشاور با احتساب ۱۰٪ مالیات بر ارزش افزوده برای هر دو طرف
          </p>
        </div>

        <button
          onClick={handleCopyInvoice}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-md shadow-purple-600/20 transition-all self-start sm:self-auto"
        >
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          <span>کپی صورت‌حساب پیامکی</span>
        </button>
      </div>

      {/* Deal Type Switcher */}
      <div className="flex p-1.5 rounded-2xl bg-slate-100 dark:bg-slate-800 max-w-md mx-auto border border-slate-200 dark:border-slate-700">
        <button
          type="button"
          onClick={() => setDealType('sale')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            dealType === 'sale'
              ? 'bg-white dark:bg-slate-900 text-purple-600 shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>کمیسیون خرید و فروش</span>
        </button>
        <button
          type="button"
          onClick={() => setDealType('rent')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            dealType === 'rent'
              ? 'bg-white dark:bg-slate-900 text-purple-600 shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
          }`}
        >
          <KeyRound className="w-4 h-4" />
          <span>کمیسیون رهن و اجاره</span>
        </button>
      </div>

      {/* Inputs & Invoice Details Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 text-right">
        {/* Left Inputs (6 cols) */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-3xl p-5 lg:p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <div className="font-bold text-sm text-slate-800 dark:text-slate-200 pb-2 border-b border-slate-100 dark:border-slate-800">
            ورود اطلاعات معامله
          </div>

          {dealType === 'sale' ? (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  مبلغ کل معامله (تومان)
                </label>
                <input
                  type="number"
                  value={salePrice}
                  onChange={(e) => setSalePrice(Number(e.target.value))}
                  step="50000000"
                  className="w-full px-4 py-2.5 text-sm font-black rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono text-left"
                  dir="ltr"
                />
                <div className="text-xs text-purple-600 font-medium mt-1">
                  {numberToPersianWords(salePrice)}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  <span>درصد تعرفه هر طرف معامله:</span>
                  <span className="font-mono font-black text-purple-600">
                    {toPersianDigits(saleRatePercent)} درصد
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {[0.25, 0.5, 1.0].map(rate => (
                    <button
                      key={rate}
                      type="button"
                      onClick={() => setSaleRatePercent(rate)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-mono font-semibold border transition-all ${
                        saleRatePercent === rate
                          ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {rate}٪ {rate === 0.25 ? '(تعرفه)' : ''}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  مبلغ ودیعه / رهن (تومان)
                </label>
                <input
                  type="number"
                  value={mortgagePrice}
                  onChange={(e) => setMortgagePrice(Number(e.target.value))}
                  step="10000000"
                  className="w-full px-4 py-2.5 text-sm font-black rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono text-left"
                  dir="ltr"
                />
                <div className="text-xs text-purple-600 font-medium mt-1">
                  {numberToPersianWords(mortgagePrice)}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  مبلغ اجاره ماهانه (تومان)
                </label>
                <input
                  type="number"
                  value={rentPrice}
                  onChange={(e) => setRentPrice(Number(e.target.value))}
                  step="1000000"
                  className="w-full px-4 py-2.5 text-sm font-black rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono text-left"
                  dir="ltr"
                />
                <div className="text-xs text-purple-600 font-medium mt-1">
                  {numberToPersianWords(rentPrice)}
                </div>
              </div>
            </div>
          )}

          {/* Tax Checkbox & Rate */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700 space-y-2">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-800 dark:text-slate-200">
              <input
                type="checkbox"
                checked={includeTax}
                onChange={(e) => setIncludeTax(e.target.checked)}
                className="w-4 h-4 text-purple-600 rounded-md"
              />
              <span>محاسبه ۱۰٪ مالیات بر ارزش افزوده (VAT اتحادیه)</span>
            </label>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              طبق قانون نظام صنفی، ۱۰ درصد ارزش افزوده به حق‌الزحمه مشاور اضافه شده و از طرفین دریافت می‌گردد.
            </p>
          </div>
        </div>

        {/* Right Invoice Receipt (6 cols) */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 lg:p-6 border border-slate-200/80 dark:border-slate-800 shadow-lg space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-purple-600" />
                <span className="font-bold text-sm text-slate-900 dark:text-white">
                  فیش تفکیکی کمیسیون
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                نرخ مصوب سال ۱۴۰۳
              </span>
            </div>

            {/* Split breakdown */}
            <div className="space-y-3">
              {/* Buyer / Tenant */}
              <div className="p-3.5 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/40 flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs text-purple-950 dark:text-purple-200">
                    سهم پرداختی {dealType === 'sale' ? 'خریدار' : 'مستاجر'}:
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    شامل کمیسیون + ارزش افزوده
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-base font-black text-purple-700 dark:text-purple-300">
                    {formatToman(firstPartyWithTax)}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    (کمیسیون خالص: {formatToman(firstPartyFee, false)})
                  </div>
                </div>
              </div>

              {/* Seller / Landlord */}
              <div className="p-3.5 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/40 flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs text-purple-950 dark:text-purple-200">
                    سهم پرداختی {dealType === 'sale' ? 'فروشنده / مالک' : 'موجر'}:
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    شامل کمیسیون + ارزش افزوده
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-base font-black text-purple-700 dark:text-purple-300">
                    {formatToman(secondPartyWithTax)}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    (کمیسیون خالص: {formatToman(secondPartyFee, false)})
                  </div>
                </div>
              </div>

              {/* Total Summary */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span>مجموع مالیات ارزش افزوده طرفین:</span>
                  <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
                    {formatToman(totalVat)}
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white flex items-center justify-between shadow-md">
                  <div>
                    <div className="text-xs text-purple-100 font-semibold">
                      مجموع کل درآمد آژانس املاک:
                    </div>
                    <div className="text-xl font-black mt-0.5">
                      {formatToman(totalAgencyIncome)}
                    </div>
                  </div>
                  <ShieldCheck className="w-8 h-8 text-purple-200 opacity-80" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
