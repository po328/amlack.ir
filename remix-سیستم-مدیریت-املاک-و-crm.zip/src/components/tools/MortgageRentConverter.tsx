import React, { useState, useEffect } from 'react';
import {
  ArrowLeftRight,
  Calculator,
  Save,
  RotateCcw,
  Copy,
  Check,
  Clock,
  Trash2,
  TrendingUp,
  Info
} from 'lucide-react';
import { ConversionRecord } from '../../types';
import {
  calculateMortgageRentConversion,
  calculateCustomConversion,
  formatToman,
  numberToPersianWords,
  toPersianDigits,
  formatPersianDate
} from '../../utils/formatters';
import { useToast } from '../../context/ToastContext';
import { ConfirmModal } from '../common/ConfirmModal';

interface MortgageRentConverterProps {
  initialMortgage?: number;
  initialRent?: number;
  history: ConversionRecord[];
  onSaveRecord: (record: Omit<ConversionRecord, 'id'>) => void;
  onClearHistory: () => void;
  defaultRatePercent?: number;
}

export const MortgageRentConverter: React.FC<MortgageRentConverterProps> = ({
  initialMortgage = 500000000,
  initialRent = 15000000,
  history,
  onSaveRecord,
  onClearHistory,
  defaultRatePercent = 3.0
}) => {
  const [mortgage, setMortgage] = useState<number>(initialMortgage);
  const [rent, setRent] = useState<number>(initialRent);
  const [ratePercent, setRatePercent] = useState<number>(defaultRatePercent); // e.g. 3%

  // Custom partial conversion state
  const [targetMortgage, setTargetMortgage] = useState<number>(initialMortgage);
  const [copied, setCopied] = useState(false);

  const { showToast } = useToast();
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  useEffect(() => {
    if (initialMortgage) setMortgage(initialMortgage);
    if (initialRent) setRent(initialRent);
    if (initialMortgage) setTargetMortgage(initialMortgage);
  }, [initialMortgage, initialRent]);

  // Main calculations
  const { fullMortgage, fullRent } = calculateMortgageRentConversion(mortgage, rent, ratePercent);
  const customRent = calculateCustomConversion(mortgage, rent, targetMortgage, ratePercent);

  const handleSaveToHistory = () => {
    onSaveRecord({
      mortgage,
      rent,
      ratePercent,
      fullMortgage,
      fullRent,
      date: new Date().toISOString()
    });
    showToast('نتیجه تبدیل با موفقیت در تاریخچه ثبت شد.', 'success');
  };

  const handleCopyResult = () => {
    const text = `🔄 گزارش تبدیل رهن و اجاره
ودیعه فعلی: ${formatToman(mortgage)}
اجاره ماهانه فعلی: ${formatToman(rent)}
نرخ تبدیل: ${ratePercent} درصد
-----------------------------
معادل رهن کامل: ${formatToman(fullMortgage)} (${numberToPersianWords(fullMortgage)})
معادل اجاره کامل: ${formatToman(fullRent)} (${numberToPersianWords(fullRent)})`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    showToast('متن گزارش تبدیل در کلیپ‌بورد کپی شد.', 'info');
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-5 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 lg:p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-right">
        <div>
          <h2 className="text-lg lg:text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <ArrowLeftRight className="w-5 h-5 text-emerald-600" />
            <span>سیستم تبدیل رهن و اجاره</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            محاسبه دقیق رهن کامل، اجاره کامل و تبدیل سفارشی مطابق عرف روز بازار مسکن
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyResult}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
            <span>کپی نتیجه</span>
          </button>
          <button
            onClick={handleSaveToHistory}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>ذخیره در تاریخچه</span>
          </button>
        </div>
      </div>

      {/* Main Interactive Calculator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Inputs Panel (7 Cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl p-5 lg:p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-5 text-right">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <span className="font-bold text-sm text-slate-900 dark:text-white">
              مبالغ فعلی قرارداد یا آگهی
            </span>
            <div className="flex items-center gap-1 text-xs text-emerald-600 font-semibold">
              <Info className="w-3.5 h-3.5" />
              <span>نرخ عرف: ۳ درصد ماهانه</span>
            </div>
          </div>

          {/* Input 1: Mortgage */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <label className="font-bold text-slate-700 dark:text-slate-300">
                مبلغ رهن / ودیعه (تومان):
              </label>
              <span className="text-emerald-600 font-medium">
                {numberToPersianWords(mortgage)}
              </span>
            </div>
            <input
              type="number"
              value={mortgage}
              onChange={(e) => {
                const val = Number(e.target.value);
                setMortgage(val);
                setTargetMortgage(val);
              }}
              step="10000000"
              className="w-full px-4 py-3 text-sm font-black rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-left"
              dir="ltr"
            />
            {/* Quick buttons */}
            <div className="flex items-center gap-1.5 pt-1 overflow-x-auto">
              {[100000000, 200000000, 500000000, 1000000000, 2000000000].map(val => (
                <button
                  key={val}
                  type="button"
                  onClick={() => {
                    setMortgage(val);
                    setTargetMortgage(val);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-[11px] text-slate-600 dark:text-slate-400 font-mono shrink-0"
                >
                  {val >= 1000000000 ? `${val / 1000000000} میلیارد` : `${val / 1000000} میلیون`}
                </button>
              ))}
            </div>
          </div>

          {/* Input 2: Rent */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <label className="font-bold text-slate-700 dark:text-slate-300">
                مبلغ اجاره ماهیانه (تومان):
              </label>
              <span className="text-teal-600 font-medium">
                {numberToPersianWords(rent)}
              </span>
            </div>
            <input
              type="number"
              value={rent}
              onChange={(e) => setRent(Number(e.target.value))}
              step="1000000"
              className="w-full px-4 py-3 text-sm font-black rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-teal-500 font-mono text-left"
              dir="ltr"
            />
            {/* Quick buttons */}
            <div className="flex items-center gap-1.5 pt-1 overflow-x-auto">
              {[5000000, 10000000, 15000000, 25000000, 50000000].map(val => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setRent(val)}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-[11px] text-slate-600 dark:text-slate-400 font-mono shrink-0"
                >
                  {val / 1000000} میلیون
                </button>
              ))}
            </div>
          </div>

          {/* Rate Percent Slider */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-slate-700 dark:text-slate-300">نرخ تبدیل ماهانه:</span>
              <span className="font-black text-emerald-600 dark:text-emerald-400 font-mono text-sm">
                {toPersianDigits(ratePercent)} درصد (هر میلیون ۳۰ هزار تومان)
              </span>
            </div>
            <input
              type="range"
              min="2.0"
              max="4.0"
              step="0.1"
              value={ratePercent}
              onChange={(e) => setRatePercent(Number(e.target.value))}
              className="w-full accent-emerald-600"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-mono">
              <span>۲.۰٪ (۲۰ هزار تومان)</span>
              <span>۲.۵٪</span>
              <span className="font-bold text-emerald-600">۳.۰٪ (عرف بازار)</span>
              <span>۳.۵٪</span>
              <span>۴.۰٪ (۴۰ هزار تومان)</span>
            </div>
          </div>

          {/* Custom conversion: "تبدیل سفارشی" */}
          <div className="p-4 rounded-2xl bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200/60 dark:border-teal-900/40 space-y-3">
            <div className="font-bold text-xs text-teal-900 dark:text-teal-300">
              تبدیل به ودیعه دلخواه (تغییر میزان رهن):
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <label className="block text-[11px] text-slate-500 dark:text-slate-400 mb-1">
                  اگر مستاجر این مقدار رهن بدهد (تومان):
                </label>
                <input
                  type="number"
                  value={targetMortgage}
                  onChange={(e) => setTargetMortgage(Number(e.target.value))}
                  step="20000000"
                  className="w-full px-3 py-2 text-xs font-bold rounded-xl bg-white dark:bg-slate-800 border border-teal-300 dark:border-teal-800 focus:outline-none"
                />
              </div>

              <div className="flex-1">
                <label className="block text-[11px] text-slate-500 dark:text-slate-400 mb-1">
                  اجاره جدید محاسبه شده:
                </label>
                <div className="px-3 py-2 text-xs font-black rounded-xl bg-teal-600 text-white truncate">
                  {formatToman(customRent)}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Output Cards (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Card 1: Full Mortgage Result */}
          <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-3xl p-5 lg:p-6 shadow-xl shadow-emerald-600/15 relative overflow-hidden text-right">
            <div className="text-xs font-semibold text-emerald-100 mb-1">معادل رهن کامل (صفر اجاره):</div>
            <div className="text-2xl lg:text-3xl font-black tracking-tight mt-1">
              {formatToman(fullMortgage)}
            </div>
            <div className="text-xs text-emerald-100 mt-1">
              {numberToPersianWords(fullMortgage)}
            </div>
            <div className="mt-4 pt-3 border-t border-white/20 text-[11px] text-emerald-100 flex items-center justify-between">
              <span>ودیعه اولیه: {formatToman(mortgage, false)}</span>
              <span>+ رهن تبدیل‌شده: {formatToman(fullMortgage - mortgage, false)}</span>
            </div>
          </div>

          {/* Card 2: Full Rent Result */}
          <div className="bg-gradient-to-br from-teal-600 to-cyan-700 text-white rounded-3xl p-5 lg:p-6 shadow-xl shadow-teal-600/15 relative overflow-hidden text-right">
            <div className="text-xs font-semibold text-teal-100 mb-1">معادل اجاره کامل (صفر ودیعه):</div>
            <div className="text-2xl lg:text-3xl font-black tracking-tight mt-1">
              {formatToman(fullRent)}
            </div>
            <div className="text-xs text-teal-100 mt-1">
              {numberToPersianWords(fullRent)} در ماه
            </div>
            <div className="mt-4 pt-3 border-t border-white/20 text-[11px] text-teal-100 flex items-center justify-between">
              <span>اجاره اولیه: {formatToman(rent, false)}</span>
              <span>+ اجاره ودیعه: {formatToman(fullRent - rent, false)}</span>
            </div>
          </div>

          {/* Formula summary */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 text-xs text-slate-600 dark:text-slate-300 space-y-2 text-right">
            <div className="font-bold text-slate-800 dark:text-slate-200">
              فرمول محاسباتی عرف املاک:
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              هر ۱۰۰ میلیون تومان ودیعه = ۳ میلیون تومان اجاره ماهانه. <br />
              برای تبدیل اجاره به رهن، اجاره تقسیم بر {ratePercent / 100} شده و به ودیعه اضافه می‌گردد.
            </p>
          </div>
        </div>
      </div>

      {/* History of conversions */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3 text-right">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              تاریخچه آخرین محاسبات تبدیل ({history.length})
            </h3>
          </div>
          {history.length > 0 && (
            <button
              type="button"
              onClick={() => setShowClearConfirm(true)}
              className="text-xs text-red-500 hover:underline flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>پاکسازی تاریخچه</span>
            </button>
          )}
        </div>

        {history.length === 0 ? (
          <p className="text-center text-xs text-slate-400 py-6">
            تاریخچه محاسبات خالی است. با زدن دکمه «ذخیره در تاریخچه»، موارد مهم در اینجا نگهداری می‌شوند.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {history.slice(0, 6).map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700/60 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between text-slate-400 text-[10px]">
                  <span>نرخ: {item.ratePercent}٪</span>
                  <span>{formatPersianDate(item.date)}</span>
                </div>
                <div className="font-bold text-slate-800 dark:text-slate-200">
                  رهن: {formatToman(item.mortgage, false)} | اجاره: {formatToman(item.rent)}
                </div>
                <div className="text-emerald-600 dark:text-emerald-400 font-extrabold text-[11px] pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
                  معادل رهن کامل: {formatToman(item.fullMortgage)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <ConfirmModal
        isOpen={showClearConfirm}
        title="پاکسازی تاریخچه تبدیلات"
        description="آیا از حذف تمامی رکوردهای تاریخچه تبدیل رهن و اجاره اطمینان دارید؟"
        confirmLabel="بله، تاریخچه پاک شود"
        cancelLabel="انصراف"
        isDanger={true}
        onConfirm={() => {
          onClearHistory();
          setShowClearConfirm(false);
          showToast('تاریخچه تبدیلات پاکسازی شد.', 'info');
        }}
        onCancel={() => setShowClearConfirm(false)}
      />
    </div>
  );
};
